# Changelog — LocalBoost AI

## [production-fixed] — 2026-09-24
Hardening release built from v1.0.0. No data loss: all existing options, encrypted
keys, tables and REST routes remain backward compatible.

### Added
- Canonical field registry (`includes/class-field-registry.php`): `title`,
  `meta_description`, `h1`, `introduction`, `faq`, `cta`, `alt_texts`,
  `internal_links`; legacy aliases (`seo_title`→`title`, `image_alt`→`alt_texts`,
  `service_description`→`introduction`); `h2_structure` kept as deprecated.
- Transform action `readability`; `improve` is now an alias of `readability`.
- Change history (`services/class-change-history.php`, new `{prefix}lbai_changes`
  table): post, user, field, old/new value, provider, model, timestamp, status —
  plus `POST /ai/undo` to roll back the last apply.
- Authenticated API-key storage: versioned payloads (v2 sodium secretbox, v3
  AES-GCM) with transparent migration from legacy v1 AES-256-CBC on read.
- SSRF protection (`includes/class-url-validator.php`): scheme/host/IP allow-list,
  metadata/private/loopback/multicast blocking for remote providers; intentional
  localhost/Ollama support kept for the self-hosted provider with an admin warning.
- mbstring-safe `Text_Utils` with pure-PHP fallback + admin notice when mbstring
  is missing.
- Cron hardening: idempotent scheduling, run lock, retry/backoff, last/next run
  and failure status (`Monitor::get_status()`).
- Usage quotas: reserve → finalize / release flow with success/failure tracking,
  provider/model/token reporting (`get_usage_report()`); DB v1.1.0 migration.
- Rate limiter: documented sliding-window semantics ("N requests per W seconds")
  and atomic-ish `consume()`.
- Reporter: pagination, date-range filters, SQL aggregation, chunked CSV export,
  CSV formula-injection neutralization; DB v1.2.0 index migration.
- Dashboard: real status cards (provider, monitoring, usage vs quota, recent
  audits) with empty states; monitoring + usage panels in Settings; RTL stylesheet
  (`assets/css/lbai-admin-rtl.css`); accessibility improvements.
- CI workflow (`.github/workflows/ci.yml`): PHP 7.4–8.4 lint + full test suite +
  PHP 8-only syntax guard + JS check.
- Marketing website (separate project, `../localboost-ai-site/`): 11 pages in
  English and Arabic (RTL), honest messaging only.

### Changed
- REST `/ai/optimize`, `/ai/apply`, `/audit/<id>`, `/ai/undo` now enforce
  `current_user_can('edit_post', $post_id)` in addition to `manage_options`;
  per-post nonces on apply/undo.
- Unified audit issue contract `{id, severity, category, field, title, problem,
  why, action, ai_fix}` shared by auditor, REST, JS and optimizer; "Fix with AI"
  only offered for AI-fixable fields.
- Apply flow: current-vs-suggestion preview, `wp_kses_post`/`sanitize_text_field`
  sanitization, `wp_save_post_revision()` safety net before overwriting.
- Meta description: Yoast (`_yoast_wpseo_metadesc`) → Rank Math
  (`rank_math_description`) → `_lbai_meta_description` fallback; no duplicate
  meta output.
- `/ai/test-connection` returns a real error when `valid` is false; admin JS
  rejects `valid !== true` and shows the API message.
- `docs/SECURITY.md`, `docs/TESTING.md`, `docs/CONFIGURATION.md`, `readme.txt`
  updated.

### Fixed
- Rate limiter now records every AI request path (`check()` without `hit()`
  replaced by `consume()` at the REST layer contract).
- Monthly monitoring no longer double-schedules; invalid frequencies can't fatal.
- CSV export no longer loads the whole dataset into memory.
- `fputcsv()` explicit escape arg (PHP 8.1 deprecation silenced, 7.4 behavior kept).

### Security
- See `docs/SECURITY.md`. No SQL injection surface found in the full `$wpdb`
  audit (`SQL_AUDIT_FINDINGS.md`); all `innerHTML` sinks escaped; CSV
  formula-injection neutralized; raw API keys never reach REST/HTML/JS/logs.

## [1.0.0] — 2026-09-23
Initial release: SEO auditor, AI optimizer, content generator, keyword assistant,
consistency checker, schema generator, reporter, monitor, 5 AI providers, 17
REST routes, 12 admin pages + 7-step onboarding.
