<?php
/**
 * Admin UI bootstrap for LocalBoost AI.
 *
 * Registers the admin menu, enqueues assets, registers Settings API
 * options and adds the plugin action links.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

namespace LocalBoostAI\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Class Admin
 *
 * Owns the entire wp-admin surface of the plugin.
 */
final class Admin {

	/**
	 * Option keys registered through the Settings API (group: lbai_settings).
	 *
	 * API keys are deliberately NOT registered here. They are stored via the
	 * encrypted Secure_Store and written only through the REST API endpoint
	 * POST /lbai/v1/settings, which keeps them out of options.php forms,
	 * autosaves and front-end output.
	 *
	 * @var array
	 */
	private $settings_keys = array(
		// Business profile.
		'lbai_business_name'     => 'sanitize_text_field',
		'lbai_business_type'     => 'sanitize_text_field',
		'lbai_address'           => 'sanitize_text_field',
		'lbai_city'              => 'sanitize_text_field',
		'lbai_region'            => 'sanitize_text_field',
		'lbai_postal_code'       => 'sanitize_text_field',
		'lbai_country'           => 'sanitize_text_field',
		'lbai_phone'             => 'sanitize_text_field',
		'lbai_email'             => 'sanitize_email',
		'lbai_website'           => 'esc_url_raw',
		'lbai_hours'             => 'sanitize_textarea_field',
		'lbai_services'          => 'sanitize_textarea_field',
		'lbai_price_range'       => 'sanitize_text_field',
		'lbai_social_profiles'   => 'sanitize_social_profiles',
		'lbai_latitude'          => 'sanitize_text_field',
		'lbai_longitude'         => 'sanitize_text_field',
		// AI preferences (keys themselves are never stored here).
		'lbai_ai_provider'       => 'sanitize_key',
		'lbai_ai_model'          => 'sanitize_text_field',
		'lbai_ai_temperature'    => 'sanitize_temperature',
		'lbai_ai_max_tokens'     => 'absint',
		// Monitoring + notifications.
		'lbai_monitor_frequency' => 'sanitize_key',
		'lbai_monitored_pages'   => 'sanitize_id_list',
		'lbai_notify_audit_completed' => 'rest_sanitize_boolean',
		'lbai_notify_critical_issue'   => 'rest_sanitize_boolean',
		'lbai_notify_report_ready'     => 'rest_sanitize_boolean',
		'lbai_notify_usage_limit'      => 'rest_sanitize_boolean',
		// Licensing / white label.
		'lbai_license_key'       => 'sanitize_text_field',
		'lbai_white_label_name'  => 'sanitize_text_field',
		'lbai_white_label_logo'  => 'esc_url_raw',
	);

	/**
	 * Register all admin hooks.
	 *
	 * @return void
	 */
	public static function register() {
		$admin = new self();

		add_action( 'admin_menu', array( $admin, 'admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $admin, 'admin_enqueue_scripts' ) );
		add_action( 'admin_init', array( $admin, 'register_settings' ) );
		add_filter(
			'plugin_action_links_' . plugin_basename( LBAI_PLUGIN_FILE ),
			array( $admin, 'plugin_action_links' )
		);
	}

	/**
	 * Register menu pages.
	 *
	 * @return void
	 */
	public function admin_menu() {
		add_menu_page(
			__( 'LocalBoost AI', 'localboost-ai' ),
			__( 'LocalBoost AI', 'localboost-ai' ),
			'manage_options',
			'lbai-dashboard',
			array( $this, 'render_dashboard' ),
			'dashicons-chart-area',
			30
		);

		$pages = array(
			'lbai-dashboard'  => array( __( 'Dashboard', 'localboost-ai' ), array( $this, 'render_dashboard' ) ),
			'lbai-audit'      => array( __( 'SEO Audit', 'localboost-ai' ), array( $this, 'render_audit' ) ),
			'lbai-optimizer'  => array( __( 'AI Optimizer', 'localboost-ai' ), array( $this, 'render_optimizer' ) ),
			'lbai-local'      => array( __( 'Local SEO', 'localboost-ai' ), array( $this, 'render_local' ) ),
			'lbai-content'    => array( __( 'Content', 'localboost-ai' ), array( $this, 'render_content' ) ),
			'lbai-schema'     => array( __( 'Schema', 'localboost-ai' ), array( $this, 'render_schema' ) ),
			'lbai-keywords'   => array( __( 'Keywords', 'localboost-ai' ), array( $this, 'render_keywords' ) ),
			'lbai-reports'    => array( __( 'Reports', 'localboost-ai' ), array( $this, 'render_reports' ) ),
			'lbai-ai-settings' => array( __( 'AI Settings', 'localboost-ai' ), array( $this, 'render_ai_settings' ) ),
			'lbai-settings'   => array( __( 'Settings', 'localboost-ai' ), array( $this, 'render_settings' ) ),
			'lbai-upgrade'    => array( __( 'Upgrade', 'localboost-ai' ), array( $this, 'render_upgrade' ) ),
		);

		foreach ( $pages as $slug => $data ) {
			list( $title, $callback ) = $data;
			add_submenu_page(
				'lbai-dashboard',
				$title . ' – ' . __( 'LocalBoost AI', 'localboost-ai' ),
				$title,
				'manage_options',
				$slug,
				$callback
			);
		}

		// Hidden onboarding wizard (no menu entry).
		add_submenu_page(
			null,
			__( 'LocalBoost AI Setup', 'localboost-ai' ),
			__( 'Setup', 'localboost-ai' ),
			'manage_options',
			'lbai-onboarding',
			array( $this, 'render_onboarding' )
		);
	}

	/**
	 * Render a view file after a capability check.
	 *
	 * @param string $view View filename without extension.
	 * @return void
	 */
	private function render( $view ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'localboost-ai' ), 403 );
		}

		$path = plugin_dir_path( LBAI_PLUGIN_FILE ) . 'admin/views/' . $view . '.php';
		if ( ! file_exists( $path ) ) {
			wp_die( esc_html__( 'View not found.', 'localboost-ai' ), 500 );
		}

		require $path;
	}

	public function render_dashboard()  { $this->render( 'view-dashboard' ); }
	public function render_audit()      { $this->render( 'view-audit' ); }
	public function render_optimizer()  { $this->render( 'view-optimizer' ); }
	public function render_local()      { $this->render( 'view-local-seo' ); }
	public function render_content()    { $this->render( 'view-content' ); }
	public function render_schema()     { $this->render( 'view-schema' ); }
	public function render_keywords()   { $this->render( 'view-keywords' ); }
	public function render_reports()    { $this->render( 'view-reports' ); }
	public function render_ai_settings() { $this->render( 'view-ai-settings' ); }
	public function render_settings()   { $this->render( 'view-settings' ); }
	public function render_upgrade()    { $this->render( 'view-upgrade' ); }
	public function render_onboarding() { $this->render( 'view-onboarding' ); }

	/**
	 * Enqueue CSS/JS only on LocalBoost AI admin screens.
	 *
	 * @param string $hook_suffix Current admin page hook suffix.
	 * @return void
	 */
	public function admin_enqueue_scripts( $hook_suffix ) {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		$screen_id = $screen ? $screen->id : '';

		$is_lbai = (
			0 === strpos( $screen_id, 'toplevel_page_lbai' ) ||
			false !== strpos( $screen_id, 'lbai-dashboard_page_' ) ||
			false !== strpos( $screen_id, 'admin_page_lbai-onboarding' )
		);

		if ( ! $is_lbai ) {
			return;
		}

		$version = defined( 'LBAI_VERSION' ) ? LBAI_VERSION : '1.0.0';

		wp_enqueue_style(
			'lbai-admin',
			plugin_dir_url( LBAI_PLUGIN_FILE ) . 'assets/css/lbai-admin.css',
			array(),
			$version
		);

		// Load assets/css/lbai-admin-rtl.css automatically in RTL admin locales.
		wp_style_add_data( 'lbai-admin', 'rtl', 'replace' );

		wp_enqueue_script(
			'lbai-admin',
			plugin_dir_url( LBAI_PLUGIN_FILE ) . 'assets/js/lbai-admin.js',
			array( 'wp-api-fetch' ),
			$version,
			true
		);

		wp_localize_script(
			'lbai-admin',
			'lbaiAdmin',
			array(
				'restUrl' => esc_url_raw( rest_url() ),
				'nonce'   => wp_create_nonce( 'wp_rest' ),
				'i18n'    => array(
					'error'               => __( 'Something went wrong. Please try again.', 'localboost-ai' ),
					'networkError'        => __( 'Network error. Check your connection and try again.', 'localboost-ai' ),
					'loading'             => __( 'Loading…', 'localboost-ai' ),
					'generating'          => __( 'Generating…', 'localboost-ai' ),
					'analyzing'           => __( 'Analyzing…', 'localboost-ai' ),
					'saving'              => __( 'Saving…', 'localboost-ai' ),
					'saved'               => __( 'Saved.', 'localboost-ai' ),
					'copied'              => __( 'Copied to clipboard.', 'localboost-ai' ),
					'copyFailed'          => __( 'Copy failed. Please select the text manually.', 'localboost-ai' ),
					'applied'             => __( 'Applied successfully.', 'localboost-ai' ),
					'testingConnection'   => __( 'Testing connection…', 'localboost-ai' ),
					'connectionOk'        => __( 'Connection successful.', 'localboost-ai' ),
					'connectionFailed'    => __( 'Connection failed.', 'localboost-ai' ),
					'confirmApply'        => __( 'Apply this AI suggestion? You can undo it from the post editor.', 'localboost-ai' ),
					'confirmDeleteData'   => __( 'This permanently deletes all LocalBoost AI data. Continue?', 'localboost-ai' ),
					'noResults'           => __( 'No results found.', 'localboost-ai' ),
					'limitReached'        => __( 'You have reached your usage limit.', 'localboost-ai' ),
					'selectPage'          => __( 'Please select a page first.', 'localboost-ai' ),
					'stepOf'              => __( 'Step %1$d of %2$d', 'localboost-ai' ),
				),
			)
		);
	}

	/**
	 * Register Settings API options.
	 *
	 * @return void
	 */
	public function register_settings() {
		foreach ( $this->settings_keys as $key => $sanitize ) {
			$callback = $sanitize;
			if ( is_string( $sanitize ) && method_exists( $this, $sanitize ) ) {
				$callback = array( $this, $sanitize );
			}
			register_setting(
				'lbai_settings',
				$key,
				array(
					'sanitize_callback' => $callback,
					'show_in_rest'      => false,
					'default'           => $this->default_for( $key ),
				)
			);
		}
	}

	/**
	 * Default value for a settings key.
	 *
	 * @param string $key Option key.
	 * @return mixed
	 */
	private function default_for( $key ) {
		$defaults = array(
			'lbai_ai_temperature'    => 0.7,
			'lbai_ai_max_tokens'     => 1000,
			'lbai_monitor_frequency' => 'off',
			'lbai_notify_audit_completed' => true,
			'lbai_notify_critical_issue'   => true,
			'lbai_notify_report_ready'     => false,
			'lbai_notify_usage_limit'      => true,
		);

		return isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
	}

	/**
	 * Sanitize temperature to the 0–2 range.
	 *
	 * @param mixed $value Raw value.
	 * @return float
	 */
	public function sanitize_temperature( $value ) {
		$value = (float) $value;
		return max( 0, min( 2, $value ) );
	}

	/**
	 * Sanitize a list of post IDs.
	 *
	 * @param mixed $value Raw value.
	 * @return array
	 */
	public function sanitize_id_list( $value ) {
		if ( ! is_array( $value ) ) {
			$value = array( $value );
		}
		return array_values( array_unique( array_filter( array_map( 'absint', $value ) ) ) );
	}

	/**
	 * Sanitize social profile URLs (one per line or comma separated).
	 *
	 * @param mixed $value Raw value.
	 * @return string Newline separated clean URLs.
	 */
	public function sanitize_social_profiles( $value ) {
		$parts = preg_split( '/[\r\n,]+/', (string) $value );
		$clean = array();
		foreach ( $parts as $part ) {
			$url = esc_url_raw( trim( $part ) );
			if ( '' !== $url ) {
				$clean[] = $url;
			}
		}
		return implode( "\n", $clean );
	}

	/**
	 * Add action links on the plugins list.
	 *
	 * @param array $links Existing links.
	 * @return array
	 */
	public function plugin_action_links( $links ) {
		$settings_link = sprintf(
			'<a href="%s">%s</a>',
			esc_url( admin_url( 'admin.php?page=lbai-settings' ) ),
			esc_html__( 'Settings', 'localboost-ai' )
		);
		array_unshift( $links, $settings_link );
		return $links;
	}
}
