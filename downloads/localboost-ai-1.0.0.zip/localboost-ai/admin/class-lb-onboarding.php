<?php
/**
 * Onboarding wizard for LocalBoost AI.
 *
 * Redirects the administrator to the 7-step setup wizard after activation
 * and exposes a finish() helper used by the REST layer / wizard JS.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

namespace LocalBoostAI\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Class Onboarding
 */
final class Onboarding {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function register() {
		$onboarding = new self();
		add_action( 'admin_init', array( $onboarding, 'maybe_redirect' ) );
	}

	/**
	 * Redirect to the onboarding wizard once after activation.
	 *
	 * The activation routine sets the 'lbai_onboarding_pending' transient.
	 * We redirect on the first admin_init for a capable user, then remove
	 * the transient so the redirect happens exactly once.
	 *
	 * @return void
	 */
	public function maybe_redirect() {
		if ( wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}

		if ( ! get_transient( 'lbai_onboarding_pending' ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( get_option( 'lbai_onboarding_done', false ) ) {
			delete_transient( 'lbai_onboarding_pending' );
			return;
		}

		if ( function_exists( 'get_current_screen' ) ) {
			$screen = get_current_screen();
			if ( $screen && false !== strpos( $screen->id, 'lbai-onboarding' ) ) {
				return;
			}
		}

		delete_transient( 'lbai_onboarding_pending' );

		wp_safe_redirect( admin_url( 'admin.php?page=lbai-onboarding' ) );
		exit;
	}

	/**
	 * Mark onboarding as complete.
	 *
	 * @return void
	 */
	public static function finish() {
		update_option( 'lbai_onboarding_done', 1 );
	}

	/**
	 * Whether onboarding was completed.
	 *
	 * @return bool
	 */
	public static function is_done() {
		return (bool) get_option( 'lbai_onboarding_done', false );
	}
}
