<?php
/**
 * Issue row partial.
 *
 * Renders a single audit issue as a table row: severity badge, problem,
 * why it matters, recommended action and a "Fix with AI" button.
 * Usage: lbai_issue_row( $issue_array );
 *
 * Expected keys: severity (critical|warning|recommendation|passed),
 * problem, why, action, field (optional, AI field name), post_id (optional).
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'lbai_issue_row' ) ) {
	/**
	 * Render an issue table row.
	 *
	 * @param array $issue Issue data.
	 * @return void
	 */
	function lbai_issue_row( $issue ) {
		$severity = isset( $issue['severity'] ) ? sanitize_key( $issue['severity'] ) : 'recommendation';
		$allowed  = array( 'critical', 'warning', 'recommendation', 'passed' );
		if ( ! in_array( $severity, $allowed, true ) ) {
			$severity = 'recommendation';
		}

		$labels = array(
			'critical'       => __( 'Critical', 'localboost-ai' ),
			'warning'        => __( 'Warning', 'localboost-ai' ),
			'recommendation' => __( 'Recommendation', 'localboost-ai' ),
			'passed'         => __( 'Passed', 'localboost-ai' ),
		);

		$problem  = isset( $issue['problem'] ) ? $issue['problem'] : '';
		$why      = isset( $issue['why'] ) ? $issue['why'] : '';
		$action   = isset( $issue['action'] ) ? $issue['action'] : '';
		$field    = isset( $issue['field'] ) ? sanitize_key( $issue['field'] ) : '';
		$post_id  = isset( $issue['post_id'] ) ? absint( $issue['post_id'] ) : 0;
		?>
		<tr class="lbai-issue-row lbai-issue-row--<?php echo esc_attr( $severity ); ?>">
			<td>
				<span class="lbai-badge lbai-badge-<?php echo esc_attr( $severity ); ?>">
					<?php echo esc_html( $labels[ $severity ] ); ?>
				</span>
			</td>
			<td>
				<strong class="lbai-issue-problem"><?php echo esc_html( $problem ); ?></strong>
				<?php if ( '' !== $why ) : ?>
					<p class="description"><?php echo esc_html( $why ); ?></p>
				<?php endif; ?>
			</td>
			<td>
				<?php if ( '' !== $action ) : ?>
					<p><?php echo esc_html( $action ); ?></p>
				<?php endif; ?>
				<?php if ( '' !== $field && $post_id > 0 && 'passed' !== $severity ) : ?>
					<button
						type="button"
						class="button button-small lbai-btn-fix-ai"
						data-field="<?php echo esc_attr( $field ); ?>"
						data-post-id="<?php echo esc_attr( (string) $post_id ); ?>"
					>
						<?php esc_html_e( 'Fix with AI', 'localboost-ai' ); ?>
					</button>
				<?php endif; ?>
			</td>
		</tr>
		<?php
	}
}
