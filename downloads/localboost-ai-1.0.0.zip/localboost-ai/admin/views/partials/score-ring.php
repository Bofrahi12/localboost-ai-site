<?php
/**
 * Score ring partial.
 *
 * Renders an accessible SVG-less score ring using a conic gradient.
 * Usage: echo lbai_score_ring( 82 );
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'lbai_score_ring' ) ) {
	/**
	 * Render a score ring.
	 *
	 * @param int    $score Score 0–100.
	 * @param string $label Accessible label. Defaults to "SEO score".
	 * @return void
	 */
	function lbai_score_ring( $score, $label = '' ) {
		$score = max( 0, min( 100, (int) $score ) );

		if ( '' === $label ) {
			/* translators: %d: score value */
			$label = sprintf( __( 'SEO score: %d out of 100', 'localboost-ai' ), $score );
		}

		$class = 'low';
		if ( $score >= 80 ) {
			$class = 'high';
		} elseif ( $score >= 50 ) {
			$class = 'mid';
		}
		?>
		<div class="lbai-score-ring score-<?php echo esc_attr( $class ); ?>" role="img" aria-label="<?php echo esc_attr( $label ); ?>" style="--score: <?php echo esc_attr( (string) $score ); ?>;">
			<span class="lbai-score-ring__value" aria-hidden="true"><?php echo esc_html( (string) $score ); ?></span>
		</div>
		<?php
	}
}
