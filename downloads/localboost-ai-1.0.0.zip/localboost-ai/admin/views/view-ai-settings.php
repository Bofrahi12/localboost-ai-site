<?php
/**
 * AI Settings view — provider, model, key, temperature, tokens.
 *
 * API keys are never rendered in plain text. The password field is always
 * empty on load; saving writes it through the encrypted Secure_Store via
 * POST /lbai/v1/settings.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

$providers = array();
if ( class_exists( '\LocalBoostAI\Providers\Provider_Factory' ) ) {
	$map = \LocalBoostAI\Providers\Provider_Factory::get_available_providers();
	foreach ( $map as $id => $class ) {
		if ( ! is_string( $class ) || ! class_exists( $class ) ) {
			continue;
		}
		if ( ! is_subclass_of( $class, '\LocalBoostAI\Providers\AI_Provider_Interface' ) ) {
			continue;
		}
		try {
			$instance = new $class( array( 'api_key' => '' ) );
			$providers[ $id ] = array(
				'label'  => $instance->get_label(),
				'hint'   => $instance->get_setup_hint(),
				'models' => $instance->get_models(),
			);
		} catch ( \Exception $e ) { // phpcs:ignore -- provider probe must never break the page.
			continue;
		}
	}
}

$current_provider    = get_option( 'lbai_ai_provider', '' );
$current_model       = get_option( 'lbai_ai_model', '' );
$current_temperature = (float) get_option( 'lbai_ai_temperature', 0.7 );
$current_max_tokens  = absint( get_option( 'lbai_ai_max_tokens', 1000 ) );
$meta_base_url       = get_option( 'lbai_meta_base_url', 'https://api.meta.ai/v1' );
$opensource_base_url = get_option( 'lbai_opensource_base_url', 'http://localhost:11434/v1' );
$has_key             = false;
if ( class_exists( '\LocalBoostAI\Includes\Secure_Store' ) && method_exists( '\LocalBoostAI\Includes\Secure_Store', 'get_api_key' ) && '' !== $current_provider ) {
	$has_key = '' !== trim( (string) \LocalBoostAI\Includes\Secure_Store::get_api_key( $current_provider ) );
}
?>
<div class="wrap lbai-wrap" data-lbai-page="ai-settings" data-lbai-providers="<?php echo esc_attr( wp_json_encode( $providers ) ); ?>">
	<h1 class="lbai-page-title"><?php esc_html_e( 'AI Settings', 'localboost-ai' ); ?></h1>
	<p class="lbai-page-subtitle"><?php esc_html_e( 'Choose your AI provider and connect your API key. Your key is stored encrypted and is never shown again.', 'localboost-ai' ); ?></p>

	<div class="lbai-card">
		<h2 class="lbai-card__title"><?php esc_html_e( 'Provider', 'localboost-ai' ); ?></h2>
		<?php if ( empty( $providers ) ) : ?>
			<p class="description"><?php esc_html_e( 'No AI providers are available. Please check the plugin installation.', 'localboost-ai' ); ?></p>
		<?php else : ?>
			<div class="lbai-provider-cards" role="radiogroup" aria-label="<?php esc_attr_e( 'AI provider', 'localboost-ai' ); ?>">
				<?php foreach ( $providers as $id => $info ) : ?>
					<label class="lbai-provider-card<?php echo $current_provider === $id ? ' is-selected' : ''; ?>">
						<input type="radio" name="lbai_ai_provider" value="<?php echo esc_attr( $id ); ?>"<?php checked( $current_provider, $id ); ?> />
						<span class="lbai-provider-card__name"><?php echo esc_html( $info['label'] ); ?></span>
						<?php if ( ! empty( $info['hint'] ) ) : ?>
							<span class="lbai-provider-card__desc"><?php echo esc_html( $info['hint'] ); ?></span>
						<?php endif; ?>
					</label>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>

	<div class="lbai-card">
		<h2 class="lbai-card__title"><?php esc_html_e( 'Model & connection', 'localboost-ai' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="lbai_ai_model"><?php esc_html_e( 'Model', 'localboost-ai' ); ?></label></th>
				<td>
					<select id="lbai_ai_model" class="lbai-select">
						<?php if ( '' !== $current_model ) : ?>
							<option value="<?php echo esc_attr( $current_model ); ?>" selected><?php echo esc_html( $current_model ); ?></option>
						<?php endif; ?>
					</select>
					<p class="description"><?php esc_html_e( 'Models update automatically when you change provider.', 'localboost-ai' ); ?></p>
				</td>
			</tr>
			<tr id="lbai-base-url-row" hidden>
				<th scope="row"><label for="lbai_provider_base_url"><?php esc_html_e( 'Server base URL', 'localboost-ai' ); ?></label></th>
				<td>
					<input type="url" id="lbai_provider_base_url" class="regular-text" value="" inputmode="url" dir="ltr"
						data-lbai-meta-url="<?php echo esc_attr( $meta_base_url ); ?>"
						data-lbai-opensource-url="<?php echo esc_attr( $opensource_base_url ); ?>" />
					<p class="description"><?php esc_html_e( 'The /v1 endpoint of your Meta-compatible or self-hosted server (e.g. Ollama). Shown only for providers that need it.', 'localboost-ai' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="lbai_api_key"><?php esc_html_e( 'API key', 'localboost-ai' ); ?></label></th>
				<td>
					<input type="password" id="lbai_api_key" class="regular-text" autocomplete="new-password" placeholder="<?php echo $has_key ? esc_attr__( '•••••••• (saved — enter a new key to replace)', 'localboost-ai' ) : esc_attr__( 'Paste your API key', 'localboost-ai' ); ?>" />
					<p class="description">
						<?php esc_html_e( 'Stored encrypted on your server. Never displayed, never sent to the browser except over this secure form.', 'localboost-ai' ); ?>
						<a href="<?php echo esc_url( 'https://localboost.ai/docs/ai-providers' ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'How to get a key', 'localboost-ai' ); ?></a>
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="lbai_ai_temperature"><?php esc_html_e( 'Creativity (temperature)', 'localboost-ai' ); ?></label></th>
				<td>
					<input type="range" id="lbai_ai_temperature" min="0" max="2" step="0.1" value="<?php echo esc_attr( (string) $current_temperature ); ?>" aria-describedby="lbai-temperature-value" />
					<output id="lbai-temperature-value" for="lbai_ai_temperature"><?php echo esc_html( (string) $current_temperature ); ?></output>
					<p class="description"><?php esc_html_e( 'Lower is more factual, higher is more creative. 0.7 is a good default.', 'localboost-ai' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="lbai_ai_max_tokens"><?php esc_html_e( 'Maximum tokens', 'localboost-ai' ); ?></label></th>
				<td>
					<input type="number" id="lbai_ai_max_tokens" class="small-text" min="100" max="8000" step="50" value="<?php echo esc_attr( (string) $current_max_tokens ); ?>" />
					<p class="description"><?php esc_html_e( 'Limits the length of AI responses. Higher values cost more.', 'localboost-ai' ); ?></p>
				</td>
			</tr>
		</table>
		<div class="lbai-form-inline">
			<button type="button" class="button button-primary lbai-btn" id="lbai-ai-save"><?php esc_html_e( 'Save AI settings', 'localboost-ai' ); ?></button>
			<button type="button" class="button lbai-btn" id="lbai-ai-test"><?php esc_html_e( 'Test connection', 'localboost-ai' ); ?></button>
		</div>
		<p class="description" id="lbai-ai-status" role="status"></p>
	</div>
</div>
