<?php
/**
 * SEO Audit view.
 *
 * Runs audits via POST /lbai/v1/audit and renders results in JS.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

require_once plugin_dir_path( LBAI_PLUGIN_FILE ) . 'admin/views/partials/score-ring.php';

$recent = get_posts(
	array(
		'post_type'      => array( 'page', 'post' ),
		'post_status'    => 'publish',
		'posts_per_page' => 20,
		'orderby'        => 'modified',
		'order'          => 'DESC',
		'fields'         => 'ids',
	)
);
?>
<div class="wrap lbai-wrap" data-lbai-page="audit">
	<h1 class="lbai-page-title"><?php esc_html_e( 'SEO Audit', 'localboost-ai' ); ?></h1>
	<p class="lbai-page-subtitle"><?php esc_html_e( 'Analyze any page or post for technical, on-page and local SEO issues. Results are cached — re-run the audit to refresh.', 'localboost-ai' ); ?></p>

	<div class="lbai-card">
		<h2 class="lbai-card__title"><?php esc_html_e( 'Analyze a page', 'localboost-ai' ); ?></h2>
		<form id="lbai-audit-form" class="lbai-form-inline">
			<label for="lbai-audit-post" class="screen-reader-text"><?php esc_html_e( 'Choose a page to analyze', 'localboost-ai' ); ?></label>
			<select id="lbai-audit-post" name="post_id" class="lbai-select" required>
				<option value=""><?php esc_html_e( '— Select a page or post —', 'localboost-ai' ); ?></option>
				<?php foreach ( $recent as $post_id ) : ?>
					<option value="<?php echo esc_attr( (string) $post_id ); ?>" data-apply-nonce="<?php echo esc_attr( wp_create_nonce( 'lbai_apply_' . $post_id ) ); ?>">
						<?php echo esc_html( get_the_title( $post_id ) . ' (' . get_post_type( $post_id ) . ')' ); ?>
					</option>
				<?php endforeach; ?>
			</select>
			<label for="lbai-audit-post-id" class="screen-reader-text"><?php esc_html_e( 'Or enter a post ID', 'localboost-ai' ); ?></label>
			<input type="number" id="lbai-audit-post-id" class="lbai-input lbai-input--short" min="1" step="1" placeholder="<?php esc_attr_e( 'Post ID', 'localboost-ai' ); ?>" />
			<button type="submit" class="button button-primary lbai-btn" id="lbai-audit-run">
				<?php esc_html_e( 'Analyze page', 'localboost-ai' ); ?>
			</button>
		</form>
		<p class="description" id="lbai-audit-status" role="status"></p>
	</div>

	<div id="lbai-audit-results" class="lbai-result" hidden>
		<div class="lbai-grid lbai-grid--2col">
			<div class="lbai-card lbai-stat">
				<div class="lbai-stat__label"><?php esc_html_e( 'Audit score', 'localboost-ai' ); ?></div>
				<div id="lbai-audit-score"><?php lbai_score_ring( 0 ); ?></div>
			</div>
			<div class="lbai-card">
				<h2 class="lbai-card__title"><?php esc_html_e( 'Score by category', 'localboost-ai' ); ?></h2>
				<div id="lbai-audit-categories"></div>
			</div>
		</div>

		<div class="lbai-card">
			<h2 class="lbai-card__title"><?php esc_html_e( 'Issues', 'localboost-ai' ); ?></h2>
			<div class="lbai-form-inline lbai-filters" role="group" aria-label="<?php esc_attr_e( 'Filter issues by severity', 'localboost-ai' ); ?>">
				<?php
				$filters = array(
					'all'      => __( 'All', 'localboost-ai' ),
					'critical' => __( 'Critical', 'localboost-ai' ),
					'warning'  => __( 'Warning', 'localboost-ai' ),
					'info'     => __( 'Info', 'localboost-ai' ),
				);
				foreach ( $filters as $key => $label ) :
					?>
					<button type="button" class="button lbai-btn lbai-filter-btn<?php echo 'all' === $key ? ' is-active' : ''; ?>" data-filter="<?php echo esc_attr( $key ); ?>" aria-pressed="<?php echo 'all' === $key ? 'true' : 'false'; ?>">
						<?php echo esc_html( $label ); ?>
					</button>
				<?php endforeach; ?>
			</div>
			<table class="wp-list-table widefat fixed striped lbai-table" id="lbai-issues-table">
				<thead>
					<tr>
						<th scope="col" class="lbai-col-severity"><?php esc_html_e( 'Severity', 'localboost-ai' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Issue', 'localboost-ai' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Recommended action', 'localboost-ai' ); ?></th>
					</tr>
				</thead>
				<tbody id="lbai-issues-body"></tbody>
			</table>
		</div>
	</div>
</div>

<div class="lbai-modal" id="lbai-opt-modal" role="dialog" aria-modal="true" aria-labelledby="lbai-opt-modal-title" hidden>
	<div class="lbai-modal__backdrop" data-lbai-modal-close></div>
	<div class="lbai-modal__box">
		<div class="lbai-modal__header">
			<h2 id="lbai-opt-modal-title"><?php esc_html_e( 'Review AI suggestion', 'localboost-ai' ); ?></h2>
			<button type="button" class="lbai-modal__close" data-lbai-modal-close aria-label="<?php esc_attr_e( 'Close dialog', 'localboost-ai' ); ?>">×</button>
		</div>
		<div class="lbai-diff">
			<div class="lbai-diff__col">
				<h3><?php esc_html_e( 'Current', 'localboost-ai' ); ?></h3>
				<div class="lbai-diff__content" id="lbai-opt-current"></div>
			</div>
			<div class="lbai-diff__col">
				<h3><?php esc_html_e( 'AI suggestion', 'localboost-ai' ); ?></h3>
				<div class="lbai-diff__content" id="lbai-opt-suggestion"></div>
			</div>
		</div>
		<div class="lbai-form-inline lbai-modal__placement" id="lbai-opt-placement-wrap" hidden>
			<label for="lbai-opt-placement"><?php esc_html_e( 'Insert as', 'localboost-ai' ); ?></label>
			<select id="lbai-opt-placement" class="lbai-select">
				<option value="prepend"><?php esc_html_e( 'Insert at the beginning', 'localboost-ai' ); ?></option>
				<option value="append"><?php esc_html_e( 'Insert at the end', 'localboost-ai' ); ?></option>
			</select>
		</div>
		<p class="description" id="lbai-opt-apply-note"><?php esc_html_e( 'Content fields are inserted only with explicit placement. Image alt texts update existing images automatically; internal link suggestions are guidance for the editor.', 'localboost-ai' ); ?></p>
		<div class="lbai-modal__footer">
			<button type="button" class="button lbai-btn" data-lbai-modal-close><?php esc_html_e( 'Discard', 'localboost-ai' ); ?></button>
			<button type="button" class="button lbai-btn" id="lbai-opt-undo" hidden><?php esc_html_e( 'Undo last apply', 'localboost-ai' ); ?></button>
			<button type="button" class="button button-primary lbai-btn" id="lbai-opt-apply"><?php esc_html_e( 'Approve & apply', 'localboost-ai' ); ?></button>
		</div>
	</div>
</div>
