<?php
/**
 * Content generator view.
 *
 * AI content generation + transform actions + copy. Inserting into WordPress
 * is done through the normal editor ("Open in editor" carries the content
 * to a new draft via the browser).
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

$types = array(
	'service_page'        => __( 'Service page', 'localboost-ai' ),
	'location_page'       => __( 'Location page', 'localboost-ai' ),
	'faq'                 => __( 'FAQ section', 'localboost-ai' ),
	'about'               => __( 'About section', 'localboost-ai' ),
	'service_description' => __( 'Service description', 'localboost-ai' ),
	'landing_outline'     => __( 'Local landing page outline', 'localboost-ai' ),
	'blog_ideas'          => __( 'Blog article ideas', 'localboost-ai' ),
	'blog_outline'        => __( 'Blog outline', 'localboost-ai' ),
	'meta_description'    => __( 'Meta description', 'localboost-ai' ),
	'seo_title'           => __( 'SEO title', 'localboost-ai' ),
);

$languages = array(
	'en' => __( 'English', 'localboost-ai' ),
	'fr' => __( 'French', 'localboost-ai' ),
	'de' => __( 'German', 'localboost-ai' ),
	'es' => __( 'Spanish', 'localboost-ai' ),
	'it' => __( 'Italian', 'localboost-ai' ),
	'nl' => __( 'Dutch', 'localboost-ai' ),
	'pt' => __( 'Portuguese', 'localboost-ai' ),
);
?>
<div class="wrap lbai-wrap" data-lbai-page="content">
	<h1 class="lbai-page-title"><?php esc_html_e( 'Content', 'localboost-ai' ); ?></h1>
	<p class="lbai-page-subtitle"><?php esc_html_e( 'Generate genuinely useful, unique content for your business — then edit it before publishing.', 'localboost-ai' ); ?></p>

	<div class="notice notice-warning lbai-notice">
		<p>
			<strong><?php esc_html_e( 'Quality warning:', 'localboost-ai' ); ?></strong>
			<?php esc_html_e( 'Do not publish large numbers of near-identical location pages. Search engines penalize doorway pages. Every page you publish should be unique, accurate and genuinely useful to a visitor.', 'localboost-ai' ); ?>
		</p>
	</div>

	<div class="lbai-card">
		<h2 class="lbai-card__title"><?php esc_html_e( 'Generate content', 'localboost-ai' ); ?></h2>
		<form id="lbai-content-form" class="lbai-form-grid">
			<div class="lbai-field">
				<label for="lbai-content-type"><?php esc_html_e( 'Content type', 'localboost-ai' ); ?></label>
				<select id="lbai-content-type" name="type" class="lbai-select" required>
					<?php foreach ( $types as $key => $label ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<div class="lbai-field">
				<label for="lbai-content-topic"><?php esc_html_e( 'Topic / service', 'localboost-ai' ); ?></label>
				<input type="text" id="lbai-content-topic" name="topic" class="lbai-input" required maxlength="200" placeholder="<?php esc_attr_e( 'e.g. Emergency plumbing', 'localboost-ai' ); ?>" />
			</div>
			<div class="lbai-field">
				<label for="lbai-content-location"><?php esc_html_e( 'Location (optional)', 'localboost-ai' ); ?></label>
				<input type="text" id="lbai-content-location" name="location" class="lbai-input" maxlength="120" value="<?php echo esc_attr( get_option( 'lbai_city', '' ) ); ?>" />
			</div>
			<div class="lbai-field">
				<label for="lbai-content-lang"><?php esc_html_e( 'Language', 'localboost-ai' ); ?></label>
				<select id="lbai-content-lang" name="language" class="lbai-select">
					<?php foreach ( $languages as $key => $label ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>"<?php selected( 'en', $key ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<div class="lbai-field lbai-field--actions">
				<button type="submit" class="button button-primary lbai-btn" id="lbai-content-generate">
					<?php esc_html_e( 'Generate', 'localboost-ai' ); ?>
				</button>
			</div>
		</form>
		<p class="description" id="lbai-content-status" role="status"></p>
	</div>

	<div class="lbai-card" id="lbai-content-result-card" hidden>
		<h2 class="lbai-card__title"><?php esc_html_e( 'Result', 'localboost-ai' ); ?></h2>
		<label for="lbai-content-editor" class="screen-reader-text"><?php esc_html_e( 'Edit generated content', 'localboost-ai' ); ?></label>
		<textarea id="lbai-content-editor" class="lbai-textarea lbai-textarea--tall" rows="16"></textarea>

		<h3 class="lbai-subheading"><?php esc_html_e( 'Improve', 'localboost-ai' ); ?></h3>
		<div class="lbai-actions" role="group" aria-label="<?php esc_attr_e( 'Content actions', 'localboost-ai' ); ?>">
			<button type="button" class="button lbai-btn lbai-transform" data-action="shorten"><?php esc_html_e( 'Shorten', 'localboost-ai' ); ?></button>
			<button type="button" class="button lbai-btn lbai-transform" data-action="expand"><?php esc_html_e( 'Expand', 'localboost-ai' ); ?></button>
			<button type="button" class="button lbai-btn lbai-transform" data-action="readability"><?php esc_html_e( 'Improve readability', 'localboost-ai' ); ?></button>
			<button type="button" class="button lbai-btn lbai-transform" data-action="tone" data-arg="friendly"><?php esc_html_e( 'Friendlier tone', 'localboost-ai' ); ?></button>
			<button type="button" class="button lbai-btn lbai-transform" data-action="tone" data-arg="professional"><?php esc_html_e( 'Professional tone', 'localboost-ai' ); ?></button>
			<button type="button" class="button lbai-btn lbai-transform" data-action="translate" data-arg="fr"><?php esc_html_e( 'Translate to French', 'localboost-ai' ); ?></button>
		</div>

		<h3 class="lbai-subheading"><?php esc_html_e( 'Use it', 'localboost-ai' ); ?></h3>
		<div class="lbai-actions">
			<button type="button" class="button lbai-btn" id="lbai-content-regenerate"><?php esc_html_e( 'Regenerate', 'localboost-ai' ); ?></button>
			<button type="button" class="button lbai-btn" id="lbai-content-copy"><?php esc_html_e( 'Copy', 'localboost-ai' ); ?></button>
			<a class="button button-primary lbai-btn" id="lbai-content-open-editor" href="<?php echo esc_url( admin_url( 'post-new.php' ) ); ?>" target="_blank" rel="noopener">
				<?php esc_html_e( 'Open in editor', 'localboost-ai' ); ?>
			</a>
		</div>
		<p class="description">
			<?php esc_html_e( 'Copy the text, then paste it into a new page or post. Review and personalize it before publishing.', 'localboost-ai' ); ?>
		</p>
	</div>
</div>
