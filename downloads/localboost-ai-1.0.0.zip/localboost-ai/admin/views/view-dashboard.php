<?php
/**
 * Dashboard view.
 *
 * Stat cards are populated by JS via GET /lbai/v1/dashboard. The system
 * status section below is rendered server-side from real plugin data
 * (provider configuration, monitor status, usage counters, recent audits)
 * so it is always accurate, with explicit empty states — never blank
 * boxes or invented numbers.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

require_once plugin_dir_path( LBAI_PLUGIN_FILE ) . 'admin/views/partials/score-ring.php';

// ---- AI provider status (real data) ----
$provider_id    = (string) get_option( 'lbai_ai_provider', 'openai' );
$provider_label = $provider_id;
$requires_key   = true;
try {
	$provider_obj   = \LocalBoostAI\Providers\Provider_Factory::create( $provider_id );
	$provider_label = $provider_obj->get_label();
	$requires_key   = $provider_obj->requires_api_key();
} catch ( \Exception $e ) { // phpcs:ignore -- provider probe must never break the page.
	$provider_obj = null;
}
$has_key      = ! $requires_key || ( class_exists( '\LocalBoostAI\Includes\Secure_Store' ) && \LocalBoostAI\Includes\Secure_Store::has_api_key( $provider_id ) );
$current_model = (string) get_option( 'lbai_ai_model', '' );

// ---- Monitor status (real data) ----
$monitor = array();
if ( class_exists( '\LocalBoostAI\Services\Monitor' ) && method_exists( '\LocalBoostAI\Services\Monitor', 'get_status' ) ) {
	$monitor = \LocalBoostAI\Services\Monitor::get_status();
}
$monitor_freq   = isset( $monitor['frequency'] ) ? $monitor['frequency'] : 'off';
$monitor_status = isset( $monitor['status'] ) ? $monitor['status'] : 'never';
$monitor_badge  = 'lbai-badge-warning';
if ( 'ok' === $monitor_status ) {
	$monitor_badge = 'lbai-badge-passed';
} elseif ( 'failed' === $monitor_status ) {
	$monitor_badge = 'lbai-badge-critical';
}
$freq_labels = array(
	'off'     => __( 'Off', 'localboost-ai' ),
	'weekly'  => __( 'Weekly', 'localboost-ai' ),
	'monthly' => __( 'Monthly', 'localboost-ai' ),
);
$status_labels = array(
	'ok'      => __( 'OK', 'localboost-ai' ),
	'failed'  => __( 'Failed', 'localboost-ai' ),
	'skipped' => __( 'Skipped', 'localboost-ai' ),
	'never'   => __( 'Never ran', 'localboost-ai' ),
);

// ---- Usage reports (real data) ----
$feature_names = array(
	'ai_generation' => __( 'AI generations', 'localboost-ai' ),
	'audit'         => __( 'Audits', 'localboost-ai' ),
	'report'        => __( 'Reports', 'localboost-ai' ),
	'content'       => __( 'Content', 'localboost-ai' ),
);
$usage_reports = array();
if ( class_exists( '\LocalBoostAI\Includes\Usage_Tracker' ) ) {
	foreach ( array_keys( $feature_names ) as $feature ) {
		$usage_reports[ $feature ] = \LocalBoostAI\Includes\Usage_Tracker::get_usage_report( $feature );
	}
}

// ---- Recent audits (real data) ----
$recent_audits = array();
global $wpdb;
if ( isset( $wpdb ) ) {
	$recent_audits = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT id, post_id, url, score, created_at FROM {$wpdb->prefix}lbai_audits ORDER BY id DESC LIMIT %d",
			5
		),
		ARRAY_A
	);
}

$usage_note = __( 'AI generations this month', 'localboost-ai' );
?>
<div class="wrap lbai-wrap" data-lbai-page="dashboard">
	<h1 class="lbai-page-title"><?php esc_html_e( 'Dashboard', 'localboost-ai' ); ?></h1>
	<p class="lbai-page-subtitle"><?php esc_html_e( 'Your local SEO at a glance. This is the LocalBoost SEO Score — an internal health metric, not an official Google ranking score.', 'localboost-ai' ); ?></p>

	<div class="lbai-grid lbai-grid--stats" id="lbai-stats" aria-live="polite">
		<div class="lbai-card lbai-stat">
			<div class="lbai-stat__label"><?php esc_html_e( 'Overall SEO score', 'localboost-ai' ); ?></div>
			<div id="lbai-score-overall"><?php lbai_score_ring( 0 ); ?></div>
		</div>
		<div class="lbai-card lbai-stat">
			<div class="lbai-stat__label"><?php esc_html_e( 'Local SEO score', 'localboost-ai' ); ?></div>
			<div id="lbai-score-local"><?php lbai_score_ring( 0 ); ?></div>
		</div>
		<div class="lbai-card lbai-stat">
			<div class="lbai-stat__label"><?php esc_html_e( 'Critical issues', 'localboost-ai' ); ?></div>
			<div class="lbai-stat__value lbai-stat__value--critical" id="lbai-count-critical">–</div>
		</div>
		<div class="lbai-card lbai-stat">
			<div class="lbai-stat__label"><?php esc_html_e( 'Warnings', 'localboost-ai' ); ?></div>
			<div class="lbai-stat__value lbai-stat__value--warning" id="lbai-count-warning">–</div>
		</div>
		<div class="lbai-card lbai-stat">
			<div class="lbai-stat__label"><?php esc_html_e( 'Passed checks', 'localboost-ai' ); ?></div>
			<div class="lbai-stat__value lbai-stat__value--passed" id="lbai-count-passed">–</div>
		</div>
		<div class="lbai-card lbai-stat">
			<div class="lbai-stat__label"><?php esc_html_e( 'Pages analyzed', 'localboost-ai' ); ?></div>
			<div class="lbai-stat__value" id="lbai-count-pages">–</div>
		</div>
		<div class="lbai-card lbai-stat">
			<div class="lbai-stat__label"><?php echo esc_html( $usage_note ); ?></div>
			<div class="lbai-stat__value"><span id="lbai-usage-used">–</span> <span class="lbai-stat__suffix" id="lbai-usage-limit"></span></div>
			<div class="lbai-progress" role="progressbar" aria-label="<?php esc_attr_e( 'AI usage', 'localboost-ai' ); ?>" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" id="lbai-usage-bar-wrap">
				<div class="lbai-progress__fill" id="lbai-usage-bar" style="width:0%"></div>
			</div>
		</div>
	</div>

	<div class="lbai-grid lbai-grid--3col">
		<section class="lbai-card" aria-labelledby="lbai-dash-provider-title">
			<h2 class="lbai-card__title" id="lbai-dash-provider-title"><?php esc_html_e( 'AI provider', 'localboost-ai' ); ?></h2>
			<p><strong><?php echo esc_html( $provider_label ); ?></strong></p>
			<?php if ( '' !== $current_model ) : ?>
				<p class="description"><?php printf( esc_html__( 'Model: %s', 'localboost-ai' ), esc_html( $current_model ) ); ?></p>
			<?php endif; ?>
			<?php if ( ! $requires_key ) : ?>
				<p><span class="lbai-badge lbai-badge-passed"><?php esc_html_e( 'Keyless (self-hosted)', 'localboost-ai' ); ?></span></p>
			<?php elseif ( $has_key ) : ?>
				<p><span class="lbai-badge lbai-badge-passed"><?php esc_html_e( 'API key configured', 'localboost-ai' ); ?></span></p>
			<?php else : ?>
				<div class="notice notice-warning lbai-notice">
					<p><?php esc_html_e( 'No API key is configured for this provider. AI features will not work until you add one.', 'localboost-ai' ); ?></p>
				</div>
			<?php endif; ?>
			<p><a class="button lbai-btn" href="<?php echo esc_url( admin_url( 'admin.php?page=lbai-ai-settings' ) ); ?>"><?php esc_html_e( 'AI settings', 'localboost-ai' ); ?></a></p>
		</section>

		<section class="lbai-card" aria-labelledby="lbai-dash-monitor-title">
			<h2 class="lbai-card__title" id="lbai-dash-monitor-title"><?php esc_html_e( 'Monitoring', 'localboost-ai' ); ?></h2>
			<?php if ( 'off' === $monitor_freq ) : ?>
				<p class="lbai-list__empty"><?php esc_html_e( 'Automated monitoring is off. Turn it on to get scheduled audits.', 'localboost-ai' ); ?></p>
			<?php else : ?>
				<p>
					<span class="lbai-badge <?php echo esc_attr( $monitor_badge ); ?>"><?php echo esc_html( isset( $status_labels[ $monitor_status ] ) ? $status_labels[ $monitor_status ] : $monitor_status ); ?></span>
					<?php echo esc_html( isset( $freq_labels[ $monitor_freq ] ) ? $freq_labels[ $monitor_freq ] : $monitor_freq ); ?>
				</p>
				<ul class="lbai-list lbai-meta-list">
					<li>
						<span class="lbai-list__meta"><?php esc_html_e( 'Last run', 'localboost-ai' ); ?></span>
						<?php echo ! empty( $monitor['last_run'] ) ? esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $monitor['last_run'] ) ) : esc_html__( 'Never', 'localboost-ai' ); ?>
					</li>
					<li>
						<span class="lbai-list__meta"><?php esc_html_e( 'Next run', 'localboost-ai' ); ?></span>
						<?php echo ! empty( $monitor['next_run'] ) ? esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $monitor['next_run'] ) ) : esc_html__( 'Not scheduled', 'localboost-ai' ); ?>
					</li>
					<li>
						<span class="lbai-list__meta"><?php esc_html_e( 'Monitored pages', 'localboost-ai' ); ?></span>
						<?php echo esc_html( number_format_i18n( (int) ( isset( $monitor['monitored_pages'] ) ? $monitor['monitored_pages'] : 0 ) ) ); ?>
					</li>
				</ul>
				<?php if ( 'failed' === $monitor_status && ! empty( $monitor['error'] ) ) : ?>
					<div class="notice notice-error lbai-notice">
						<p><?php echo esc_html( $monitor['error'] ); ?></p>
					</div>
				<?php endif; ?>
			<?php endif; ?>
			<p><a class="button lbai-btn" href="<?php echo esc_url( admin_url( 'admin.php?page=lbai-settings' ) ); ?>"><?php esc_html_e( 'Monitoring settings', 'localboost-ai' ); ?></a></p>
		</section>

		<section class="lbai-card" aria-labelledby="lbai-dash-usage-title">
			<h2 class="lbai-card__title" id="lbai-dash-usage-title"><?php esc_html_e( 'Usage this month', 'localboost-ai' ); ?></h2>
			<?php if ( empty( $usage_reports ) ) : ?>
				<p class="lbai-list__empty"><?php esc_html_e( 'Usage tracking is not available.', 'localboost-ai' ); ?></p>
			<?php else : ?>
				<ul class="lbai-list">
					<?php foreach ( $usage_reports as $feature => $report ) :
						$quota     = (int) $report['quota'];
						$used      = (int) $report['successful'];
						$pct       = $quota > 0 ? min( 100, round( $used / $quota * 100 ) ) : 0;
						$exhausted = $quota >= 0 && $used >= $quota;
						?>
						<li>
							<div class="lbai-category-bar__head">
								<span><?php echo esc_html( $feature_names[ $feature ] ); ?></span>
								<span>
									<?php
									if ( $quota < 0 ) {
										printf( esc_html__( '%s (unlimited)', 'localboost-ai' ), esc_html( number_format_i18n( $used ) ) );
									} else {
										printf( esc_html__( '%1$s of %2$s used', 'localboost-ai' ), esc_html( number_format_i18n( $used ) ), esc_html( number_format_i18n( $quota ) ) );
									}
									?>
								</span>
							</div>
							<div class="lbai-progress" role="progressbar" aria-label="<?php echo esc_attr( $feature_names[ $feature ] ); ?>" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?php echo esc_attr( (string) $pct ); ?>">
								<div class="lbai-progress__fill" style="width:<?php echo esc_attr( (string) $pct ); ?>%"></div>
							</div>
							<?php if ( $exhausted ) : ?>
								<span class="lbai-list__meta lbai-stat__value--critical"><?php esc_html_e( 'Quota exhausted — AI features are paused until next month.', 'localboost-ai' ); ?></span>
							<?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</section>
	</div>

	<div class="lbai-grid lbai-grid--2col">
		<section class="lbai-card" aria-labelledby="lbai-dash-recent-title">
			<h2 class="lbai-card__title" id="lbai-dash-recent-title"><?php esc_html_e( 'Recent audits', 'localboost-ai' ); ?></h2>
			<?php if ( empty( $recent_audits ) ) : ?>
				<p class="lbai-list__empty">
					<?php esc_html_e( 'No audits yet. Run your first SEO audit to see your score here.', 'localboost-ai' ); ?>
				</p>
				<p><a class="button button-primary lbai-btn" href="<?php echo esc_url( admin_url( 'admin.php?page=lbai-audit' ) ); ?>"><?php esc_html_e( 'Run your first audit', 'localboost-ai' ); ?></a></p>
			<?php else : ?>
				<ul class="lbai-list">
					<?php foreach ( $recent_audits as $audit ) :
						$title = ! empty( $audit['post_id'] ) ? get_the_title( (int) $audit['post_id'] ) : '';
						if ( '' === $title ) {
							$title = ! empty( $audit['url'] ) ? $audit['url'] : sprintf( esc_html__( 'Audit #%d', 'localboost-ai' ), (int) $audit['id'] );
						}
						?>
						<li>
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=lbai-audit' ) ); ?>"><?php echo esc_html( $title ); ?></a>
							<span class="lbai-list__meta">
								<?php printf( esc_html__( 'Score %1$d · %2$s', 'localboost-ai' ), (int) $audit['score'], esc_html( date_i18n( get_option( 'date_format' ), strtotime( $audit['created_at'] ) ) ) ); ?>
							</span>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</section>

		<div class="lbai-card">
			<h2 class="lbai-card__title"><?php esc_html_e( 'Quick actions', 'localboost-ai' ); ?></h2>
			<div class="lbai-actions">
				<a class="button button-primary lbai-btn" href="<?php echo esc_url( admin_url( 'admin.php?page=lbai-audit' ) ); ?>">
					<?php esc_html_e( 'Run SEO audit', 'localboost-ai' ); ?>
				</a>
				<a class="button lbai-btn" href="<?php echo esc_url( admin_url( 'admin.php?page=lbai-optimizer' ) ); ?>">
					<?php esc_html_e( 'Optimize with AI', 'localboost-ai' ); ?>
				</a>
				<button type="button" class="button lbai-btn" id="lbai-quick-consistency">
					<?php esc_html_e( 'Check business info consistency', 'localboost-ai' ); ?>
				</button>
				<a class="button lbai-btn" href="<?php echo esc_url( admin_url( 'admin.php?page=lbai-reports' ) ); ?>">
					<?php esc_html_e( 'View reports', 'localboost-ai' ); ?>
				</a>
			</div>
			<div id="lbai-consistency-result" class="lbai-result" hidden></div>
		</div>
	</div>

	<div class="lbai-card">
		<h2 class="lbai-card__title"><?php esc_html_e( 'Recent improvements', 'localboost-ai' ); ?></h2>
		<ul class="lbai-list" id="lbai-improvements">
			<li class="lbai-list__empty"><?php esc_html_e( 'Loading…', 'localboost-ai' ); ?></li>
		</ul>
	</div>

	<div class="lbai-card">
		<h2 class="lbai-card__title"><?php esc_html_e( 'How the score is calculated', 'localboost-ai' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'The LocalBoost SEO Score combines five categories: Technical SEO (25%), On-page SEO (25%), Local SEO (25%), Content (15%) and Structured Data (10%). Each audit check contributes to its category; categories are weighted into a 0–100 score. Fixing critical issues moves the score the most.', 'localboost-ai' ); ?>
		</p>
	</div>
</div>
