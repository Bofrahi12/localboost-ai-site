<?php
/**
 * Keyword assistant view.
 *
 * Generates AI keyword ideas — clearly labelled as AI-generated ideas,
 * never presented as search-volume data.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

$languages = array(
	'en' => __( 'English', 'localboost-ai' ),
	'fr' => __( 'French', 'localboost-ai' ),
	'de' => __( 'German', 'localboost-ai' ),
	'es' => __( 'Spanish', 'localboost-ai' ),
	'it' => __( 'Italian', 'localboost-ai' ),
	'nl' => __( 'Dutch', 'localboost-ai' ),
	'pt' => __( 'Portuguese', 'localboost-ai' ),
);
?>
<div class="wrap lbai-wrap" data-lbai-page="keywords">
	<h1 class="lbai-page-title"><?php esc_html_e( 'Keywords', 'localboost-ai' ); ?></h1>
	<p class="lbai-page-subtitle"><?php esc_html_e( 'Local keyword ideas for your business. These are AI-generated ideas — no search volume data is claimed.', 'localboost-ai' ); ?></p>

	<div class="lbai-card">
		<h2 class="lbai-card__title"><?php esc_html_e( 'Find keyword ideas', 'localboost-ai' ); ?></h2>
		<form id="lbai-keywords-form" class="lbai-form-grid">
			<div class="lbai-field">
				<label for="lbai-kw-type"><?php esc_html_e( 'Business type', 'localboost-ai' ); ?></label>
				<input type="text" id="lbai-kw-type" name="business_type" class="lbai-input" required maxlength="120" value="<?php echo esc_attr( get_option( 'lbai_business_type', '' ) ); ?>" placeholder="<?php esc_attr_e( 'e.g. Dentist', 'localboost-ai' ); ?>" />
			</div>
			<div class="lbai-field">
				<label for="lbai-kw-service"><?php esc_html_e( 'Service', 'localboost-ai' ); ?></label>
				<input type="text" id="lbai-kw-service" name="service" class="lbai-input" required maxlength="120" placeholder="<?php esc_attr_e( 'e.g. Teeth whitening', 'localboost-ai' ); ?>" />
			</div>
			<div class="lbai-field">
				<label for="lbai-kw-city"><?php esc_html_e( 'City', 'localboost-ai' ); ?></label>
				<input type="text" id="lbai-kw-city" name="city" class="lbai-input" required maxlength="120" value="<?php echo esc_attr( get_option( 'lbai_city', '' ) ); ?>" />
			</div>
			<div class="lbai-field">
				<label for="lbai-kw-region"><?php esc_html_e( 'Region (optional)', 'localboost-ai' ); ?></label>
				<input type="text" id="lbai-kw-region" name="region" class="lbai-input" maxlength="120" value="<?php echo esc_attr( get_option( 'lbai_region', '' ) ); ?>" />
			</div>
			<div class="lbai-field">
				<label for="lbai-kw-country"><?php esc_html_e( 'Country (optional)', 'localboost-ai' ); ?></label>
				<input type="text" id="lbai-kw-country" name="country" class="lbai-input" maxlength="120" value="<?php echo esc_attr( get_option( 'lbai_country', '' ) ); ?>" />
			</div>
			<div class="lbai-field">
				<label for="lbai-kw-lang"><?php esc_html_e( 'Language', 'localboost-ai' ); ?></label>
				<select id="lbai-kw-lang" name="language" class="lbai-select">
					<?php foreach ( $languages as $key => $label ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>"<?php selected( 'en', $key ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<div class="lbai-field lbai-field--actions">
				<button type="submit" class="button button-primary lbai-btn" id="lbai-kw-generate">
					<?php esc_html_e( 'Generate keywords', 'localboost-ai' ); ?>
				</button>
			</div>
		</form>
		<p class="description" id="lbai-kw-status" role="status"></p>
	</div>

	<div class="lbai-result" id="lbai-kw-results" hidden aria-live="polite">
		<div class="notice notice-info lbai-notice">
			<p><?php esc_html_e( 'AI-generated ideas — no search volume data. Use them as a starting point for your content planning.', 'localboost-ai' ); ?></p>
		</div>
		<div class="lbai-grid lbai-grid--2col" id="lbai-kw-groups"></div>
	</div>
</div>
