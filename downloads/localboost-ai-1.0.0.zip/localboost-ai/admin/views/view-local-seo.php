<?php
/**
 * Local SEO view — business profile saved through the Settings API.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

$countries = array(
	'US' => __( 'United States', 'localboost-ai' ),
	'CA' => __( 'Canada', 'localboost-ai' ),
	'GB' => __( 'United Kingdom', 'localboost-ai' ),
	'FR' => __( 'France', 'localboost-ai' ),
	'DE' => __( 'Germany', 'localboost-ai' ),
	'ES' => __( 'Spain', 'localboost-ai' ),
	'IT' => __( 'Italy', 'localboost-ai' ),
	'NL' => __( 'Netherlands', 'localboost-ai' ),
	'BE' => __( 'Belgium', 'localboost-ai' ),
	'PT' => __( 'Portugal', 'localboost-ai' ),
);

$business_types = array(
	'Restaurant'          => __( 'Restaurant', 'localboost-ai' ),
	'Dentist'             => __( 'Dentist', 'localboost-ai' ),
	'Physician'           => __( 'Doctor', 'localboost-ai' ),
	'Attorney'            => __( 'Lawyer', 'localboost-ai' ),
	'RealEstateAgent'     => __( 'Real estate', 'localboost-ai' ),
	'HairSalon'           => __( 'Salon', 'localboost-ai' ),
	'HomeAndConstructionBusiness' => __( 'Contractor', 'localboost-ai' ),
	'Plumber'             => __( 'Plumber', 'localboost-ai' ),
	'Electrician'         => __( 'Electrician', 'localboost-ai' ),
	'CleaningService'     => __( 'Cleaning company', 'localboost-ai' ),
	'Store'               => __( 'Local shop', 'localboost-ai' ),
	'ProfessionalService' => __( 'Marketing agency', 'localboost-ai' ),
	'LocalBusiness'       => __( 'Other local business', 'localboost-ai' ),
);

$current_country = get_option( 'lbai_country', '' );
$current_type    = get_option( 'lbai_business_type', '' );

if ( ! function_exists( 'lbai_local_field' ) ) {
	/**
	 * Render a text field row for the business profile form.
	 *
	 * @param string $key   Option key.
	 * @param string $label Field label.
	 * @param string $type  Input type.
	 * @return void
	 */
	function lbai_local_field( $key, $label, $type = 'text' ) {
		$value = get_option( $key, '' );
		?>
		<tr>
			<th scope="row"><label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
			<td>
				<input type="<?php echo esc_attr( $type ); ?>" id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $value ); ?>" class="regular-text" />
			</td>
		</tr>
		<?php
	}
}
?>
<div class="wrap lbai-wrap" data-lbai-page="local">
	<h1 class="lbai-page-title"><?php esc_html_e( 'Local SEO', 'localboost-ai' ); ?></h1>
	<p class="lbai-page-subtitle"><?php esc_html_e( 'Tell search engines exactly who you are. This information powers your schema markup and the consistency checker.', 'localboost-ai' ); ?></p>

	<form method="post" action="options.php" class="lbai-form">
		<?php settings_fields( 'lbai_settings' ); ?>

		<div class="lbai-card">
			<h2 class="lbai-card__title"><?php esc_html_e( 'Business information', 'localboost-ai' ); ?></h2>
			<table class="form-table" role="presentation">
				<?php lbai_local_field( 'lbai_business_name', __( 'Business name', 'localboost-ai' ) ); ?>
				<tr>
					<th scope="row"><label for="lbai_business_type"><?php esc_html_e( 'Business type', 'localboost-ai' ); ?></label></th>
					<td>
						<select id="lbai_business_type" name="lbai_business_type" class="lbai-select">
							<option value=""><?php esc_html_e( '— Select —', 'localboost-ai' ); ?></option>
							<?php foreach ( $business_types as $key => $label ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>"<?php selected( $current_type, $key ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
				<?php
				lbai_local_field( 'lbai_address', __( 'Street address', 'localboost-ai' ) );
				lbai_local_field( 'lbai_city', __( 'City', 'localboost-ai' ) );
				lbai_local_field( 'lbai_region', __( 'State / Region', 'localboost-ai' ) );
				lbai_local_field( 'lbai_postal_code', __( 'Postal code', 'localboost-ai' ) );
				?>
				<tr>
					<th scope="row"><label for="lbai_country"><?php esc_html_e( 'Country', 'localboost-ai' ); ?></label></th>
					<td>
						<select id="lbai_country" name="lbai_country" class="lbai-select">
							<option value=""><?php esc_html_e( '— Select —', 'localboost-ai' ); ?></option>
							<?php foreach ( $countries as $code => $label ) : ?>
								<option value="<?php echo esc_attr( $code ); ?>"<?php selected( $current_country, $code ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
				<?php
				lbai_local_field( 'lbai_phone', __( 'Phone', 'localboost-ai' ), 'tel' );
				lbai_local_field( 'lbai_email', __( 'Email', 'localboost-ai' ), 'email' );
				lbai_local_field( 'lbai_website', __( 'Website', 'localboost-ai' ), 'url' );
				lbai_local_field( 'lbai_price_range', __( 'Price range (e.g. $$)', 'localboost-ai' ) );
				lbai_local_field( 'lbai_latitude', __( 'Latitude (optional)', 'localboost-ai' ) );
				lbai_local_field( 'lbai_longitude', __( 'Longitude (optional)', 'localboost-ai' ) );
				?>
				<tr>
					<th scope="row"><label for="lbai_hours"><?php esc_html_e( 'Opening hours', 'localboost-ai' ); ?></label></th>
					<td>
						<textarea id="lbai_hours" name="lbai_hours" rows="4" class="large-text" placeholder="<?php esc_attr_e( 'Mo-Fr 09:00-18:00', 'localboost-ai' ); ?>"><?php echo esc_textarea( get_option( 'lbai_hours', '' ) ); ?></textarea>
						<p class="description"><?php esc_html_e( 'One line per day range, in a format your customers understand.', 'localboost-ai' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="lbai_services"><?php esc_html_e( 'Services', 'localboost-ai' ); ?></label></th>
					<td>
						<textarea id="lbai_services" name="lbai_services" rows="4" class="large-text"><?php echo esc_textarea( get_option( 'lbai_services', '' ) ); ?></textarea>
						<p class="description"><?php esc_html_e( 'One service per line.', 'localboost-ai' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="lbai_social_profiles"><?php esc_html_e( 'Social profiles', 'localboost-ai' ); ?></label></th>
					<td>
						<textarea id="lbai_social_profiles" name="lbai_social_profiles" rows="4" class="large-text" placeholder="https://facebook.com/…"><?php echo esc_textarea( get_option( 'lbai_social_profiles', '' ) ); ?></textarea>
						<p class="description"><?php esc_html_e( 'One URL per line.', 'localboost-ai' ); ?></p>
					</td>
				</tr>
			</table>
		</div>

		<?php submit_button( __( 'Save business information', 'localboost-ai' ), 'primary', 'submit', false, array( 'class' => 'button button-primary lbai-btn' ) ); ?>
	</form>

	<div class="lbai-card">
		<h2 class="lbai-card__title"><?php esc_html_e( 'NAP consistency check', 'localboost-ai' ); ?></h2>
		<p class="description"><?php esc_html_e( 'Compare your saved business name, address and phone against what is actually published on your pages, and get exact corrections.', 'localboost-ai' ); ?></p>
		<button type="button" class="button lbai-btn" id="lbai-consistency-run"><?php esc_html_e( 'Check consistency', 'localboost-ai' ); ?></button>
		<div id="lbai-consistency-result" class="lbai-result" hidden></div>
	</div>
</div>
