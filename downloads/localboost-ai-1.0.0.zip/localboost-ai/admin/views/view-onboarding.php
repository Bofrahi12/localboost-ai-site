<?php
/**
 * Onboarding wizard view — 7 steps driven by JS + REST.
 *
 * Steps: 1 Welcome · 2 Business info · 3 Choose AI provider ·
 * 4 Connect API · 5 Run first scan · 6 Recommendations · 7 Finish.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

$providers = array();
if ( class_exists( '\LocalBoostAI\Providers\Provider_Factory' ) ) {
	$map = \LocalBoostAI\Providers\Provider_Factory::get_available_providers();
	foreach ( $map as $id => $class ) {
		if ( ! is_string( $class ) || ! class_exists( $class ) ) {
			continue;
		}
		if ( ! is_subclass_of( $class, '\LocalBoostAI\Providers\AI_Provider_Interface' ) ) {
			continue;
		}
		try {
			$instance = new $class( array( 'api_key' => '' ) );
			$providers[ $id ] = array(
				'label' => $instance->get_label(),
				'hint'  => $instance->get_setup_hint(),
			);
		} catch ( \Exception $e ) { // phpcs:ignore -- provider probe must never break the wizard.
			continue;
		}
	}
}

$recent = get_posts(
	array(
		'post_type'      => array( 'page', 'post' ),
		'post_status'    => 'publish',
		'posts_per_page' => 10,
		'orderby'        => 'modified',
		'order'          => 'DESC',
		'fields'         => 'ids',
	)
);
?>
<div class="wrap lbai-wrap lbai-onboarding" data-lbai-page="onboarding" data-lbai-providers="<?php echo esc_attr( wp_json_encode( $providers ) ); ?>">
	<div class="lbai-onboarding__card lbai-card">
		<div class="lbai-onboarding__brand">
			<span class="dashicons dashicons-chart-area" aria-hidden="true"></span>
			<strong>LocalBoost AI</strong>
		</div>
		<p class="lbai-onboarding__progress" id="lbai-ob-progress" role="status"></p>
		<div class="lbai-progress" role="progressbar" aria-label="<?php esc_attr_e( 'Setup progress', 'localboost-ai' ); ?>" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" id="lbai-ob-bar-wrap">
			<div class="lbai-progress__fill" id="lbai-ob-bar" style="width:0%"></div>
		</div>

		<!-- Step 1: Welcome -->
		<section class="lbai-ob-step" data-step="1">
			<h1><?php esc_html_e( 'Welcome to LocalBoost AI', 'localboost-ai' ); ?></h1>
			<p><?php esc_html_e( 'Your AI-powered local SEO assistant. In under 5 minutes you will connect an AI provider, scan your first page and get clear recommendations — no SEO knowledge required.', 'localboost-ai' ); ?></p>
			<ul class="lbai-checklist">
				<li><?php esc_html_e( 'Scan your website for SEO problems', 'localboost-ai' ); ?></li>
				<li><?php esc_html_e( 'Fix issues with AI — always with your approval', 'localboost-ai' ); ?></li>
				<li><?php esc_html_e( 'Keep your business information consistent', 'localboost-ai' ); ?></li>
			</ul>
			<button type="button" class="button button-primary lbai-btn lbai-ob-next"><?php esc_html_e( 'Get started', 'localboost-ai' ); ?></button>
		</section>

		<!-- Step 2: Business info -->
		<section class="lbai-ob-step" data-step="2" hidden>
			<h1><?php esc_html_e( 'Your business', 'localboost-ai' ); ?></h1>
			<p><?php esc_html_e( 'This information powers your local SEO, schema markup and consistency checks.', 'localboost-ai' ); ?></p>
			<div class="lbai-form-grid">
				<div class="lbai-field">
					<label for="lbai-ob-name"><?php esc_html_e( 'Business name', 'localboost-ai' ); ?></label>
					<input type="text" id="lbai-ob-name" class="lbai-input" required maxlength="120" />
				</div>
				<div class="lbai-field">
					<label for="lbai-ob-city"><?php esc_html_e( 'City', 'localboost-ai' ); ?></label>
					<input type="text" id="lbai-ob-city" class="lbai-input" required maxlength="120" />
				</div>
				<div class="lbai-field">
					<label for="lbai-ob-phone"><?php esc_html_e( 'Phone', 'localboost-ai' ); ?></label>
					<input type="tel" id="lbai-ob-phone" class="lbai-input" maxlength="40" />
				</div>
				<div class="lbai-field">
					<label for="lbai-ob-website"><?php esc_html_e( 'Website', 'localboost-ai' ); ?></label>
					<input type="url" id="lbai-ob-website" class="lbai-input" maxlength="200" value="<?php echo esc_attr( home_url() ); ?>" />
				</div>
			</div>
			<div class="lbai-ob-nav">
				<button type="button" class="button lbai-btn lbai-ob-prev"><?php esc_html_e( 'Back', 'localboost-ai' ); ?></button>
				<button type="button" class="button button-primary lbai-btn" id="lbai-ob-save-business"><?php esc_html_e( 'Save & continue', 'localboost-ai' ); ?></button>
			</div>
		</section>

		<!-- Step 3: Choose AI provider -->
		<section class="lbai-ob-step" data-step="3" hidden>
			<h1><?php esc_html_e( 'Choose your AI provider', 'localboost-ai' ); ?></h1>
			<p><?php esc_html_e( 'LocalBoost AI works with several providers. Pick the one you have an API key for — you can change this later.', 'localboost-ai' ); ?></p>
			<div class="lbai-provider-cards" role="radiogroup" aria-label="<?php esc_attr_e( 'AI provider', 'localboost-ai' ); ?>">
				<?php foreach ( $providers as $id => $info ) : ?>
					<label class="lbai-provider-card">
						<input type="radio" name="lbai_ob_provider" value="<?php echo esc_attr( $id ); ?>" />
						<span class="lbai-provider-card__name"><?php echo esc_html( $info['label'] ); ?></span>
						<?php if ( ! empty( $info['hint'] ) ) : ?>
							<span class="lbai-provider-card__desc"><?php echo esc_html( $info['hint'] ); ?></span>
						<?php endif; ?>
					</label>
				<?php endforeach; ?>
			</div>
			<div class="lbai-ob-nav">
				<button type="button" class="button lbai-btn lbai-ob-prev"><?php esc_html_e( 'Back', 'localboost-ai' ); ?></button>
				<button type="button" class="button button-primary lbai-btn lbai-ob-next" id="lbai-ob-provider-next" disabled><?php esc_html_e( 'Continue', 'localboost-ai' ); ?></button>
			</div>
		</section>

		<!-- Step 4: Connect API -->
		<section class="lbai-ob-step" data-step="4" hidden>
			<h1><?php esc_html_e( 'Connect your AI provider', 'localboost-ai' ); ?></h1>
			<p id="lbai-ob-key-desc"
				data-lbai-with-key="<?php esc_attr_e( 'Paste the API key from your provider. It is stored encrypted on your server and never shown again.', 'localboost-ai' ); ?>"
				data-lbai-no-key="<?php esc_attr_e( 'This provider runs on your own server and needs no API key. Just click “Connect & test” to verify it is reachable.', 'localboost-ai' ); ?>"
			><?php esc_html_e( 'Paste the API key from your provider. It is stored encrypted on your server and never shown again.', 'localboost-ai' ); ?></p>
			<label for="lbai-ob-key" class="screen-reader-text"><?php esc_html_e( 'API key', 'localboost-ai' ); ?></label>
			<input type="password" id="lbai-ob-key" class="lbai-input" autocomplete="new-password" placeholder="<?php esc_attr_e( 'Paste your API key', 'localboost-ai' ); ?>" />
			<p class="description" id="lbai-ob-key-status" role="status"></p>
			<div class="lbai-ob-nav">
				<button type="button" class="button lbai-btn lbai-ob-prev"><?php esc_html_e( 'Back', 'localboost-ai' ); ?></button>
				<button type="button" class="button lbai-btn" id="lbai-ob-skip-key"><?php esc_html_e( 'Skip for now', 'localboost-ai' ); ?></button>
				<button type="button" class="button button-primary lbai-btn" id="lbai-ob-test-key"><?php esc_html_e( 'Connect & test', 'localboost-ai' ); ?></button>
			</div>
		</section>

		<!-- Step 5: First scan -->
		<section class="lbai-ob-step" data-step="5" hidden>
			<h1><?php esc_html_e( 'Run your first scan', 'localboost-ai' ); ?></h1>
			<p><?php esc_html_e( 'Pick your most important page — usually your homepage — and we will analyze it.', 'localboost-ai' ); ?></p>
			<div class="lbai-form-inline">
				<label for="lbai-ob-post" class="screen-reader-text"><?php esc_html_e( 'Choose a page to scan', 'localboost-ai' ); ?></label>
				<select id="lbai-ob-post" class="lbai-select">
					<?php foreach ( $recent as $post_id ) : ?>
						<option value="<?php echo esc_attr( (string) $post_id ); ?>"><?php echo esc_html( get_the_title( $post_id ) ); ?></option>
					<?php endforeach; ?>
				</select>
				<button type="button" class="button button-primary lbai-btn" id="lbai-ob-run-scan"><?php esc_html_e( 'Scan page', 'localboost-ai' ); ?></button>
			</div>
			<p class="description" id="lbai-ob-scan-status" role="status"></p>
			<div class="lbai-ob-nav">
				<button type="button" class="button lbai-btn lbai-ob-prev"><?php esc_html_e( 'Back', 'localboost-ai' ); ?></button>
			</div>
		</section>

		<!-- Step 6: Recommendations -->
		<section class="lbai-ob-step" data-step="6" hidden>
			<h1><?php esc_html_e( 'Your first recommendations', 'localboost-ai' ); ?></h1>
			<p><?php esc_html_e( 'Here are the most important findings. Fix them any time from the SEO Audit page — each issue has a “Fix with AI” button.', 'localboost-ai' ); ?></p>
			<ul class="lbai-list" id="lbai-ob-issues"></ul>
			<div class="lbai-ob-nav">
				<button type="button" class="button lbai-btn lbai-ob-prev"><?php esc_html_e( 'Back', 'localboost-ai' ); ?></button>
				<button type="button" class="button button-primary lbai-btn lbai-ob-next"><?php esc_html_e( 'Continue', 'localboost-ai' ); ?></button>
			</div>
		</section>

		<!-- Step 7: Finish -->
		<section class="lbai-ob-step" data-step="7" hidden>
			<h1><?php esc_html_e( 'You’re all set!', 'localboost-ai' ); ?></h1>
			<p><?php esc_html_e( 'LocalBoost AI is ready. Explore your dashboard, run full audits and let AI improve your pages — always with your approval.', 'localboost-ai' ); ?></p>
			<button type="button" class="button button-primary lbai-btn" id="lbai-ob-finish"><?php esc_html_e( 'Go to dashboard', 'localboost-ai' ); ?></button>
		</section>
	</div>
</div>
