<?php
/**
 * AI Optimizer view.
 *
 * Generate AI improvements with a CURRENT vs AI SUGGESTION preview modal.
 * Nothing is applied without explicit approval.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

$recent = get_posts(
	array(
		'post_type'      => array( 'page', 'post' ),
		'post_status'    => array( 'publish', 'draft' ),
		'posts_per_page' => 20,
		'orderby'        => 'modified',
		'order'          => 'DESC',
		'fields'         => 'ids',
	)
);

$fields = array(
	'title'            => __( 'SEO title', 'localboost-ai' ),
	'meta_description' => __( 'Meta description', 'localboost-ai' ),
	'h1'               => __( 'H1 heading', 'localboost-ai' ),
	'introduction'     => __( 'Introduction', 'localboost-ai' ),
	'faq'              => __( 'FAQ section', 'localboost-ai' ),
	'cta'              => __( 'Call to action', 'localboost-ai' ),
	'alt_texts'        => __( 'Image alt texts', 'localboost-ai' ),
	'internal_links'   => __( 'Internal links', 'localboost-ai' ),
);

$languages = array(
	'en' => __( 'English', 'localboost-ai' ),
	'fr' => __( 'French', 'localboost-ai' ),
	'de' => __( 'German', 'localboost-ai' ),
	'es' => __( 'Spanish', 'localboost-ai' ),
	'it' => __( 'Italian', 'localboost-ai' ),
	'nl' => __( 'Dutch', 'localboost-ai' ),
	'pt' => __( 'Portuguese', 'localboost-ai' ),
);
?>
<div class="wrap lbai-wrap" data-lbai-page="optimizer">
	<h1 class="lbai-page-title"><?php esc_html_e( 'AI Optimizer', 'localboost-ai' ); ?></h1>
	<p class="lbai-page-subtitle"><?php esc_html_e( 'Let AI improve one element at a time. You always review the suggestion before anything changes.', 'localboost-ai' ); ?></p>

	<div class="lbai-card">
		<h2 class="lbai-card__title"><?php esc_html_e( 'Generate an improvement', 'localboost-ai' ); ?></h2>
		<form id="lbai-optimizer-form" class="lbai-form-grid">
			<div class="lbai-field">
				<label for="lbai-opt-post"><?php esc_html_e( 'Page or post', 'localboost-ai' ); ?></label>
				<select id="lbai-opt-post" name="post_id" class="lbai-select" required>
					<option value=""><?php esc_html_e( '— Select —', 'localboost-ai' ); ?></option>
					<?php foreach ( $recent as $post_id ) : ?>
						<option value="<?php echo esc_attr( (string) $post_id ); ?>" data-apply-nonce="<?php echo esc_attr( wp_create_nonce( 'lbai_apply_' . $post_id ) ); ?>">
							<?php echo esc_html( get_the_title( $post_id ) . ' (' . get_post_type( $post_id ) . ')' ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</div>
			<div class="lbai-field">
				<label for="lbai-opt-field"><?php esc_html_e( 'What to improve', 'localboost-ai' ); ?></label>
				<select id="lbai-opt-field" name="field" class="lbai-select" required>
					<?php foreach ( $fields as $key => $label ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<div class="lbai-field">
				<label for="lbai-opt-lang"><?php esc_html_e( 'Language', 'localboost-ai' ); ?></label>
				<select id="lbai-opt-lang" name="language" class="lbai-select">
					<?php foreach ( $languages as $key => $label ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>"<?php selected( 'en', $key ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<div class="lbai-field lbai-field--actions">
				<button type="submit" class="button button-primary lbai-btn" id="lbai-opt-generate">
					<?php esc_html_e( 'Generate suggestion', 'localboost-ai' ); ?>
				</button>
			</div>
		</form>
		<p class="description" id="lbai-opt-status" role="status"></p>
	</div>

	<div class="lbai-card">
		<h2 class="lbai-card__title"><?php esc_html_e( 'One-click actions', 'localboost-ai' ); ?></h2>
		<p class="description"><?php esc_html_e( 'Pick a page above, then run a single action. Each result opens in the review dialog.', 'localboost-ai' ); ?></p>
		<div class="lbai-actions">
			<button type="button" class="button lbai-btn lbai-quick-action" data-field="title"><?php esc_html_e( 'Improve title', 'localboost-ai' ); ?></button>
			<button type="button" class="button lbai-btn lbai-quick-action" data-field="meta_description"><?php esc_html_e( 'Generate meta description', 'localboost-ai' ); ?></button>
			<button type="button" class="button lbai-btn lbai-quick-action" data-field="faq"><?php esc_html_e( 'Generate FAQ', 'localboost-ai' ); ?></button>
			<button type="button" class="button lbai-btn lbai-quick-action" data-field="introduction"><?php esc_html_e( 'Optimize content', 'localboost-ai' ); ?></button>
		</div>
	</div>
</div>

<div class="lbai-modal" id="lbai-opt-modal" role="dialog" aria-modal="true" aria-labelledby="lbai-opt-modal-title" hidden>
	<div class="lbai-modal__backdrop" data-lbai-modal-close></div>
	<div class="lbai-modal__box">
		<div class="lbai-modal__header">
			<h2 id="lbai-opt-modal-title"><?php esc_html_e( 'Review AI suggestion', 'localboost-ai' ); ?></h2>
			<button type="button" class="lbai-modal__close" data-lbai-modal-close aria-label="<?php esc_attr_e( 'Close dialog', 'localboost-ai' ); ?>">×</button>
		</div>
		<div class="lbai-diff">
			<div class="lbai-diff__col">
				<h3><?php esc_html_e( 'Current', 'localboost-ai' ); ?></h3>
				<div class="lbai-diff__content" id="lbai-opt-current"></div>
			</div>
			<div class="lbai-diff__col">
				<h3><?php esc_html_e( 'AI suggestion', 'localboost-ai' ); ?></h3>
				<div class="lbai-diff__content" id="lbai-opt-suggestion"></div>
			</div>
		</div>
		<div class="lbai-form-inline lbai-modal__placement" id="lbai-opt-placement-wrap" hidden>
			<label for="lbai-opt-placement"><?php esc_html_e( 'Insert as', 'localboost-ai' ); ?></label>
			<select id="lbai-opt-placement" class="lbai-select">
				<option value="prepend"><?php esc_html_e( 'Insert at the beginning', 'localboost-ai' ); ?></option>
				<option value="append"><?php esc_html_e( 'Insert at the end', 'localboost-ai' ); ?></option>
			</select>
		</div>
		<p class="description" id="lbai-opt-apply-note"><?php esc_html_e( 'Content fields are inserted only with explicit placement. Image alt texts update existing images automatically; internal link suggestions are guidance for the editor.', 'localboost-ai' ); ?></p>
		<div class="lbai-modal__footer">
			<button type="button" class="button lbai-btn" data-lbai-modal-close><?php esc_html_e( 'Discard', 'localboost-ai' ); ?></button>
			<button type="button" class="button lbai-btn" id="lbai-opt-undo" hidden><?php esc_html_e( 'Undo last apply', 'localboost-ai' ); ?></button>
			<button type="button" class="button button-primary lbai-btn" id="lbai-opt-apply"><?php esc_html_e( 'Approve & apply', 'localboost-ai' ); ?></button>
		</div>
	</div>
</div>
