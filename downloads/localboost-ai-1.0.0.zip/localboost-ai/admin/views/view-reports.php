<?php
/**
 * Reports view — agency-friendly summaries with CSV export.
 *
 * White-label controls are Pro-gated honestly: disabled inputs with a note
 * when Licensing::is_pro() is false.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

$is_pro = class_exists( '\LocalBoostAI\Includes\Licensing' )
	? \LocalBoostAI\Includes\Licensing::is_pro()
	: false;
?>
<div class="wrap lbai-wrap" data-lbai-page="reports">
	<h1 class="lbai-page-title"><?php esc_html_e( 'Reports', 'localboost-ai' ); ?></h1>
	<p class="lbai-page-subtitle"><?php esc_html_e( 'A clean summary of your SEO progress — ready to share with clients.', 'localboost-ai' ); ?></p>

	<div class="lbai-grid lbai-grid--stats" id="lbai-report-stats" aria-live="polite">
		<div class="lbai-card lbai-stat">
			<div class="lbai-stat__label"><?php esc_html_e( 'Current score', 'localboost-ai' ); ?></div>
			<div class="lbai-stat__value" id="lbai-rep-score">–</div>
		</div>
		<div class="lbai-card lbai-stat">
			<div class="lbai-stat__label"><?php esc_html_e( 'Issues fixed', 'localboost-ai' ); ?></div>
			<div class="lbai-stat__value lbai-stat__value--passed" id="lbai-rep-fixed">–</div>
		</div>
		<div class="lbai-card lbai-stat">
			<div class="lbai-stat__label"><?php esc_html_e( 'Issues remaining', 'localboost-ai' ); ?></div>
			<div class="lbai-stat__value lbai-stat__value--warning" id="lbai-rep-remaining">–</div>
		</div>
		<div class="lbai-card lbai-stat">
			<div class="lbai-stat__label"><?php esc_html_e( 'Pages analyzed', 'localboost-ai' ); ?></div>
			<div class="lbai-stat__value" id="lbai-rep-pages">–</div>
		</div>
		<div class="lbai-card lbai-stat">
			<div class="lbai-stat__label"><?php esc_html_e( 'AI generations', 'localboost-ai' ); ?></div>
			<div class="lbai-stat__value" id="lbai-rep-ai">–</div>
		</div>
	</div>

	<div class="lbai-card">
		<h2 class="lbai-card__title"><?php esc_html_e( 'AI usage this month', 'localboost-ai' ); ?></h2>
		<?php
		$lbai_usage_features = array(
			'ai_generation' => __( 'AI generations', 'localboost-ai' ),
			'audit'         => __( 'Audits', 'localboost-ai' ),
			'report'        => __( 'Reports', 'localboost-ai' ),
			'content'       => __( 'Content', 'localboost-ai' ),
		);
		?>
		<?php if ( ! class_exists( '\LocalBoostAI\Includes\Usage_Tracker' ) ) : ?>
			<p class="lbai-list__empty"><?php esc_html_e( 'Usage tracking is not available.', 'localboost-ai' ); ?></p>
		<?php else :
			$lbai_any_usage = false;
			$lbai_usage_rows = array();
			foreach ( $lbai_usage_features as $lbai_feature => $lbai_feature_name ) {
				$lbai_rep = \LocalBoostAI\Includes\Usage_Tracker::get_usage_report( $lbai_feature );
				if ( (int) $lbai_rep['requests'] > 0 ) {
					$lbai_any_usage = true;
				}
				$lbai_usage_rows[ $lbai_feature ] = $lbai_rep;
			}
			?>
			<?php if ( ! $lbai_any_usage ) : ?>
				<p class="lbai-list__empty"><?php esc_html_e( 'No AI usage recorded this month yet. Usage appears here after your first audit or generation.', 'localboost-ai' ); ?></p>
			<?php endif; ?>
			<table class="wp-list-table widefat fixed striped lbai-table">
				<thead>
					<tr>
						<th scope="col"><?php esc_html_e( 'Feature', 'localboost-ai' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Requests', 'localboost-ai' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Successful', 'localboost-ai' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Failed', 'localboost-ai' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Tokens', 'localboost-ai' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $lbai_usage_rows as $lbai_feature => $lbai_rep ) : ?>
						<tr>
							<th scope="row"><?php echo esc_html( $lbai_usage_features[ $lbai_feature ] ); ?></th>
							<td><?php echo esc_html( number_format_i18n( (int) $lbai_rep['requests'] ) ); ?></td>
							<td><?php echo esc_html( number_format_i18n( (int) $lbai_rep['successful'] ) ); ?></td>
							<td><?php echo esc_html( number_format_i18n( (int) $lbai_rep['failed'] ) ); ?></td>
							<td><?php echo esc_html( number_format_i18n( (int) $lbai_rep['tokens_total'] ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
	</div>

	<div class="lbai-card">
		<h2 class="lbai-card__title"><?php esc_html_e( 'Score history', 'localboost-ai' ); ?></h2>
		<ul class="lbai-list" id="lbai-rep-history">
			<li class="lbai-list__empty"><?php esc_html_e( 'Loading…', 'localboost-ai' ); ?></li>
		</ul>
	</div>

	<div class="lbai-card">
		<h2 class="lbai-card__title"><?php esc_html_e( 'Improvements made', 'localboost-ai' ); ?></h2>
		<ul class="lbai-list" id="lbai-rep-improvements">
			<li class="lbai-list__empty"><?php esc_html_e( 'Loading…', 'localboost-ai' ); ?></li>
		</ul>
	</div>

	<div class="lbai-card">
		<h2 class="lbai-card__title"><?php esc_html_e( 'Export', 'localboost-ai' ); ?></h2>
		<p class="description"><?php esc_html_e( 'Download a CSV file you can open in any spreadsheet app.', 'localboost-ai' ); ?></p>
		<div class="lbai-actions">
			<button type="button" class="button lbai-btn" data-lbai-export="audits"><?php esc_html_e( 'Export audits (CSV)', 'localboost-ai' ); ?></button>
			<button type="button" class="button lbai-btn" data-lbai-export="usage"><?php esc_html_e( 'Export AI usage (CSV)', 'localboost-ai' ); ?></button>
		</div>
		<p class="description"><?php esc_html_e( 'PDF export is planned for a future release.', 'localboost-ai' ); ?></p>
	</div>

	<div class="lbai-card">
		<h2 class="lbai-card__title">
			<?php esc_html_e( 'White label', 'localboost-ai' ); ?>
			<?php if ( $is_pro ) : ?>
				<span class="lbai-badge lbai-badge-passed"><?php esc_html_e( 'Pro', 'localboost-ai' ); ?></span>
			<?php else : ?>
				<span class="lbai-badge lbai-badge-warning"><?php esc_html_e( 'Pro only', 'localboost-ai' ); ?></span>
			<?php endif; ?>
		</h2>
		<?php if ( ! $is_pro ) : ?>
			<p class="description">
				<?php
				printf(
					/* translators: %s: Upgrade page URL */
					esc_html__( 'White-label reports are a Pro feature. %s to unlock your agency branding.', 'localboost-ai' ),
					'<a href="' . esc_url( admin_url( 'admin.php?page=lbai-upgrade' ) ) . '">' . esc_html__( 'Upgrade', 'localboost-ai' ) . '</a>'
				);
				?>
			</p>
		<?php endif; ?>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="lbai_white_label_name"><?php esc_html_e( 'Agency name', 'localboost-ai' ); ?></label></th>
				<td><input type="text" id="lbai_white_label_name" class="regular-text" value="<?php echo esc_attr( get_option( 'lbai_white_label_name', '' ) ); ?>"<?php disabled( ! $is_pro ); ?> /></td>
			</tr>
			<tr>
				<th scope="row"><label for="lbai_white_label_logo"><?php esc_html_e( 'Logo URL', 'localboost-ai' ); ?></label></th>
				<td><input type="url" id="lbai_white_label_logo" class="regular-text" value="<?php echo esc_attr( get_option( 'lbai_white_label_logo', '' ) ); ?>"<?php disabled( ! $is_pro ); ?> /></td>
			</tr>
		</table>
		<?php if ( $is_pro ) : ?>
			<button type="button" class="button button-primary lbai-btn" id="lbai-whitelabel-save"><?php esc_html_e( 'Save branding', 'localboost-ai' ); ?></button>
			<p class="description" id="lbai-whitelabel-status" role="status"></p>
		<?php endif; ?>
	</div>
</div>
