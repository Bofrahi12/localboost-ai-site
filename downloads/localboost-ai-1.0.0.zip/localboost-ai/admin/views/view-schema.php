<?php
/**
 * Schema view — preview and enable JSON-LD structured data.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

$schema_types = array(
	'LocalBusiness'  => __( 'LocalBusiness (auto-detects subtype from business type)', 'localboost-ai' ),
	'Organization'   => __( 'Organization', 'localboost-ai' ),
	'Service'        => __( 'Service', 'localboost-ai' ),
	'FAQPage'        => __( 'FAQPage', 'localboost-ai' ),
	'BreadcrumbList' => __( 'BreadcrumbList', 'localboost-ai' ),
);
?>
<div class="wrap lbai-wrap" data-lbai-page="schema">
	<h1 class="lbai-page-title"><?php esc_html_e( 'Schema', 'localboost-ai' ); ?></h1>
	<p class="lbai-page-subtitle"><?php esc_html_e( 'Preview the exact JSON-LD markup before it goes live. Only valid, non-misleading schema is generated.', 'localboost-ai' ); ?></p>

	<div class="lbai-card">
		<h2 class="lbai-card__title"><?php esc_html_e( 'Schema types', 'localboost-ai' ); ?></h2>
		<fieldset>
			<legend class="screen-reader-text"><?php esc_html_e( 'Select schema types to enable', 'localboost-ai' ); ?></legend>
			<?php foreach ( $schema_types as $key => $label ) : ?>
				<label class="lbai-checkbox">
					<input type="checkbox" class="lbai-schema-type" value="<?php echo esc_attr( $key ); ?>" />
					<?php echo esc_html( $label ); ?>
				</label>
			<?php endforeach; ?>
		</fieldset>
		<div class="lbai-form-inline" style="margin-top: 1rem;">
			<label for="lbai-schema-preview-type" class="screen-reader-text"><?php esc_html_e( 'Schema type to preview', 'localboost-ai' ); ?></label>
			<select id="lbai-schema-preview-type" class="lbai-select">
				<?php foreach ( array_keys( $schema_types ) as $key ) : ?>
					<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $key ); ?></option>
				<?php endforeach; ?>
			</select>
			<button type="button" class="button lbai-btn" id="lbai-schema-preview-btn">
				<?php esc_html_e( 'Preview JSON-LD', 'localboost-ai' ); ?>
			</button>
		</div>
	</div>

	<div class="lbai-card" id="lbai-schema-preview-card" hidden>
		<h2 class="lbai-card__title"><?php esc_html_e( 'JSON-LD preview', 'localboost-ai' ); ?></h2>
		<pre class="lbai-code" id="lbai-schema-preview" tabindex="0" aria-live="polite"></pre>
		<div id="lbai-schema-errors" class="lbai-result" hidden></div>
		<p class="description">
			<?php esc_html_e( 'Validate this markup with Google’s Rich Results Test before enabling it on your live site.', 'localboost-ai' ); ?>
		</p>
	</div>

	<div class="lbai-card">
		<h2 class="lbai-card__title"><?php esc_html_e( 'Activation', 'localboost-ai' ); ?></h2>
		<label class="lbai-checkbox">
			<input type="checkbox" id="lbai-schema-enabled" />
			<?php esc_html_e( 'Output schema markup in the site header', 'localboost-ai' ); ?>
		</label>
		<p>
			<button type="button" class="button button-primary lbai-btn" id="lbai-schema-save">
				<?php esc_html_e( 'Generate schema', 'localboost-ai' ); ?>
			</button>
		</p>
		<p class="description" id="lbai-schema-status" role="status"></p>
	</div>
</div>
