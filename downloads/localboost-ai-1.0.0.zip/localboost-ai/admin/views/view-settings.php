<?php
/**
 * General settings view — monitoring, notifications, privacy/data tools.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

$frequencies = array(
	'off'     => __( 'Off', 'localboost-ai' ),
	'weekly'  => __( 'Weekly', 'localboost-ai' ),
	'monthly' => __( 'Monthly', 'localboost-ai' ),
);
$current_freq = get_option( 'lbai_monitor_frequency', 'off' );

$pages = get_posts(
	array(
		'post_type'      => array( 'page', 'post' ),
		'post_status'    => 'publish',
		'posts_per_page' => 50,
		'orderby'        => 'title',
		'order'          => 'ASC',
		'fields'         => 'ids',
	)
);
$monitored = get_option( 'lbai_monitored_pages', array() );
if ( ! is_array( $monitored ) ) {
	$monitored = array();
}

if ( ! function_exists( 'lbai_notify_checkbox' ) ) {
	/**
	 * Render a notification toggle row.
	 *
	 * @param string $key   Option key.
	 * @param string $label Label text.
	 * @return void
	 */
	function lbai_notify_checkbox( $key, $label ) {
		?>
		<tr>
			<th scope="row"><?php echo esc_html( $label ); ?></th>
			<td>
				<label>
					<input type="checkbox" name="<?php echo esc_attr( $key ); ?>" value="1"<?php checked( get_option( $key, true ), true ); ?> />
					<?php esc_html_e( 'Enabled', 'localboost-ai' ); ?>
				</label>
			</td>
		</tr>
		<?php
	}
}
?>
<div class="wrap lbai-wrap" data-lbai-page="settings">
	<h1 class="lbai-page-title"><?php esc_html_e( 'Settings', 'localboost-ai' ); ?></h1>
	<p class="lbai-page-subtitle"><?php esc_html_e( 'Monitoring, notifications and your data.', 'localboost-ai' ); ?></p>

	<form method="post" action="options.php" class="lbai-form">
		<?php settings_fields( 'lbai_settings' ); ?>

		<div class="lbai-card">
			<h2 class="lbai-card__title"><?php esc_html_e( 'Automated monitoring', 'localboost-ai' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="lbai_monitor_frequency"><?php esc_html_e( 'Audit frequency', 'localboost-ai' ); ?></label></th>
					<td>
						<select id="lbai_monitor_frequency" name="lbai_monitor_frequency" class="lbai-select">
							<?php foreach ( $frequencies as $key => $label ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>"<?php selected( $current_freq, $key ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'Scheduled audits run quietly via WP-Cron and notify you about new issues. Never more than one job per schedule.', 'localboost-ai' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="lbai_monitored_pages"><?php esc_html_e( 'Monitored pages', 'localboost-ai' ); ?></label></th>
					<td>
						<select id="lbai_monitored_pages" name="lbai_monitored_pages[]" class="lbai-select" multiple size="8">
							<?php foreach ( $pages as $post_id ) : ?>
								<option value="<?php echo esc_attr( (string) $post_id ); ?>"<?php echo in_array( $post_id, $monitored, true ) ? ' selected' : ''; ?>>
									<?php echo esc_html( get_the_title( $post_id ) ); ?>
								</option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'Hold Ctrl/Cmd to select multiple pages.', 'localboost-ai' ); ?></p>
					</td>
				</tr>
			</table>
		</div>

		<div class="lbai-card">
			<h2 class="lbai-card__title"><?php esc_html_e( 'Email notifications', 'localboost-ai' ); ?></h2>
			<table class="form-table" role="presentation">
				<?php
				lbai_notify_checkbox( 'lbai_notify_audit_completed', __( 'Audit completed', 'localboost-ai' ) );
				lbai_notify_checkbox( 'lbai_notify_critical_issue', __( 'Critical SEO issue detected', 'localboost-ai' ) );
				lbai_notify_checkbox( 'lbai_notify_report_ready', __( 'Scheduled report ready', 'localboost-ai' ) );
				lbai_notify_checkbox( 'lbai_notify_usage_limit', __( 'Usage limit reached', 'localboost-ai' ) );
				?>
			</table>
			<p class="description"><?php esc_html_e( 'Notifications are sent to the site administrator email address.', 'localboost-ai' ); ?></p>
		</div>

		<?php submit_button( __( 'Save settings', 'localboost-ai' ), 'primary', 'submit', false, array( 'class' => 'button button-primary lbai-btn' ) ); ?>
	</form>

	<?php
	// Read-only status panels: rendered from real plugin data, never saved here.
	$lbai_monitor_status = array();
	if ( class_exists( '\LocalBoostAI\Services\Monitor' ) && method_exists( '\LocalBoostAI\Services\Monitor', 'get_status' ) ) {
		$lbai_monitor_status = \LocalBoostAI\Services\Monitor::get_status();
	}
	$lbai_usage_features = array(
		'ai_generation' => __( 'AI generations', 'localboost-ai' ),
		'audit'         => __( 'Audits', 'localboost-ai' ),
		'report'        => __( 'Reports', 'localboost-ai' ),
		'content'       => __( 'Content', 'localboost-ai' ),
	);
	$lbai_status_labels = array(
		'ok'      => __( 'OK', 'localboost-ai' ),
		'failed'  => __( 'Failed', 'localboost-ai' ),
		'skipped' => __( 'Skipped', 'localboost-ai' ),
		'never'   => __( 'Never ran', 'localboost-ai' ),
	);
	$lbai_freq_labels = array(
		'off'     => __( 'Off', 'localboost-ai' ),
		'weekly'  => __( 'Weekly', 'localboost-ai' ),
		'monthly' => __( 'Monthly', 'localboost-ai' ),
	);
	?>

	<div class="lbai-card">
		<h2 class="lbai-card__title"><?php esc_html_e( 'Monitoring status', 'localboost-ai' ); ?></h2>
		<?php if ( empty( $lbai_monitor_status ) ) : ?>
			<p class="lbai-list__empty"><?php esc_html_e( 'Monitoring status is not available.', 'localboost-ai' ); ?></p>
		<?php else :
			$lbai_ms = $lbai_monitor_status['status'];
			$lbai_mb = 'lbai-badge-warning';
			if ( 'ok' === $lbai_ms ) {
				$lbai_mb = 'lbai-badge-passed';
			} elseif ( 'failed' === $lbai_ms ) {
				$lbai_mb = 'lbai-badge-critical';
			}
			?>
			<table class="wp-list-table widefat fixed striped lbai-table">
				<tbody>
					<tr>
						<th scope="row"><?php esc_html_e( 'Frequency', 'localboost-ai' ); ?></th>
						<td><?php echo esc_html( isset( $lbai_freq_labels[ $lbai_monitor_status['frequency'] ] ) ? $lbai_freq_labels[ $lbai_monitor_status['frequency'] ] : $lbai_monitor_status['frequency'] ); ?></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Last run', 'localboost-ai' ); ?></th>
						<td><?php echo ! empty( $lbai_monitor_status['last_run'] ) ? esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $lbai_monitor_status['last_run'] ) ) : esc_html__( 'Never', 'localboost-ai' ); ?></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Next run', 'localboost-ai' ); ?></th>
						<td><?php echo ! empty( $lbai_monitor_status['next_run'] ) ? esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $lbai_monitor_status['next_run'] ) ) : esc_html__( 'Not scheduled', 'localboost-ai' ); ?></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Last status', 'localboost-ai' ); ?></th>
						<td><span class="lbai-badge <?php echo esc_attr( $lbai_mb ); ?>"><?php echo esc_html( isset( $lbai_status_labels[ $lbai_ms ] ) ? $lbai_status_labels[ $lbai_ms ] : $lbai_ms ); ?></span></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Monitored pages', 'localboost-ai' ); ?></th>
						<td><?php echo esc_html( number_format_i18n( (int) $lbai_monitor_status['monitored_pages'] ) ); ?></td>
					</tr>
					<?php if ( 'failed' === $lbai_ms && ! empty( $lbai_monitor_status['error'] ) ) : ?>
						<tr>
							<th scope="row"><?php esc_html_e( 'Last error', 'localboost-ai' ); ?></th>
							<td><?php echo esc_html( $lbai_monitor_status['error'] ); ?></td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		<?php endif; ?>
	</div>

	<div class="lbai-card">
		<h2 class="lbai-card__title"><?php esc_html_e( 'Usage & limits', 'localboost-ai' ); ?></h2>
		<?php if ( ! class_exists( '\LocalBoostAI\Includes\Usage_Tracker' ) ) : ?>
			<p class="lbai-list__empty"><?php esc_html_e( 'Usage tracking is not available.', 'localboost-ai' ); ?></p>
		<?php else : ?>
			<table class="wp-list-table widefat fixed striped lbai-table">
				<thead>
					<tr>
						<th scope="col"><?php esc_html_e( 'Feature', 'localboost-ai' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Used', 'localboost-ai' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Quota', 'localboost-ai' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Remaining', 'localboost-ai' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Successful', 'localboost-ai' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Failed', 'localboost-ai' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Tokens', 'localboost-ai' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $lbai_usage_features as $lbai_feature => $lbai_feature_name ) :
						$lbai_rep = \LocalBoostAI\Includes\Usage_Tracker::get_usage_report( $lbai_feature );
						$lbai_quota = (int) $lbai_rep['quota'];
						?>
						<tr>
							<th scope="row"><?php echo esc_html( $lbai_feature_name ); ?></th>
							<td><?php echo esc_html( number_format_i18n( (int) $lbai_rep['successful'] ) ); ?></td>
							<td><?php echo $lbai_quota < 0 ? esc_html__( 'Unlimited', 'localboost-ai' ) : esc_html( number_format_i18n( $lbai_quota ) ); ?></td>
							<td><?php echo (int) $lbai_rep['remaining'] < 0 ? esc_html__( 'Unlimited', 'localboost-ai' ) : esc_html( number_format_i18n( (int) $lbai_rep['remaining'] ) ); ?></td>
							<td><?php echo esc_html( number_format_i18n( (int) $lbai_rep['successful'] ) ); ?></td>
							<td><?php echo esc_html( number_format_i18n( (int) $lbai_rep['failed'] ) ); ?></td>
							<td><?php echo esc_html( number_format_i18n( (int) $lbai_rep['tokens_total'] ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<p class="description"><?php esc_html_e( 'Counters reset on the first day of each month. Failed attempts never count against your quota.', 'localboost-ai' ); ?></p>
		<?php endif; ?>
	</div>

	<div class="lbai-card">
		<h2 class="lbai-card__title"><?php esc_html_e( 'Your data', 'localboost-ai' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'LocalBoost AI stores your business profile, audit results and usage counters on your own server. Page content is sent to your chosen AI provider only when you request a generation. Uninstalling the plugin removes all plugin data (your posts and pages are never touched).', 'localboost-ai' ); ?>
		</p>
		<div class="lbai-actions">
			<button type="button" class="button lbai-btn" id="lbai-export-settings"><?php esc_html_e( 'Export my settings', 'localboost-ai' ); ?></button>
		</div>
		<p class="description">
			<?php esc_html_e( 'To erase personal data, use WordPress’s built-in privacy tools under Tools → Export/Erase Personal Data.', 'localboost-ai' ); ?>
		</p>
	</div>
</div>
