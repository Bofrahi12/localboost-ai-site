<?php
/**
 * Upgrade view — Free vs Pro comparison.
 *
 * Honest freemium: license key is stored, validation against the licensing
 * server is an integration point (see docs/ROADMAP.md). No payment is
 * processed in this version.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

$is_pro = class_exists( '\LocalBoostAI\Includes\Licensing' )
	? \LocalBoostAI\Includes\Licensing::is_pro()
	: false;

$features = array(
	array( __( 'Basic SEO audit', 'localboost-ai' ), true, true ),
	array( __( 'AI title & meta optimization', 'localboost-ai' ), true, true ),
	array( __( 'Basic Local SEO & schema', 'localboost-ai' ), true, true ),
	array( __( 'AI generations per month', 'localboost-ai' ), __( '10', 'localboost-ai' ), __( '500', 'localboost-ai' ) ),
	array( __( 'Advanced audits (bulk, scheduled)', 'localboost-ai' ), false, true ),
	array( __( 'Advanced AI models', 'localboost-ai' ), false, true ),
	array( __( 'Advanced reports', 'localboost-ai' ), false, true ),
	array( __( 'Automated monitoring', 'localboost-ai' ), false, true ),
	array( __( 'Advanced schema types', 'localboost-ai' ), false, true ),
	array( __( 'Agency features', 'localboost-ai' ), false, true ),
	array( __( 'White-label reports', 'localboost-ai' ), false, true ),
);
?>
<div class="wrap lbai-wrap" data-lbai-page="upgrade">
	<h1 class="lbai-page-title"><?php esc_html_e( 'Upgrade', 'localboost-ai' ); ?></h1>
	<p class="lbai-page-subtitle">
		<?php esc_html_e( 'Current plan:', 'localboost-ai' ); ?>
		<span class="lbai-badge <?php echo $is_pro ? 'lbai-badge-passed' : 'lbai-badge-warning'; ?>">
			<?php echo $is_pro ? esc_html__( 'Pro', 'localboost-ai' ) : esc_html__( 'Free', 'localboost-ai' ); ?>
		</span>
	</p>

	<div class="lbai-card">
		<h2 class="lbai-card__title"><?php esc_html_e( 'Free vs Pro', 'localboost-ai' ); ?></h2>
		<table class="wp-list-table widefat fixed striped lbai-table">
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Feature', 'localboost-ai' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Free', 'localboost-ai' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Pro', 'localboost-ai' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $features as $row ) :
					list( $name, $free, $pro ) = $row;
					?>
					<tr>
						<td><?php echo esc_html( $name ); ?></td>
						<td><?php echo is_bool( $free ) ? ( $free ? '<span class="dashicons dashicons-yes" aria-label="' . esc_attr__( 'Included', 'localboost-ai' ) . '"></span>' : '<span class="dashicons dashicons-minus" aria-label="' . esc_attr__( 'Not included', 'localboost-ai' ) . '"></span>' ) : esc_html( $free ); ?></td>
						<td><?php echo is_bool( $pro ) ? ( $pro ? '<span class="dashicons dashicons-yes" aria-label="' . esc_attr__( 'Included', 'localboost-ai' ) . '"></span>' : '<span class="dashicons dashicons-minus" aria-label="' . esc_attr__( 'Not included', 'localboost-ai' ) . '"></span>' ) : esc_html( $pro ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>

	<div class="lbai-card">
		<h2 class="lbai-card__title"><?php esc_html_e( 'Activate your Pro license', 'localboost-ai' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="lbai_license_key"><?php esc_html_e( 'License key', 'localboost-ai' ); ?></label></th>
				<td>
					<input type="text" id="lbai_license_key" class="regular-text" value="<?php echo esc_attr( get_option( 'lbai_license_key', '' ) ); ?>" autocomplete="off" spellcheck="false" />
				</td>
			</tr>
		</table>
		<button type="button" class="button button-primary lbai-btn" id="lbai-license-save"><?php esc_html_e( 'Save license key', 'localboost-ai' ); ?></button>
		<p class="description" id="lbai-license-status" role="status"></p>
		<div class="notice notice-info lbai-notice">
			<p>
				<?php esc_html_e( 'License validation connects to the licensing server — see docs/ROADMAP.md for the integration status. Payments are handled by your chosen payment provider (Stripe integration planned); no payment is processed inside this plugin version.', 'localboost-ai' ); ?>
			</p>
		</div>
	</div>
</div>
