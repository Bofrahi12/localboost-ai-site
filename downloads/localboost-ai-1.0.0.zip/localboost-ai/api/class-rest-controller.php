<?php
/**
 * REST API controller for LocalBoost AI.
 *
 * Namespace: lbai/v1
 *
 * Every route requires the manage_options capability. Routes that read or
 * write a specific post additionally require edit_post for that post, and
 * the /ai/apply route requires a per-post nonce issued by /ai/apply-nonce.
 * Service classes (SEO_Auditor, AI_Optimizer, Content_Generator,
 * Keyword_Assistant, Schema_Generator, Consistency_Checker, Reporter) and
 * the Provider_Factory are owned by other modules; each call is guarded
 * with class_exists() and returns HTTP 501 when the service is not
 * available.
 *
 * Success envelope: {"success": true, "data": ...}
 * Errors: WP_Error with a lbai_* code and an appropriate HTTP status.
 * Exception: GET /reports/export returns a raw CSV file download.
 *
 * @package LocalBoostAI\Api
 */

namespace LocalBoostAI\Api;

use LocalBoostAI\Includes\AI_Exception;
use LocalBoostAI\Includes\Field_Registry;
use LocalBoostAI\Includes\Licensing;
use LocalBoostAI\Includes\Options;
use LocalBoostAI\Includes\Rate_Limiter;
use LocalBoostAI\Includes\Secure_Store;
use LocalBoostAI\Includes\Url_Validator;
use LocalBoostAI\Includes\Usage_Tracker;
use LocalBoostAI\Services\AI_Optimizer;
use LocalBoostAI\Services\Change_History;

if (!defined('ABSPATH')) {
    exit;
}

class Rest_Controller {

    const REST_NAMESPACE = 'lbai/v1';

    /** AI provider slugs accepted by the settings UI. */
    const PROVIDERS = array('openai', 'gemini', 'anthropic', 'meta', 'opensource');

    /**
     * Fields the AI optimizer may rewrite.
     *
     * Canonical field names from Field_Registry, plus the deprecated
     * 'h2_structure' (still accepted for backward compatibility, hidden
     * from new UI). Legacy aliases (seo_title, image_alt,
     * service_description) are accepted by the route validators through
     * Field_Registry::is_valid() and normalized to canonical names.
     */
    const OPTIMIZE_FIELDS = array(
        'title',
        'meta_description',
        'h1',
        'h2_structure',
        'introduction',
        'faq',
        'cta',
        'alt_texts',
        'internal_links',
    );

    /** Content types the generator may produce. */
    const CONTENT_TYPES = array(
        'service_page',
        'location_page',
        'faq',
        'about',
        'service_description',
        'landing_outline',
        'blog_ideas',
        'blog_outline',
        'meta_description',
        'seo_title',
    );

    /**
     * Text transformations.
     *
     * Canonical action names; the legacy 'improve' alias is accepted by the
     * route validator and normalized to 'readability' via
     * Field_Registry::canonicalize_action().
     */
    const TRANSFORM_ACTIONS = array('shorten', 'expand', 'readability', 'tone', 'translate');

    /** Schema.org types the generator supports. */
    const SCHEMA_TYPES = array('local_business', 'organization', 'service', 'faq', 'breadcrumb');

    /**
     * Hook route registration into the REST API.
     */
    public function register(): void {
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    /**
     * Permission callback shared by all routes.
     *
     * @return bool
     */
    public function check_permission(): bool {
        return current_user_can('manage_options');
    }

    /**
     * Register all routes under lbai/v1.
     */
    public function register_routes(): void {
        $ns   = self::REST_NAMESPACE;
        $perm = array($this, 'check_permission');

        // Dashboard.
        register_rest_route($ns, '/dashboard', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_dashboard'),
            'permission_callback' => $perm,
        ));

        // SEO audit.
        register_rest_route($ns, '/audit', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'audit_page'),
            'permission_callback' => $perm,
            'args'                => array(
                'post_id' => array(
                    'required'          => true,
                    'type'              => 'integer',
                    'sanitize_callback' => 'absint',
                    'validate_callback' => function ($v) { return $v > 0; },
                ),
            ),
        ));

        register_rest_route($ns, '/audit/(?P<id>\d+)', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_audit'),
            'permission_callback' => $perm,
            'args'                => array(
                'id' => array(
                    'type'              => 'integer',
                    'sanitize_callback' => 'absint',
                ),
            ),
        ));

        // AI optimizer.
        register_rest_route($ns, '/ai/optimize', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'optimize_field'),
            'permission_callback' => $perm,
            'args'                => array(
                'post_id'  => array(
                    'required'          => true,
                    'type'              => 'integer',
                    'sanitize_callback' => 'absint',
                    'validate_callback' => function ($v) { return $v > 0; },
                ),
                'field'    => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_key',
                    'validate_callback' => function ($v) { return Field_Registry::is_valid($v); },
                ),
                'language' => array(
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                    'default'           => 'en',
                ),
            ),
        ));

        // Per-post apply nonce for /ai/apply.
        register_rest_route($ns, '/ai/apply-nonce', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'apply_nonce'),
            'permission_callback' => $perm,
            'args'                => array(
                'post_id' => array(
                    'required'          => true,
                    'type'              => 'integer',
                    'sanitize_callback' => 'absint',
                    'validate_callback' => function ($v) { return $v > 0; },
                ),
            ),
        ));

        register_rest_route($ns, '/ai/apply', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'apply_suggestion'),
            'permission_callback' => $perm,
            'args'                => array(
                'post_id'   => array(
                    'required'          => true,
                    'type'              => 'integer',
                    'sanitize_callback' => 'absint',
                    'validate_callback' => function ($v) { return $v > 0; },
                ),
                'field'     => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_key',
                    'validate_callback' => function ($v) { return Field_Registry::is_valid($v); },
                ),
                'value'     => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'wp_kses_post',
                ),
                'placement' => array(
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_key',
                ),
                'apply_nonce' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'provider'  => array(
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                    'default'           => '',
                ),
                'model'     => array(
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                    'default'           => '',
                ),
            ),
        ));

        register_rest_route($ns, '/ai/undo', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'undo_apply'),
            'permission_callback' => $perm,
            'args'                => array(
                'post_id'   => array(
                    'required'          => true,
                    'type'              => 'integer',
                    'sanitize_callback' => 'absint',
                    'validate_callback' => function ($v) { return $v > 0; },
                ),
                'field'     => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_key',
                    'validate_callback' => function ($v) { return Field_Registry::is_valid($v); },
                ),
                'apply_nonce' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));

        // Content generator.
        register_rest_route($ns, '/ai/content', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'generate_content'),
            'permission_callback' => $perm,
            'args'                => array(
                'type'     => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_key',
                    'validate_callback' => function ($v) { return in_array($v, self::CONTENT_TYPES, true); },
                ),
                'params'   => array(
                    'type'    => 'object',
                    'default' => array(),
                ),
                'language' => array(
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                    'default'           => 'en',
                ),
            ),
        ));

        register_rest_route($ns, '/ai/transform', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'transform_content'),
            'permission_callback' => $perm,
            'args'                => array(
                'action' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_key',
                    'validate_callback' => function ($v) { return Field_Registry::is_valid_action($v); },
                ),
                'text'   => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'wp_kses_post',
                ),
                'args'   => array(
                    'type'    => 'object',
                    'default' => array(),
                ),
            ),
        ));

        // Keyword assistant.
        register_rest_route($ns, '/ai/keywords', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'suggest_keywords'),
            'permission_callback' => $perm,
            'args'                => array(
                'business_type' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'service'       => array(
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                    'default'           => '',
                ),
                'city'          => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'region'        => array(
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                    'default'           => '',
                ),
                'country'       => array(
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                    'default'           => '',
                ),
                'language'      => array(
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                    'default'           => 'en',
                ),
            ),
        ));

        // Schema.
        register_rest_route($ns, '/schema/preview', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'schema_preview'),
            'permission_callback' => $perm,
            'args'                => array(
                'type' => array(
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_key',
                    'validate_callback' => function ($v) { return in_array($v, self::SCHEMA_TYPES, true); },
                    'default'           => 'local_business',
                ),
            ),
        ));

        register_rest_route($ns, '/schema/save', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'schema_save'),
            'permission_callback' => $perm,
            'args'                => array(
                'enabled' => array(
                    'type'    => 'boolean',
                    'default' => false,
                ),
                'types'   => array(
                    'type'    => 'array',
                    'default' => array(),
                ),
            ),
        ));

        // Consistency checker.
        register_rest_route($ns, '/consistency/check', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'consistency_check'),
            'permission_callback' => $perm,
        ));

        // Reports.
        register_rest_route($ns, '/reports/summary', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'reports_summary'),
            'permission_callback' => $perm,
        ));

        register_rest_route($ns, '/reports/export', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'reports_export'),
            'permission_callback' => $perm,
            'args'                => array(
                'format' => array(
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_key',
                    'validate_callback' => function ($v) { return in_array($v, array('csv'), true); },
                    'default'           => 'csv',
                ),
                'report' => array(
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_key',
                    'validate_callback' => function ($v) { return in_array($v, array('audits', 'usage'), true); },
                    'default'           => 'audits',
                ),
            ),
        ));

        // Settings.
        register_rest_route($ns, '/settings', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_settings'),
            'permission_callback' => $perm,
        ));

        register_rest_route($ns, '/settings', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'update_settings'),
            'permission_callback' => $perm,
            'args'                => array(
                'settings' => array(
                    'required' => true,
                    'type'     => 'object',
                ),
            ),
        ));

        // AI provider connection test.
        register_rest_route($ns, '/ai/test-connection', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'test_connection'),
            'permission_callback' => $perm,
            'args'                => array(
                'provider' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_key',
                    'validate_callback' => function ($v) { return in_array($v, self::PROVIDERS, true); },
                ),
            ),
        ));

        // Onboarding completion flag.
        register_rest_route($ns, '/onboarding/finish', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'finish_onboarding'),
            'permission_callback' => $perm,
        ));
    }

    // ------------------------------------------------------------------
    // Handlers
    // ------------------------------------------------------------------

    /**
     * GET /dashboard
     */
    public function get_dashboard(\WP_REST_Request $request) {
        $summary = array(
            'latest'         => null,
            'counts'         => array('critical' => 0, 'warning' => 0, 'info' => 0),
            'pages_analyzed' => 0,
        );
        if (class_exists('LocalBoostAI\Services\SEO_Auditor')) {
            try {
                $summary = \LocalBoostAI\Services\SEO_Auditor::get_latest_audit_summary();
            } catch (\Throwable $e) {
                return $this->map_exception($e);
            }
        }

        $latest     = is_array($summary) && isset($summary['latest']) ? $summary['latest'] : null;
        $categories = is_array($latest) && isset($latest['categories']) && is_array($latest['categories'])
            ? $latest['categories']
            : array();
        $counts     = isset($summary['counts']) && is_array($summary['counts']) ? $summary['counts'] : array();

        $used  = 0;
        $limit = 0;
        if (class_exists('LocalBoostAI\Includes\Usage_Tracker')) {
            $used  = \LocalBoostAI\Includes\Usage_Tracker::get_monthly_usage('ai_generation');
            $limit = \LocalBoostAI\Includes\Usage_Tracker::get_limit('ai_generation');
        }

        $recent = array();
        if (class_exists('LocalBoostAI\Services\Reporter')) {
            try {
                $report = \LocalBoostAI\Services\Reporter::summary();
                $imps   = isset($report['improvements']) && is_array($report['improvements']) ? $report['improvements'] : array();
                foreach ($imps as $imp) {
                    $recent[] = array(
                        'text' => sprintf(
                            /* translators: 1: page URL, 2: previous score, 3: new score. */
                            __('%1$s: score %2$d → %3$d', 'localboost-ai'),
                            isset($imp['url']) ? $imp['url'] : '',
                            isset($imp['previous_score']) ? (int) $imp['previous_score'] : 0,
                            isset($imp['score']) ? (int) $imp['score'] : 0
                        ),
                        'date' => isset($imp['checked_at']) ? $imp['checked_at'] : '',
                    );
                }
            } catch (\Throwable $e) {
                // Improvements are nice-to-have; never break the dashboard.
            }
        }

        return $this->ok(array(
            'scores' => array(
                'overall' => is_array($latest) ? (int) $latest['score'] : 0,
                'local'   => isset($categories['local']) ? (int) $categories['local'] : 0,
            ),
            'issues' => array(
                'critical' => (int) (isset($counts['critical']) ? $counts['critical'] : 0),
                'warning'  => (int) (isset($counts['warning']) ? $counts['warning'] : 0),
                // The auditor contract reports informational results as
                // 'info'; the dashboard keeps its historical 'passed' key.
                'passed'   => (int) (isset($counts['info']) ? $counts['info'] : 0),
            ),
            'pages_analyzed'      => (int) (isset($summary['pages_analyzed']) ? $summary['pages_analyzed'] : 0),
            'usage'               => array('used' => $used, 'limit' => $limit),
            'recent_improvements' => array_slice($recent, 0, 5),
            'plan'                => class_exists('LocalBoostAI\Includes\Licensing') ? \LocalBoostAI\Includes\Licensing::get_plan() : 'free',
        ));
    }

    /**
     * POST /audit
     */
    public function audit_page(\WP_REST_Request $request) {
        $post_id = absint($request->get_param('post_id'));
        if ($post_id <= 0 || !get_post($post_id)) {
            return new \WP_Error('lbai_not_found', __('Page not found.', 'localboost-ai'), array('status' => 404));
        }
        if (!current_user_can('edit_post', $post_id)) {
            return new \WP_Error('lbai_forbidden', __('You are not allowed to audit this page.', 'localboost-ai'), array('status' => 403));
        }
        if (!class_exists('LocalBoostAI\Services\SEO_Auditor')) {
            return $this->service_unavailable();
        }
        $usage_error = $this->check_usage('audit');
        if ($usage_error) {
            return $usage_error;
        }
        try {
            // Static service; it records 'audit' usage itself.
            $result = \LocalBoostAI\Services\SEO_Auditor::audit_post($post_id);
        } catch (\Throwable $e) {
            return $this->map_exception($e);
        }
        return $this->ok($result);
    }

    /**
     * GET /audit/<id>
     */
    public function get_audit(\WP_REST_Request $request) {
        global $wpdb;
        $id  = absint($request->get_param('id'));
        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}lbai_audits WHERE id = %d", $id),
            ARRAY_A
        );
        if (!$row) {
            return new \WP_Error('lbai_not_found', __('Audit not found.', 'localboost-ai'), array('status' => 404));
        }
        $audit_post_id = isset($row['post_id']) ? (int) $row['post_id'] : 0;
        if ($audit_post_id > 0 && !current_user_can('edit_post', $audit_post_id)) {
            return new \WP_Error('lbai_forbidden', __('You are not allowed to view this audit.', 'localboost-ai'), array('status' => 403));
        }
        $row['categories'] = $this->maybe_decode_json($row['categories']);
        $row['issues']     = $this->maybe_decode_json($row['issues']);
        return $this->ok($row);
    }

    /**
     * POST /ai/optimize
     */
    public function optimize_field(\WP_REST_Request $request) {
        $post_id  = absint($request->get_param('post_id'));
        $field    = sanitize_key($request->get_param('field'));
        $language = sanitize_text_field($request->get_param('language') ? $request->get_param('language') : 'en');

        if ($post_id <= 0 || !get_post($post_id)) {
            return new \WP_Error('lbai_not_found', __('Page not found.', 'localboost-ai'), array('status' => 404));
        }
        if (!current_user_can('edit_post', $post_id)) {
            return new \WP_Error('lbai_forbidden', __('You are not allowed to optimize this page.', 'localboost-ai'), array('status' => 403));
        }
        $field = Field_Registry::canonicalize($field);
        if (null === $field) {
            return new \WP_Error('lbai_validation', __('Unknown optimization field.', 'localboost-ai'), array('status' => 400));
        }
        if (!class_exists(AI_Optimizer::class)) {
            return $this->service_unavailable();
        }
        $limited = $this->ai_rate_limit();
        if ($limited) {
            return $limited;
        }
        $usage_error = $this->check_usage('ai_generation');
        if ($usage_error) {
            return $usage_error;
        }
        try {
            // Instance service; it enforces capability/usage/rate limits and records usage itself.
            $optimizer = new AI_Optimizer();
            $result    = $optimizer->optimize_field($post_id, $field, array('language' => $language));
        } catch (\Throwable $e) {
            return $this->map_exception($e);
        }
        return $this->ok($result);
    }

    /**
     * GET /ai/apply-nonce
     *
     * Issues a per-post nonce that /ai/apply must present. Lets the UI mint
     * the nonce on demand instead of embedding one per post row.
     */
    public function apply_nonce(\WP_REST_Request $request) {
        $post_id = absint($request->get_param('post_id'));
        if ($post_id <= 0 || !get_post($post_id)) {
            return new \WP_Error('lbai_not_found', __('Page not found.', 'localboost-ai'), array('status' => 404));
        }
        if (!current_user_can('edit_post', $post_id)) {
            return new \WP_Error('lbai_forbidden', __('You are not allowed to edit this page.', 'localboost-ai'), array('status' => 403));
        }
        return $this->ok(array('nonce' => wp_create_nonce('lbai_apply_' . $post_id)));
    }

    /**
     * POST /ai/apply
     */
    public function apply_suggestion(\WP_REST_Request $request) {
        $post_id   = absint($request->get_param('post_id'));
        $field     = sanitize_key($request->get_param('field'));
        $value     = (string) $request->get_param('value');
        $placement = sanitize_key($request->get_param('placement') ? $request->get_param('placement') : '');
        $nonce     = (string) $request->get_param('apply_nonce');

        if ($post_id <= 0 || !get_post($post_id)) {
            return new \WP_Error('lbai_not_found', __('Page not found.', 'localboost-ai'), array('status' => 404));
        }
        if (!current_user_can('edit_post', $post_id)) {
            return new \WP_Error('lbai_forbidden', __('You are not allowed to edit this page.', 'localboost-ai'), array('status' => 403));
        }
        if ('' === $nonce || !wp_verify_nonce($nonce, 'lbai_apply_' . $post_id)) {
            return new \WP_Error('lbai_invalid_nonce', __('Invalid apply nonce. Please reload the page and try again.', 'localboost-ai'), array('status' => 403));
        }
        $field = Field_Registry::canonicalize($field);
        if (null === $field) {
            return new \WP_Error('lbai_validation', __('Unknown optimization field.', 'localboost-ai'), array('status' => 400));
        }
        if (!class_exists(AI_Optimizer::class)) {
            return $this->service_unavailable();
        }
        $limited = $this->ai_rate_limit();
        if ($limited) {
            return $limited;
        }
        // Field-specific sanitization at the boundary; the service
        // sanitizes again by field type as defense in depth.
        $value = $this->sanitize_apply_value($field, $value);
        try {
            $optimizer = new AI_Optimizer();
            $result    = $optimizer->apply_suggestion($post_id, $field, $value, array(
                'placement' => $placement,
                'provider'  => sanitize_text_field((string) $request->get_param('provider')),
                'model'     => sanitize_text_field((string) $request->get_param('model')),
            ));
        } catch (\Throwable $e) {
            return $this->map_exception($e);
        }
        return $this->ok($result);
    }

    /**
     * POST /ai/undo
     *
     * Reverts the most recent applied change for a post/field, using the
     * same per-post apply nonce as /ai/apply.
     */
    public function undo_apply(\WP_REST_Request $request) {
        $post_id = absint($request->get_param('post_id'));
        $field   = sanitize_key($request->get_param('field'));
        $nonce   = (string) $request->get_param('apply_nonce');

        if ($post_id <= 0 || !get_post($post_id)) {
            return new \WP_Error('lbai_not_found', __('Page not found.', 'localboost-ai'), array('status' => 404));
        }
        if (!current_user_can('edit_post', $post_id)) {
            return new \WP_Error('lbai_forbidden', __('You are not allowed to edit this page.', 'localboost-ai'), array('status' => 403));
        }
        if ('' === $nonce || !wp_verify_nonce($nonce, 'lbai_apply_' . $post_id)) {
            return new \WP_Error('lbai_invalid_nonce', __('Invalid apply nonce. Please reload the page and try again.', 'localboost-ai'), array('status' => 403));
        }
        $field = Field_Registry::canonicalize($field);
        if (null === $field) {
            return new \WP_Error('lbai_validation', __('Unknown optimization field.', 'localboost-ai'), array('status' => 400));
        }
        if (!class_exists(Change_History::class)) {
            return $this->service_unavailable();
        }
        $result = Change_History::undo_last($post_id, $field);
        if (is_wp_error($result)) {
            return new \WP_Error($result->get_error_code(), $result->get_error_message(), array('status' => 404));
        }
        return $this->ok($result);
    }

    /**
     * Sanitize an apply value by field type, delegating to the optimizer's
     * field-aware sanitizer; the service sanitizes again as defense in
     * depth.
     *
     * @param string $field Canonical field name.
     * @param string $value Raw value.
     * @return string
     */
    private function sanitize_apply_value(string $field, string $value): string {
        return (new AI_Optimizer())->sanitize_field_value($field, $value);
    }

    /**
     * POST /ai/content
     */
    public function generate_content(\WP_REST_Request $request) {
        $type     = sanitize_key($request->get_param('type'));
        $params   = $request->get_param('params');
        $params   = is_array($params) ? $this->sanitize_deep($params) : array();
        $language = sanitize_text_field($request->get_param('language') ? $request->get_param('language') : 'en');

        if (!class_exists('LocalBoostAI\Services\Content_Generator')) {
            return $this->service_unavailable();
        }
        $limited = $this->ai_rate_limit();
        if ($limited) {
            return $limited;
        }
        $usage_error = $this->check_usage('content');
        if ($usage_error) {
            return $usage_error;
        }
        // The service reads language from $params and records 'content' usage itself.
        $params['language'] = $language;
        try {
            $generator = new \LocalBoostAI\Services\Content_Generator();
            $result    = $generator->generate($type, $params);
        } catch (\Throwable $e) {
            return $this->map_exception($e);
        }
        return $this->ok($result);
    }

    /**
     * POST /ai/transform
     */
    public function transform_content(\WP_REST_Request $request) {
        $action = Field_Registry::canonicalize_action(sanitize_key($request->get_param('action')));
        $text   = wp_kses_post($request->get_param('text'));
        $args   = $request->get_param('args');
        $args   = is_array($args) ? $this->sanitize_deep($args) : array();

        if (null === $action) {
            return new \WP_Error('lbai_validation', __('Unknown transform action.', 'localboost-ai'), array('status' => 400));
        }

        if (function_exists('mb_substr')) {
            $text = mb_substr($text, 0, 20000, 'UTF-8');
        } else {
            $text = substr($text, 0, 20000);
        }

        if (!class_exists('LocalBoostAI\Services\Content_Generator')) {
            return $this->service_unavailable();
        }
        $limited = $this->ai_rate_limit();
        if ($limited) {
            return $limited;
        }
        $usage_error = $this->check_usage('ai_generation');
        if ($usage_error) {
            return $usage_error;
        }
        try {
            // Instance service; it records 'ai_generation' usage itself.
            $generator = new \LocalBoostAI\Services\Content_Generator();
            $result    = $generator->transform($action, $text, $args);
        } catch (\Throwable $e) {
            return $this->map_exception($e);
        }
        return $this->ok($result);
    }

    /**
     * POST /ai/keywords
     */
    public function suggest_keywords(\WP_REST_Request $request) {
        $params = array(
            'business_type' => sanitize_text_field($request->get_param('business_type')),
            'service'       => sanitize_text_field($request->get_param('service')),
            'city'          => sanitize_text_field($request->get_param('city')),
            'region'        => sanitize_text_field($request->get_param('region')),
            'country'       => sanitize_text_field($request->get_param('country')),
            'language'      => sanitize_text_field($request->get_param('language') ? $request->get_param('language') : 'en'),
        );

        if (!class_exists('LocalBoostAI\Services\Keyword_Assistant')) {
            return $this->service_unavailable();
        }
        $limited = $this->ai_rate_limit();
        if ($limited) {
            return $limited;
        }
        $usage_error = $this->check_usage('ai_generation');
        if ($usage_error) {
            return $usage_error;
        }
        try {
            // Instance service; it records 'ai_generation' usage itself.
            $assistant = new \LocalBoostAI\Services\Keyword_Assistant();
            $result    = $assistant->suggest($params);
        } catch (\Throwable $e) {
            return $this->map_exception($e);
        }
        return $this->ok($result);
    }

    /**
     * GET /schema/preview
     */
    public function schema_preview(\WP_REST_Request $request) {
        $type = sanitize_key($request->get_param('type') ? $request->get_param('type') : 'local_business');

        if (!class_exists('LocalBoostAI\Services\Schema_Generator')) {
            return $this->service_unavailable();
        }
        try {
            $schema = \LocalBoostAI\Services\Schema_Generator::build($type);
            $jsonld = \LocalBoostAI\Services\Schema_Generator::to_jsonld($schema);
        } catch (\Throwable $e) {
            return $this->map_exception($e);
        }
        return $this->ok(array(
            'type'    => $type,
            'schema'  => $schema,
            'json_ld' => $jsonld,
        ));
    }

    /**
     * POST /schema/save
     */
    public function schema_save(\WP_REST_Request $request) {
        $enabled = $request->get_param('enabled') ? 1 : 0;
        $types   = $request->get_param('types');
        $types   = is_array($types)
            ? array_values(array_intersect(array_map('sanitize_key', $types), self::SCHEMA_TYPES))
            : array();

        Options::set('lbai_schema_enabled', $enabled);
        Options::set('lbai_schema_types', $types);

        return $this->ok(array('enabled' => $enabled, 'types' => $types));
    }

    /**
     * POST /consistency/check
     */
    public function consistency_check(\WP_REST_Request $request) {
        if (!class_exists('LocalBoostAI\Services\Consistency_Checker')) {
            return $this->service_unavailable();
        }
        try {
            $checker = new \LocalBoostAI\Services\Consistency_Checker();
            $result  = $checker->check();
        } catch (\Throwable $e) {
            return $this->map_exception($e);
        }

        // Shape the per-field results for the UI table: only non-consistent
        // fields are listed as differences.
        $differences = array();
        foreach ((array) $result as $row) {
            if (!is_array($row)) {
                continue;
            }
            $status = isset($row['status']) ? (string) $row['status'] : '';
            if ($status === 'consistent') {
                continue;
            }
            $found = isset($row['found']) ? $row['found'] : array();
            $differences[] = array(
                'field' => isset($row['label']) ? (string) $row['label'] : (isset($row['field']) ? (string) $row['field'] : ''),
                'saved' => isset($row['canonical']) ? (string) $row['canonical'] : '',
                'found' => is_array($found) ? implode(', ', array_slice(array_map('strval', $found), 0, 5)) : (string) $found,
                'fix'   => isset($row['message']) ? (string) $row['message'] : '',
            );
        }

        if (empty($differences)) {
            return $this->ok(array(
                'differences' => array(),
                'message'     => __('Business information is consistent across the site.', 'localboost-ai'),
            ));
        }
        return $this->ok(array('differences' => $differences));
    }

    /**
     * GET /reports/summary
     */
    public function reports_summary(\WP_REST_Request $request) {
        if (!class_exists('LocalBoostAI\Services\Reporter')) {
            return $this->service_unavailable();
        }
        try {
            $result = \LocalBoostAI\Services\Reporter::summary();
        } catch (\Throwable $e) {
            return $this->map_exception($e);
        }
        return $this->ok($result);
    }

    /**
     * GET /reports/export — returns a raw CSV file download.
     */
    public function reports_export(\WP_REST_Request $request) {
        $format = sanitize_key($request->get_param('format') ? $request->get_param('format') : 'csv');
        $report = sanitize_key($request->get_param('report') ? $request->get_param('report') : 'audits');

        if (!class_exists('LocalBoostAI\Services\Reporter')) {
            return $this->service_unavailable();
        }
        $usage_error = $this->check_usage('report');
        if ($usage_error) {
            return $usage_error;
        }
        try {
            $export = \LocalBoostAI\Services\Reporter::export_csv($report);
        } catch (\Throwable $e) {
            return $this->map_exception($e);
        }

        if (is_array($export) && isset($export['content'])) {
            $content  = (string) $export['content'];
            $filename = isset($export['filename']) ? (string) $export['filename'] : '';
        } else {
            $content  = (string) $export;
            $filename = '';
        }
        if ($filename === '') {
            $filename = 'localboost-' . $report . '-' . gmdate('Y-m-d') . '.csv';
        }

        Usage_Tracker::record('report');

        $response = new \WP_REST_Response($content, 200);
        $response->header('Content-Type', 'text/csv; charset=UTF-8');
        $response->header('Content-Disposition', 'attachment; filename="' . sanitize_file_name($filename) . '"');
        return $response;
    }

    /**
     * GET /settings
     */
    public function get_settings(\WP_REST_Request $request) {
        return $this->ok($this->get_settings_array());
    }

    /**
     * POST /settings
     */
    public function update_settings(\WP_REST_Request $request) {
        $settings = $request->get_param('settings');
        if (!is_array($settings)) {
            return new \WP_Error('lbai_validation', __('Invalid settings payload.', 'localboost-ai'), array('status' => 400));
        }

        $whitelist = array_diff(Options::all_known_keys(), array('lbai_db_version'));
        $updated   = array();

        foreach ($settings as $key => $value) {
            if (!is_string($key)) {
                continue;
            }

            // API keys are stored encrypted and never returned raw.
            if (strpos($key, 'lbai_api_key_') === 0) {
                $provider = substr($key, strlen('lbai_api_key_'));
                if (!in_array($provider, self::PROVIDERS, true)) {
                    continue;
                }
                if ($value === '' || $value === null) {
                    Secure_Store::delete_api_key($provider);
                } elseif (is_string($value)) {
                    Secure_Store::set_api_key($provider, $value);
                } else {
                    continue;
                }
                $updated[] = $key;
                continue;
            }

            if (!in_array($key, $whitelist, true)) {
                continue;
            }

            if ($key === 'lbai_ai_provider' && !in_array($value, self::PROVIDERS, true)) {
                return new \WP_Error('lbai_validation', __('Invalid AI provider.', 'localboost-ai'), array('status' => 400));
            }

            // SSRF defense in depth: AI base URLs are validated on save as
            // well as on every outbound request. Loopback stays allowed for
            // the self-hosted provider only (with an admin warning).
            if ($key === 'lbai_meta_base_url' && is_string($value) && trim($value) !== '') {
                $check = Url_Validator::validate($value, 'remote');
                if (!$check['valid']) {
                    return new \WP_Error('lbai_validation', $check['error'], array('status' => 400));
                }
            }
            if ($key === 'lbai_opensource_base_url' && is_string($value) && trim($value) !== '') {
                $check = Url_Validator::validate($value, 'selfhosted');
                if (!$check['valid']) {
                    return new \WP_Error('lbai_validation', $check['error'], array('status' => 400));
                }
            }

            if ($key === 'lbai_schema_types' && is_array($value)) {
                $value = array_values(array_intersect(array_map('sanitize_key', $value), self::SCHEMA_TYPES));
            }

            Options::set($key, $this->sanitize_setting($key, $value));
            $updated[] = $key;
        }

        return $this->ok(array(
            'updated'  => $updated,
            'settings' => $this->get_settings_array(),
        ));
    }

    /**
     * POST /ai/test-connection
     *
     * Returns a proper REST error (non-2xx, success:false) whenever the
     * connection is not valid — never a 200-OK-looking payload with
     * valid:false, so no client can mistake a failed test for success.
     */
    public function test_connection(\WP_REST_Request $request) {
        $provider = sanitize_key($request->get_param('provider'));

        if (!class_exists('LocalBoostAI\Providers\Provider_Factory')) {
            return $this->service_unavailable();
        }

        $limited = $this->ai_rate_limit();
        if ($limited) {
            return $limited;
        }

        $key = Secure_Store::get_api_key($provider);
        if ($key === '') {
            // Keyless providers (e.g. self-hosted open-source servers) can be
            // tested without a stored key; the others need one first.
            $needs_key = true;
            $map = \LocalBoostAI\Providers\Provider_Factory::get_available_providers();
            if (isset($map[$provider]) && is_string($map[$provider]) && class_exists($map[$provider])) {
                $probe     = new $map[$provider](array('api_key' => ''));
                $needs_key = !method_exists($probe, 'requires_api_key') || $probe->requires_api_key();
            }
            if ($needs_key) {
                return new \WP_Error(
                    'lbai_connection_failed',
                    __('No API key stored for this provider. Save a key first.', 'localboost-ai'),
                    array('status' => 400, 'valid' => false)
                );
            }
        }

        try {
            $instance = \LocalBoostAI\Providers\Provider_Factory::create($provider);
            $valid    = $instance->validate_credentials($key);
        } catch (\Throwable $e) {
            return $this->map_exception($e);
        }

        if ($valid) {
            return $this->ok(array(
                'valid'   => true,
                'message' => __('Connection successful.', 'localboost-ai'),
            ));
        }

        return new \WP_Error(
            'lbai_connection_failed',
            __('The provider rejected the API key.', 'localboost-ai'),
            array('status' => 400, 'valid' => false)
        );
    }

    /**
     * POST /onboarding/finish
     *
     * Marks the onboarding wizard complete so the redirect never fires again.
     */
    public function finish_onboarding(\WP_REST_Request $request) {
        Options::set('lbai_onboarding_done', 1);
        delete_transient('lbai_onboarding_pending');
        return $this->ok(array('done' => true));
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    /**
     * Wrap data in the standard success envelope.
     *
     * @param mixed $data   Payload.
     * @param int   $status HTTP status code.
     * @return \WP_REST_Response
     */
    private function ok($data = array(), int $status = 200) {
        $response = rest_ensure_response(array('success' => true, 'data' => $data));
        $response->set_status($status);
        return $response;
    }

    /**
     * Standard 501 response for services owned by other modules.
     *
     * @return \WP_Error
     */
    private function service_unavailable() {
        return new \WP_Error(
            'lbai_service_unavailable',
            __('This feature is not available yet. Please update the plugin.', 'localboost-ai'),
            array('status' => 501)
        );
    }

    /**
     * Map a thrown exception to a WP_Error with the right HTTP status.
     *
     * AI_Exception codes: invalid_key -> 401, rate_limited -> 429,
     * timeout -> 504, provider_unavailable -> 502, validation -> 400,
     * anything else -> 500. User messages are safe to display; technical
     * details never leave the server.
     *
     * @param \Throwable $e
     * @return \WP_Error
     */
    private function map_exception(\Throwable $e) {
        $status  = 500;
        $code    = 'lbai_error';
        $message = __('Something went wrong. Please try again.', 'localboost-ai');

        if ($e instanceof AI_Exception) {
            $error_code = $e->get_error_code();
            $code       = 'lbai_' . $error_code;
            $message    = $e->get_user_message();
            $map        = array(
                'invalid_key'          => 401,
                'rate_limited'         => 429,
                'timeout'              => 504,
                'provider_unavailable' => 502,
                'validation'           => 400,
                'not_configured'       => 400,
                'limit_reached'        => 429,
                'permission_denied'    => 403,
            );
            $status = isset($map[$error_code]) ? $map[$error_code] : 500;
        }

        return new \WP_Error($code, $message, array('status' => $status));
    }

    /**
     * Per-user rate limit for AI routes: 20 requests/minute (sliding window).
     *
     * Uses the atomic consume() check so a request is counted exactly when
     * it is allowed — no check-then-hit race.
     *
     * @return \WP_Error|null WP_Error when limited, null when allowed.
     */
    private function ai_rate_limit() {
        $bucket = 'lbai_ai_' . get_current_user_id();
        if (!Rate_Limiter::consume($bucket, 20, 60)) {
            return new \WP_Error(
                'lbai_rate_limited',
                __('Too many AI requests. Please wait a minute and try again.', 'localboost-ai'),
                array('status' => 429)
            );
        }
        return null;
    }

    /**
     * Enforce the monthly usage limit for a feature.
     *
     * @param string $feature Feature slug.
     * @return \WP_Error|null WP_Error when the limit is reached, null otherwise.
     */
    private function check_usage(string $feature) {
        if (!Usage_Tracker::can_use($feature)) {
            return new \WP_Error(
                'lbai_limit_reached',
                Usage_Tracker::usage_message($feature),
                array('status' => 429)
            );
        }
        return null;
    }

    /**
     * Remaining-units map for a limits array.
     *
     * @param array $limits Feature slug => int limit.
     * @return array
     */
    private function remaining_map(array $limits): array {
        $remaining = array();
        foreach ($limits as $feature => $limit) {
            $remaining[$feature] = Usage_Tracker::remaining((string) $feature);
        }
        return $remaining;
    }

    /**
     * Settings payload for GET /settings: all options plus masked API
     * keys, the current plan, limits and remaining units.
     *
     * @return array
     */
    private function get_settings_array(): array {
        $settings = Options::get_all();
        foreach (self::PROVIDERS as $provider) {
            $settings['lbai_api_key_' . $provider] = Secure_Store::get_masked_key($provider);
        }
        $settings['plan']      = Licensing::get_plan();
        $settings['limits']    = Licensing::get_limits();
        $settings['remaining'] = $this->remaining_map($settings['limits']);
        return $settings;
    }

    /**
     * Sanitize a single setting value according to its type.
     *
     * @param string $key   Option name.
     * @param mixed  $value Raw value.
     * @return mixed
     */
    private function sanitize_setting(string $key, $value) {
        $int_keys   = array('lbai_ai_max_tokens', 'lbai_onboarding_done');
        $bool_keys  = array('lbai_schema_enabled', 'lbai_notify_audit_completed', 'lbai_notify_critical', 'lbai_notify_report', 'lbai_notify_usage');
        $url_keys   = array('lbai_website', 'lbai_meta_base_url', 'lbai_opensource_base_url', 'lbai_white_label_logo');
        $array_keys = array('lbai_hours', 'lbai_services', 'lbai_social', 'lbai_schema_types', 'lbai_monitor_pages');

        if (in_array($key, $int_keys, true)) {
            return absint($value);
        }
        if (in_array($key, $bool_keys, true)) {
            return $value ? 1 : 0;
        }
        if ($key === 'lbai_ai_temperature') {
            return min(2.0, max(0.0, (float) $value));
        }
        if ($key === 'lbai_email') {
            return sanitize_email($value);
        }
        if (in_array($key, $url_keys, true)) {
            return esc_url_raw($value);
        }
        if (in_array($key, $array_keys, true)) {
            return is_array($value) ? $this->sanitize_deep($value) : array();
        }
        return is_string($value) ? sanitize_text_field($value) : $value;
    }

    /**
     * Recursively sanitize an arbitrary array payload.
     *
     * @param mixed $value
     * @return mixed
     */
    private function sanitize_deep($value) {
        if (is_array($value)) {
            $clean = array();
            foreach ($value as $k => $v) {
                $clean[is_string($k) ? sanitize_key($k) : $k] = $this->sanitize_deep($v);
            }
            return $clean;
        }
        if (is_string($value)) {
            return sanitize_text_field($value);
        }
        if (is_int($value) || is_float($value) || is_bool($value)) {
            return $value;
        }
        return null;
    }

    /**
     * JSON-decode a DB text column when it holds JSON, else return as-is.
     *
     * @param mixed $value
     * @return mixed
     */
    private function maybe_decode_json($value) {
        if (!is_string($value) || $value === '') {
            return $value;
        }
        $decoded = json_decode($value, true);
        return json_last_error() === JSON_ERROR_NONE ? $decoded : $value;
    }
}
