/**
 * LocalBoost AI — admin app.
 *
 * Vanilla JS (no jQuery). Talks to the REST API at lbai/v1/.
 * API keys are never handled here — they travel only through the
 * password field on the AI Settings page to POST /settings.
 */
(function () {
	'use strict';

	var cfg = window.lbaiAdmin || {};
	var i18n = cfg.i18n || {};

	if (!cfg.restUrl || !cfg.nonce) {
		return;
	}

	var base = cfg.restUrl.replace(/\/$/, '') + '/lbai/v1/';

	/* ---------- helpers ---------- */

	function t(key) {
		return i18n[key] || key;
	}

	function esc(s) {
		return String(s == null ? '' : s)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#039;');
	}

	function api(path, opts) {
		opts = opts || {};
		return fetch(base + path.replace(/^\//, ''), {
			method: opts.method || 'GET',
			headers: {
				'X-WP-Nonce': cfg.nonce,
				'Content-Type': 'application/json'
			},
			body: opts.body ? JSON.stringify(opts.body) : undefined
		}).then(function (res) {
			return res.json().then(function (json) {
				if (!res.ok || !json || !json.success) {
					var msg = (json && (json.message || (json.data && json.data.message))) || t('error');
					throw new Error(msg);
				}
				return json.data;
			});
		}).catch(function (err) {
			if (err instanceof TypeError) {
				throw new Error(t('networkError'));
			}
			throw err;
		});
	}

	function toast(msg, type) {
		var wrap = document.getElementById('lbai-toasts');
		if (!wrap) {
			wrap = document.createElement('div');
			wrap.id = 'lbai-toasts';
			wrap.setAttribute('aria-live', 'polite');
			document.body.appendChild(wrap);
		}
		var el = document.createElement('div');
		el.className = 'lbai-toast' + (type ? ' lbai-toast--' + type : '');
		el.textContent = msg;
		wrap.appendChild(el);
		setTimeout(function () {
			el.remove();
		}, 4500);
	}

	function setStatus(el, msg) {
		if (el) {
			el.textContent = msg || '';
		}
	}

	function busy(btn, isBusy, label) {
		if (!btn) {
			return;
		}
		if (isBusy) {
			btn.dataset.lbaiLabel = btn.textContent;
			btn.disabled = true;
			btn.textContent = label || t('loading');
		} else {
			btn.disabled = false;
			if (btn.dataset.lbaiLabel) {
				btn.textContent = btn.dataset.lbaiLabel;
			}
		}
	}

	function scoreRing(score) {
		score = Math.max(0, Math.min(100, parseInt(score, 10) || 0));
		var cls = score >= 80 ? 'high' : (score >= 50 ? 'mid' : 'low');
		return '<div class="lbai-score-ring score-' + cls + '" role="img" aria-label="' + esc(score) + ' / 100" style="--score:' + score + ';">' +
			'<span class="lbai-score-ring__value" aria-hidden="true">' + score + '</span></div>';
	}

	function badge(severity) {
		var labels = { critical: 'Critical', warning: 'Warning', info: 'Info' };
		// 'info' reuses the existing 'passed' badge styling (no new CSS needed).
		var classes = { critical: 'critical', warning: 'warning', info: 'passed' };
		var sev = labels[severity] ? severity : 'info';
		return '<span class="lbai-badge lbai-badge-' + classes[sev] + '">' + esc(labels[sev]) + '</span>';
	}

	function copyText(text, done) {
		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(text).then(function () {
				toast(t('copied'), 'success');
				if (done) {
					done();
				}
			}, function () {
				toast(t('copyFailed'), 'error');
			});
		} else {
			toast(t('copyFailed'), 'error');
		}
	}

	function download(url, filename) {
		return fetch(url, { headers: { 'X-WP-Nonce': cfg.nonce } }).then(function (res) {
			if (!res.ok) {
				throw new Error(t('error'));
			}
			return res.blob();
		}).then(function (blob) {
			var a = document.createElement('a');
			a.href = URL.createObjectURL(blob);
			a.download = filename;
			document.body.appendChild(a);
			a.click();
			a.remove();
			setTimeout(function () {
				URL.revokeObjectURL(a.href);
			}, 4000);
		});
	}

	/* ---------- dashboard ---------- */

	function initDashboard() {
		api('dashboard').then(function (data) {
			var scores = data.scores || {};
			document.getElementById('lbai-score-overall').innerHTML = scoreRing(scores.overall);
			document.getElementById('lbai-score-local').innerHTML = scoreRing(scores.local);

			var issues = data.issues || {};
			document.getElementById('lbai-count-critical').textContent = issues.critical || 0;
			document.getElementById('lbai-count-warning').textContent = issues.warning || 0;
			document.getElementById('lbai-count-passed').textContent = issues.passed || 0;
			document.getElementById('lbai-count-pages').textContent = data.pages_analyzed || 0;

			var usage = data.usage || {};
			var used = usage.used || 0;
			var limit = usage.limit || 0;
			document.getElementById('lbai-usage-used').textContent = used;
			document.getElementById('lbai-usage-limit').textContent = limit ? '/ ' + limit : '';
			if (limit > 0) {
				var pct = Math.min(100, Math.round((used / limit) * 100));
				var bar = document.getElementById('lbai-usage-bar');
				bar.style.width = pct + '%';
				document.getElementById('lbai-usage-bar-wrap').setAttribute('aria-valuenow', pct);
			}

			var list = document.getElementById('lbai-improvements');
			var items = data.recent_improvements || [];
			if (!items.length) {
				list.innerHTML = '<li class="lbai-list__empty">—</li>';
			} else {
				list.innerHTML = items.map(function (item) {
					return '<li>' + esc(item.text || item) +
						(item.date ? '<span class="lbai-list__meta">' + esc(item.date) + '</span>' : '') + '</li>';
				}).join('');
			}
		}).catch(function (err) {
			toast(err.message, 'error');
		});

		var btn = document.getElementById('lbai-quick-consistency');
		if (btn) {
			btn.addEventListener('click', function () {
				runConsistency(document.getElementById('lbai-consistency-result'), btn);
			});
		}
	}

	function runConsistency(resultEl, btn) {
		if (resultEl) {
			resultEl.hidden = false;
			resultEl.innerHTML = '<p>' + esc(t('loading')) + '</p>';
		}
		busy(btn, true, t('loading'));
		api('consistency/check', { method: 'POST' }).then(function (data) {
			var diffs = data.differences || data.items || [];
			var html;
			if (!diffs.length) {
				html = '<div class="notice notice-success lbai-notice"><p>✓ ' + esc(data.message || 'OK') + '</p></div>';
			} else {
				html = '<table class="wp-list-table widefat fixed striped lbai-table"><thead><tr>' +
					'<th>Field</th><th>Saved</th><th>Found on site</th><th>Action needed</th></tr></thead><tbody>' +
					diffs.map(function (d) {
						return '<tr><td><strong>' + esc(d.field || '') + '</strong></td>' +
							'<td>' + esc(d.expected || d.saved || '') + '</td>' +
							'<td>' + esc(d.found || '') + '</td>' +
							'<td>' + esc(d.fix || d.action || '') + '</td></tr>';
					}).join('') + '</tbody></table>';
			}
			if (resultEl) {
				resultEl.innerHTML = html;
			}
		}).catch(function (err) {
			if (resultEl) {
				resultEl.innerHTML = '<div class="notice notice-error lbai-notice"><p>' + esc(err.message) + '</p></div>';
			}
		}).finally(function () {
			busy(btn, false);
		});
	}

	/* ---------- audit ---------- */

	var auditPostId = 0;

	function initAudit() {
		var form = document.getElementById('lbai-audit-form');
		if (!form) {
			return;
		}
		var select = document.getElementById('lbai-audit-post');
		var idInput = document.getElementById('lbai-audit-post-id');
		var runBtn = document.getElementById('lbai-audit-run');
		var status = document.getElementById('lbai-audit-status');
		var results = document.getElementById('lbai-audit-results');

		form.addEventListener('submit', function (e) {
			e.preventDefault();
			var postId = parseInt(idInput.value, 10) || parseInt(select.value, 10) || 0;
			if (!postId) {
				toast(t('selectPage'), 'error');
				return;
			}
			auditPostId = postId;
			busy(runBtn, true, t('analyzing'));
			setStatus(status, t('analyzing'));

			api('audit', { method: 'POST', body: { post_id: postId } }).then(function (data) {
				results.hidden = false;
				renderAuditResults(data, postId);
				setStatus(status, '');
			}).catch(function (err) {
				setStatus(status, '');
				toast(err.message, 'error');
			}).finally(function () {
				busy(runBtn, false);
			});
		});

		document.querySelectorAll('.lbai-filter-btn').forEach(function (btn) {
			btn.addEventListener('click', function () {
				document.querySelectorAll('.lbai-filter-btn').forEach(function (b) {
					b.classList.remove('is-active');
					b.setAttribute('aria-pressed', 'false');
				});
				btn.classList.add('is-active');
				btn.setAttribute('aria-pressed', 'true');
				var filter = btn.dataset.filter;
				document.querySelectorAll('#lbai-issues-body tr').forEach(function (row) {
					row.style.display = (filter === 'all' || row.dataset.severity === filter) ? '' : 'none';
				});
			});
		});

		document.getElementById('lbai-issues-body').addEventListener('click', function (e) {
			var btn = e.target.closest('.lbai-btn-fix-ai');
			if (!btn) {
				return;
			}
			var postId = parseInt(btn.dataset.postId, 10) || 0;
			var field = btn.dataset.field || '';
			if (!postId || !field) {
				return;
			}
			// Fix with AI: request the suggestion and open the review dialog
			// on this page; nothing is applied until the user approves it.
			busy(btn, true, t('generating'));
			api('ai/optimize', { method: 'POST', body: { post_id: postId, field: field } }).then(function (data) {
				openReviewModal(postId, field, data);
			}).catch(function (err) {
				toast(err.message, 'error');
			}).finally(function () {
				busy(btn, false);
			});
		});

		wireReviewModal();
	}

	function renderAuditResults(data, postId) {
		document.getElementById('lbai-audit-score').innerHTML = scoreRing(data.score);

		var cats = data.categories || {};
		var catEl = document.getElementById('lbai-audit-categories');
		var names = {
			technical: 'Technical SEO',
			onpage: 'On-page SEO',
			local: 'Local SEO',
			content: 'Content',
			structured: 'Structured Data'
		};
		catEl.innerHTML = Object.keys(names).map(function (key) {
			var v = Math.max(0, Math.min(100, parseInt(cats[key], 10) || 0));
			return '<div class="lbai-category-bar"><div class="lbai-category-bar__head"><span>' +
				esc(names[key]) + '</span><span>' + v + '</span></div>' +
				'<div class="lbai-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + v + '" aria-label="' + esc(names[key]) + '">' +
				'<div class="lbai-progress__fill" style="width:' + v + '%"></div></div></div>';
		}).join('');

		var issues = data.issues || [];
		var body = document.getElementById('lbai-issues-body');
		if (!issues.length) {
			body.innerHTML = '<tr><td colspan="3">' + esc(t('noResults')) + '</td></tr>';
			return;
		}
		body.innerHTML = issues.map(function (issue) {
			var sev = issue.severity || 'info';
			// The "Fix with AI" button appears only when the auditor flags
			// the issue as AI-fixable (issue.ai_fix === true).
			var fixBtn = (issue.ai_fix === true && issue.field)
				? '<button type="button" class="button button-small lbai-btn-fix-ai" data-field="' + esc(issue.field) + '" data-post-id="' + postId + '">Fix with AI</button>'
				: '';
			return '<tr class="lbai-issue-row lbai-issue-row--' + esc(sev === 'info' ? 'passed' : sev) + '" data-severity="' + esc(sev) + '">' +
				'<td>' + badge(sev) + '</td>' +
				'<td><strong class="lbai-issue-problem">' + esc(issue.problem || '') + '</strong>' +
				(issue.why ? '<p class="description">' + esc(issue.why) + '</p>' : '') + '</td>' +
				'<td>' + (issue.action ? '<p>' + esc(issue.action) + '</p>' : '') + fixBtn + '</td></tr>';
		}).join('');
	}

	/* ---------- shared AI suggestion review modal ---------- */

	var pendingApply = null;
	var pendingUndo = null;

	/**
	 * English fallbacks for strings added after the localized pack.
	 * (New keys cannot be added to wp_localize_script from this file's
	 * scope; i18n[key] wins when a translation exists.)
	 */
	function tx(key, fallback) {
		return i18n[key] || fallback;
	}
	var applyNonceCache = {};

	/**
	 * Fields that need an explicit insert placement when applying.
	 */
	function placementFields() {
		return ['h1', 'introduction', 'faq', 'cta'];
	}

	/**
	 * Get the per-post apply nonce: prefer the nonce rendered on the post
	 * <option>, mint one via /ai/apply-nonce when it is not available.
	 */
	function getApplyNonce(postId) {
		if (applyNonceCache[postId]) {
			return Promise.resolve(applyNonceCache[postId]);
		}
		var nonce = '';
		document.querySelectorAll('option[data-apply-nonce]').forEach(function (opt) {
			if (parseInt(opt.value, 10) === postId && opt.getAttribute('data-apply-nonce')) {
				nonce = opt.getAttribute('data-apply-nonce');
			}
		});
		if (nonce) {
			applyNonceCache[postId] = nonce;
			return Promise.resolve(nonce);
		}
		return api('ai/apply-nonce?post_id=' + encodeURIComponent(postId)).then(function (data) {
			applyNonceCache[postId] = data.nonce;
			return data.nonce;
		});
	}

	/**
	 * Populate the review modal with an optimize preview and open it.
	 * Reads canonical current_value/suggested_value first, legacy
	 * current/suggestion second. Text is set via textContent so AI output
	 * can never inject HTML.
	 */
	function openReviewModal(postId, field, data) {
		var modal = document.getElementById('lbai-opt-modal');
		if (!modal) {
			return;
		}
		document.getElementById('lbai-opt-current').textContent = data.current_value || data.current || '';
		document.getElementById('lbai-opt-suggestion').textContent = data.suggested_value || data.suggestion || '';
		var wrap = document.getElementById('lbai-opt-placement-wrap');
		if (wrap) {
			wrap.hidden = placementFields().indexOf(field) === -1;
		}
		var applyBtn = document.getElementById('lbai-opt-apply');
		if (applyBtn) {
			// internal_links is advisory-only: the optimizer refuses to
			// apply it, so the button is hidden for that field.
			applyBtn.hidden = (field === 'internal_links');
		}
		var undoBtn = document.getElementById('lbai-opt-undo');
		if (undoBtn) {
			undoBtn.hidden = true;
		}
		pendingUndo = null;
		pendingApply = {
			post_id: postId,
			field: field,
			value: data.suggested_value || data.suggestion || ''
		};
		openModal(modal);
	}

	/**
	 * Wire the review modal once (safe to call from several init functions).
	 */
	function wireReviewModal() {
		var modal = document.getElementById('lbai-opt-modal');
		if (!modal || modal.dataset.lbaiWired) {
			return;
		}
		modal.dataset.lbaiWired = '1';
		var applyBtn = document.getElementById('lbai-opt-apply');
		var undoBtn = document.getElementById('lbai-opt-undo');
		var placementWrap = document.getElementById('lbai-opt-placement-wrap');
		var placementSel = document.getElementById('lbai-opt-placement');

		modal.querySelectorAll('[data-lbai-modal-close]').forEach(function (el) {
			el.addEventListener('click', function () {
				closeModal(modal);
			});
		});
		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && !modal.hidden) {
				closeModal(modal);
			}
		});

		if (!applyBtn) {
			return;
		}
		applyBtn.addEventListener('click', function () {
			if (!pendingApply) {
				return;
			}
			if (!window.confirm(t('confirmApply'))) {
				return;
			}
			var body = {
				post_id: pendingApply.post_id,
				field: pendingApply.field,
				value: pendingApply.value
			};
			if (placementWrap && !placementWrap.hidden && placementSel) {
				body.placement = placementSel.value;
			}
			busy(applyBtn, true, t('saving'));
			getApplyNonce(pendingApply.post_id).then(function (nonce) {
				body.apply_nonce = nonce;
				return api('ai/apply', { method: 'POST', body: body });
			}).then(function (data) {
				// Keep the modal open and offer undo for the applied change.
				pendingUndo = { post_id: pendingApply.post_id, field: pendingApply.field };
				pendingApply = null;
				applyBtn.hidden = true;
				if (undoBtn) {
					undoBtn.hidden = false;
				}
				var msg = t('applied');
				if (data && data.revision_id) {
					msg += ' (revision #' + data.revision_id + ')';
				}
				toast(msg, 'success');
			}).catch(function (err) {
				toast(err.message, 'error');
			}).finally(function () {
				busy(applyBtn, false);
			});
		});

		if (undoBtn) {
			undoBtn.addEventListener('click', function () {
				if (!pendingUndo) {
					return;
				}
				if (!window.confirm(tx('confirmUndo', 'Undo the last applied change and restore the previous value?'))) {
					return;
				}
				var target = pendingUndo;
				busy(undoBtn, true, t('saving'));
				getApplyNonce(target.post_id).then(function (nonce) {
					return api('ai/undo', {
						method: 'POST',
						body: {
							post_id: target.post_id,
							field: target.field,
							apply_nonce: nonce
						}
					});
				}).then(function () {
					pendingUndo = null;
					undoBtn.hidden = true;
					if (applyBtn) {
						applyBtn.hidden = false;
					}
					closeModal(modal);
					toast(tx('undone', 'Change undone. The previous value was restored.'), 'success');
				}).catch(function (err) {
					toast(err.message, 'error');
				}).finally(function () {
					busy(undoBtn, false);
				});
			});
		}
	}

	/* ---------- optimizer ---------- */

	function initOptimizer() {
		var form = document.getElementById('lbai-optimizer-form');
		if (!form) {
			return;
		}
		var postSel = document.getElementById('lbai-opt-post');
		var fieldSel = document.getElementById('lbai-opt-field');
		var langSel = document.getElementById('lbai-opt-lang');
		var genBtn = document.getElementById('lbai-opt-generate');
		var status = document.getElementById('lbai-opt-status');

		// Deep link from audit "Fix with AI".
		var params = new URLSearchParams(window.location.search);
		if (params.get('post_id')) {
			postSel.value = params.get('post_id');
		}
		if (params.get('field')) {
			fieldSel.value = params.get('field');
		}

		function generate(field) {
			var postId = parseInt(postSel.value, 10) || 0;
			if (!postId) {
				toast(t('selectPage'), 'error');
				return;
			}
			field = field || fieldSel.value;
			busy(genBtn, true, t('generating'));
			setStatus(status, t('generating'));
			api('ai/optimize', {
				method: 'POST',
				body: { post_id: postId, field: field, language: langSel.value }
			}).then(function (data) {
				openReviewModal(postId, field, data);
				setStatus(status, '');
			}).catch(function (err) {
				setStatus(status, '');
				toast(err.message, 'error');
			}).finally(function () {
				busy(genBtn, false);
			});
		}

		form.addEventListener('submit', function (e) {
			e.preventDefault();
			generate();
		});

		document.querySelectorAll('.lbai-quick-action').forEach(function (btn) {
			btn.addEventListener('click', function () {
				generate(btn.dataset.field);
			});
		});

		wireReviewModal();
	}

	function openModal(modal) {
		modal.hidden = false;
		var close = modal.querySelector('.lbai-modal__close');
		if (close) {
			close.focus();
		}
	}

	function closeModal(modal) {
		modal.hidden = true;
	}

	/* ---------- local seo (consistency) ---------- */

	function initLocal() {
		var btn = document.getElementById('lbai-consistency-run');
		if (btn) {
			btn.addEventListener('click', function () {
				runConsistency(document.getElementById('lbai-consistency-result'), btn);
			});
		}
	}

	/* ---------- content ---------- */

	var lastContentParams = null;

	function initContent() {
		var form = document.getElementById('lbai-content-form');
		if (!form) {
			return;
		}
		var genBtn = document.getElementById('lbai-content-generate');
		var status = document.getElementById('lbai-content-status');
		var card = document.getElementById('lbai-content-result-card');
		var editor = document.getElementById('lbai-content-editor');

		function generate() {
			var params = {
				type: document.getElementById('lbai-content-type').value,
				topic: document.getElementById('lbai-content-topic').value.trim(),
				location: document.getElementById('lbai-content-location').value.trim(),
				language: document.getElementById('lbai-content-lang').value
			};
			if (!params.topic) {
				return;
			}
			lastContentParams = params;
			busy(genBtn, true, t('generating'));
			setStatus(status, t('generating'));
			api('ai/content', {
				method: 'POST',
				body: { type: params.type, params: params, language: params.language }
			}).then(function (data) {
				editor.value = data.content || '';
				card.hidden = false;
				setStatus(status, '');
				card.scrollIntoView({ block: 'nearest' });
			}).catch(function (err) {
				setStatus(status, '');
				toast(err.message, 'error');
			}).finally(function () {
				busy(genBtn, false);
			});
		}

		form.addEventListener('submit', function (e) {
			e.preventDefault();
			generate();
		});

		document.getElementById('lbai-content-regenerate').addEventListener('click', generate);

		document.getElementById('lbai-content-copy').addEventListener('click', function () {
			copyText(editor.value);
		});

		document.getElementById('lbai-content-open-editor').addEventListener('click', function () {
			if (editor.value) {
				copyText(editor.value);
			}
		});

		document.querySelectorAll('.lbai-transform').forEach(function (btn) {
			btn.addEventListener('click', function () {
				var text = editor.value.trim();
				if (!text) {
					return;
				}
				busy(btn, true, t('generating'));
				var body = { action: btn.dataset.action, text: text };
				if (btn.dataset.arg) {
					body.args = { tone: btn.dataset.arg, target_language: btn.dataset.arg };
				}
				api('ai/transform', { method: 'POST', body: body }).then(function (data) {
					// Canonical key is 'result'; 'content' is kept as a legacy fallback.
					var transformed = data.result || data.content || '';
					if (transformed) {
						editor.value = transformed;
						toast(t('applied'), 'success');
					}
				}).catch(function (err) {
					toast(err.message, 'error');
				}).finally(function () {
					busy(btn, false);
				});
			});
		});
	}

	/* ---------- schema ---------- */

	function initSchema() {
		var previewBtn = document.getElementById('lbai-schema-preview-btn');
		if (!previewBtn) {
			return;
		}
		var typeSel = document.getElementById('lbai-schema-preview-type');
		var pre = document.getElementById('lbai-schema-preview');
		var previewCard = document.getElementById('lbai-schema-preview-card');
		var errorsEl = document.getElementById('lbai-schema-errors');
		var saveBtn = document.getElementById('lbai-schema-save');
		var enabledBox = document.getElementById('lbai-schema-enabled');
		var status = document.getElementById('lbai-schema-status');

		function selectedTypes() {
			return Array.prototype.map.call(
				document.querySelectorAll('.lbai-schema-type:checked'),
				function (el) { return el.value; }
			);
		}

		previewBtn.addEventListener('click', function () {
			busy(previewBtn, true, t('loading'));
			api('schema/preview?type=' + encodeURIComponent(typeSel.value)).then(function (data) {
				var jsonld = data.jsonld || data;
				pre.textContent = typeof jsonld === 'string' ? jsonld : JSON.stringify(jsonld, null, 2);
				previewCard.hidden = false;
				if (data.errors && data.errors.length) {
					errorsEl.hidden = false;
					errorsEl.innerHTML = '<div class="notice notice-error lbai-notice"><p>' +
						data.errors.map(esc).join('<br>') + '</p></div>';
				} else {
					errorsEl.hidden = true;
					errorsEl.innerHTML = '';
				}
			}).catch(function (err) {
				toast(err.message, 'error');
			}).finally(function () {
				busy(previewBtn, false);
			});
		});

		saveBtn.addEventListener('click', function () {
			busy(saveBtn, true, t('saving'));
			setStatus(status, t('saving'));
			api('schema/save', {
				method: 'POST',
				body: { enabled: enabledBox.checked, types: selectedTypes() }
			}).then(function () {
				setStatus(status, t('saved'));
				toast(t('saved'), 'success');
			}).catch(function (err) {
				setStatus(status, '');
				toast(err.message, 'error');
			}).finally(function () {
				busy(saveBtn, false);
			});
		});
	}

	/* ---------- keywords ---------- */

	function initKeywords() {
		var form = document.getElementById('lbai-keywords-form');
		if (!form) {
			return;
		}
		var genBtn = document.getElementById('lbai-kw-generate');
		var status = document.getElementById('lbai-kw-status');
		var results = document.getElementById('lbai-kw-results');
		var groups = document.getElementById('lbai-kw-groups');

		form.addEventListener('submit', function (e) {
			e.preventDefault();
			busy(genBtn, true, t('generating'));
			setStatus(status, t('generating'));
			api('ai/keywords', {
				method: 'POST',
				body: {
					business_type: document.getElementById('lbai-kw-type').value.trim(),
					service: document.getElementById('lbai-kw-service').value.trim(),
					city: document.getElementById('lbai-kw-city').value.trim(),
					region: document.getElementById('lbai-kw-region').value.trim(),
					country: document.getElementById('lbai-kw-country').value.trim(),
					language: document.getElementById('lbai-kw-lang').value
				}
			}).then(function (data) {
				var kw = data.keywords || data.groups || {};
				var order = ['primary', 'secondary', 'long_tail', 'questions', 'local_intent'];
				var labels = {
					primary: 'Primary keywords',
					secondary: 'Secondary keywords',
					long_tail: 'Long-tail keywords',
					questions: 'Question keywords',
					local_intent: 'Local intent keywords'
				};
				var html = '';
				order.forEach(function (key) {
					var items = kw[key] || [];
					if (!items.length) {
						return;
					}
					html += '<div class="lbai-card lbai-kw-group"><h3 class="lbai-card__title">' + esc(labels[key]) + '</h3>' +
						'<ul class="lbai-list">' +
						items.map(function (item) {
							return '<li><span>' + esc(item) + '</span>' +
								'<button type="button" class="button button-small lbai-btn lbai-kw-copy" data-kw="' + esc(item) + '">Copy</button></li>';
						}).join('') + '</ul></div>';
				});
				groups.innerHTML = html || '<p>' + esc(t('noResults')) + '</p>';
				results.hidden = false;
				setStatus(status, '');
			}).catch(function (err) {
				setStatus(status, '');
				toast(err.message, 'error');
			}).finally(function () {
				busy(genBtn, false);
			});
		});

		groups.addEventListener('click', function (e) {
			var btn = e.target.closest('.lbai-kw-copy');
			if (btn) {
				copyText(btn.dataset.kw);
			}
		});
	}

	/* ---------- reports ---------- */

	function initReports() {
		var stats = document.getElementById('lbai-report-stats');
		if (!stats) {
			return;
		}
		api('reports/summary').then(function (data) {
			document.getElementById('lbai-rep-score').textContent = data.score != null ? data.score : '–';
			document.getElementById('lbai-rep-fixed').textContent = data.issues_fixed || 0;
			document.getElementById('lbai-rep-remaining').textContent = data.issues_remaining || 0;
			document.getElementById('lbai-rep-pages').textContent = data.pages_analyzed || 0;
			document.getElementById('lbai-rep-ai').textContent = data.ai_generations || 0;

			var history = document.getElementById('lbai-rep-history');
			var entries = data.score_history || [];
			history.innerHTML = entries.length
				? entries.map(function (h) {
					return '<li>' + esc(h.date || '') + ' — <strong>' + esc(String(h.score != null ? h.score : '')) + '</strong></li>';
				}).join('')
				: '<li class="lbai-list__empty">' + esc(t('noResults')) + '</li>';

			var imp = document.getElementById('lbai-rep-improvements');
			var items = data.improvements || [];
			imp.innerHTML = items.length
				? items.map(function (item) {
					return '<li>' + esc(item.text || item) +
						(item.date ? '<span class="lbai-list__meta">' + esc(item.date) + '</span>' : '') + '</li>';
				}).join('')
				: '<li class="lbai-list__empty">' + esc(t('noResults')) + '</li>';
		}).catch(function (err) {
			toast(err.message, 'error');
		});

		document.querySelectorAll('[data-lbai-export]').forEach(function (btn) {
			btn.addEventListener('click', function () {
				var report = btn.dataset.lbaiExport;
				download(
					base + 'reports/export?format=csv&report=' + encodeURIComponent(report),
					'localboost-' + report + '.csv'
				).catch(function (err) {
					toast(err.message, 'error');
				});
			});
		});

		var wlSave = document.getElementById('lbai-whitelabel-save');
		if (wlSave) {
			wlSave.addEventListener('click', function () {
				busy(wlSave, true, t('saving'));
				api('settings', {
					method: 'POST',
					body: {
						settings: {
							lbai_white_label_name: document.getElementById('lbai_white_label_name').value,
							lbai_white_label_logo: document.getElementById('lbai_white_label_logo').value
						}
					}
				}).then(function () {
					setStatus(document.getElementById('lbai-whitelabel-status'), t('saved'));
					toast(t('saved'), 'success');
				}).catch(function (err) {
					toast(err.message, 'error');
				}).finally(function () {
					busy(wlSave, false);
				});
			});
		}
	}

	/* ---------- ai settings ---------- */

	function initAISettings() {
		var page = document.querySelector('[data-lbai-page="ai-settings"]');
		if (!page) {
			return;
		}
		var providers = {};
		try {
			providers = JSON.parse(page.dataset.lbaiProviders || '{}');
		} catch (e) {
			providers = {};
		}

		var modelSel = document.getElementById('lbai_ai_model');
		var tempInput = document.getElementById('lbai_ai_temperature');
		var tempOut = document.getElementById('lbai-temperature-value');
		var keyInput = document.getElementById('lbai_api_key');
		var saveBtn = document.getElementById('lbai-ai-save');
		var testBtn = document.getElementById('lbai-ai-test');
		var status = document.getElementById('lbai-ai-status');

		function currentProvider() {
			var checked = document.querySelector('input[name="lbai_ai_provider"]:checked');
			return checked ? checked.value : '';
		}

		function fillModels(provider) {
			var info = providers[provider] || {};
			var models = info.models || {};
			var current = modelSel.value;
			modelSel.innerHTML = '';
			Object.keys(models).forEach(function (id) {
				var opt = document.createElement('option');
				opt.value = id;
				opt.textContent = models[id];
				modelSel.appendChild(opt);
			});
			if (current) {
				var exists = Array.prototype.some.call(modelSel.options, function (o) { return o.value === current; });
				if (!exists) {
					var opt = document.createElement('option');
					opt.value = current;
					opt.textContent = current;
					modelSel.appendChild(opt);
				}
				modelSel.value = current;
			}
		}

		var baseUrlRow = document.getElementById('lbai-base-url-row');
		var baseUrlInput = document.getElementById('lbai_provider_base_url');

		function syncBaseUrl(provider) {
			if (!baseUrlRow || !baseUrlInput) {
				return;
			}
			var show = provider === 'meta' || provider === 'opensource';
			baseUrlRow.hidden = !show;
			if (show) {
				baseUrlInput.value = provider === 'meta'
					? (baseUrlInput.dataset.lbaiMetaUrl || '')
					: (baseUrlInput.dataset.lbaiOpensourceUrl || '');
			}
		}

		document.querySelectorAll('input[name="lbai_ai_provider"]').forEach(function (radio) {
			radio.addEventListener('change', function () {
				document.querySelectorAll('.lbai-provider-card').forEach(function (card) {
					card.classList.remove('is-selected');
				});
				var card = radio.closest('.lbai-provider-card');
				if (card) {
					card.classList.add('is-selected');
				}
				fillModels(radio.value);
				syncBaseUrl(radio.value);
			});
		});

		if (currentProvider()) {
			fillModels(currentProvider());
			syncBaseUrl(currentProvider());
		}

		tempInput.addEventListener('input', function () {
			tempOut.textContent = tempInput.value;
		});

		saveBtn.addEventListener('click', function () {
			var provider = currentProvider();
			if (!provider) {
				toast(t('error'), 'error');
				return;
			}
			busy(saveBtn, true, t('saving'));
			setStatus(status, t('saving'));
			var settings = {
				lbai_ai_provider: provider,
				lbai_ai_model: modelSel.value,
				lbai_ai_temperature: parseFloat(tempInput.value),
				lbai_ai_max_tokens: parseInt(document.getElementById('lbai_ai_max_tokens').value, 10)
			};
			var key = keyInput.value.trim();
			if (key !== '') {
				settings['lbai_api_key_' + provider] = key;
			}
			var baseUrlInput = document.getElementById('lbai_provider_base_url');
			if (baseUrlInput && (provider === 'meta' || provider === 'opensource')) {
				settings[provider === 'meta' ? 'lbai_meta_base_url' : 'lbai_opensource_base_url'] = baseUrlInput.value.trim();
			}
			api('settings', { method: 'POST', body: { settings: settings } }).then(function () {
				keyInput.value = '';
				keyInput.placeholder = '••••••••';
				setStatus(status, t('saved'));
				toast(t('saved'), 'success');
			}).catch(function (err) {
				setStatus(status, '');
				toast(err.message, 'error');
			}).finally(function () {
				busy(saveBtn, false);
			});
		});

		testBtn.addEventListener('click', function () {
			var provider = currentProvider();
			if (!provider) {
				toast(t('error'), 'error');
				return;
			}
			busy(testBtn, true, t('testingConnection'));
			setStatus(status, t('testingConnection'));
			api('ai/test-connection', { method: 'POST', body: { provider: provider } }).then(function (data) {
				if (data && data.valid) {
					var msg = t('connectionOk') + (data && data.model ? ' (' + data.model + ')' : '');
					setStatus(status, msg);
					toast(msg, 'success');
				} else {
					var failMsg = (data && data.message) ? data.message : t('connectionFailed');
					setStatus(status, failMsg);
					toast(failMsg, 'error');
				}
			}).catch(function (err) {
				setStatus(status, t('connectionFailed') + ': ' + err.message);
				toast(t('connectionFailed'), 'error');
			}).finally(function () {
				busy(testBtn, false);
			});
		});
	}

	/* ---------- general settings ---------- */

	function initSettings() {
		var btn = document.getElementById('lbai-export-settings');
		if (!btn) {
			return;
		}
		btn.addEventListener('click', function () {
			busy(btn, true, t('loading'));
			api('settings').then(function (data) {
				var blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
				var a = document.createElement('a');
				a.href = URL.createObjectURL(blob);
				a.download = 'localboost-ai-settings.json';
				document.body.appendChild(a);
				a.click();
				a.remove();
				setTimeout(function () {
					URL.revokeObjectURL(a.href);
				}, 4000);
			}).catch(function (err) {
				toast(err.message, 'error');
			}).finally(function () {
				busy(btn, false);
			});
		});
	}

	/* ---------- upgrade ---------- */

	function initUpgrade() {
		var btn = document.getElementById('lbai-license-save');
		if (!btn) {
			return;
		}
		btn.addEventListener('click', function () {
			busy(btn, true, t('saving'));
			api('settings', {
				method: 'POST',
				body: { settings: { lbai_license_key: document.getElementById('lbai_license_key').value.trim() } }
			}).then(function () {
				setStatus(document.getElementById('lbai-license-status'), t('saved'));
				toast(t('saved'), 'success');
			}).catch(function (err) {
				toast(err.message, 'error');
			}).finally(function () {
				busy(btn, false);
			});
		});
	}

	/* ---------- onboarding wizard ---------- */

	function initOnboarding() {
		var page = document.querySelector('[data-lbai-page="onboarding"]');
		if (!page) {
			return;
		}
		var providers = {};
		try {
			providers = JSON.parse(page.dataset.lbaiProviders || '{}');
		} catch (e) {
			providers = {};
		}

		var steps = Array.prototype.slice.call(page.querySelectorAll('.lbai-ob-step'));
		var total = steps.length;
		var current = 1;
		var bar = document.getElementById('lbai-ob-bar');
		var barWrap = document.getElementById('lbai-ob-bar-wrap');
		var progress = document.getElementById('lbai-ob-progress');
		var chosenProvider = '';
		var auditResult = null;

		function show(step) {
			current = Math.max(1, Math.min(total, step));
			steps.forEach(function (s) {
				s.hidden = parseInt(s.dataset.step, 10) !== current;
			});
			var pct = Math.round((current / total) * 100);
			bar.style.width = pct + '%';
			barWrap.setAttribute('aria-valuenow', pct);
			progress.textContent = t('stepOf').replace('%1$d', current).replace('%2$d', total);
			var visible = page.querySelector('.lbai-ob-step:not([hidden]) h1');
			if (visible) {
				visible.setAttribute('tabindex', '-1');
				visible.focus({ preventScroll: true });
			}
			window.scrollTo(0, 0);
		}

		page.querySelectorAll('.lbai-ob-next').forEach(function (btn) {
			btn.addEventListener('click', function () {
				show(current + 1);
			});
		});
		page.querySelectorAll('.lbai-ob-prev').forEach(function (btn) {
			btn.addEventListener('click', function () {
				show(current - 1);
			});
		});

		// Step 2: save business info.
		document.getElementById('lbai-ob-save-business').addEventListener('click', function () {
			var btn = this;
			var name = document.getElementById('lbai-ob-name').value.trim();
			var city = document.getElementById('lbai-ob-city').value.trim();
			if (!name || !city) {
				toast(t('error'), 'error');
				return;
			}
			busy(btn, true, t('saving'));
			api('settings', {
				method: 'POST',
				body: {
					settings: {
						lbai_business_name: name,
						lbai_city: city,
						lbai_phone: document.getElementById('lbai-ob-phone').value.trim(),
						lbai_website: document.getElementById('lbai-ob-website').value.trim()
					}
				}
			}).then(function () {
				show(3);
			}).catch(function (err) {
				toast(err.message, 'error');
			}).finally(function () {
				busy(btn, false);
			});
		});

		// Step 3: provider choice.
		var providerNext = document.getElementById('lbai-ob-provider-next');
		page.querySelectorAll('input[name="lbai_ob_provider"]').forEach(function (radio) {
			radio.addEventListener('change', function () {
				chosenProvider = radio.value;
				providerNext.disabled = false;
				syncObKeyStep();
				document.querySelectorAll('.lbai-provider-card').forEach(function (card) {
					card.classList.remove('is-selected');
				});
				var card = radio.closest('.lbai-provider-card');
				if (card) {
					card.classList.add('is-selected');
				}
				api('settings', { method: 'POST', body: { settings: { lbai_ai_provider: chosenProvider } } }).catch(function () {});
			});
		});

		// Step 4: connect key + test.
		var keyStatus = document.getElementById('lbai-ob-key-status');
		var keyDesc = document.getElementById('lbai-ob-key-desc');
		var keyInput = document.getElementById('lbai-ob-key');
		var KEYLESS_PROVIDERS = ['opensource'];
		function obNeedsKey() {
			return KEYLESS_PROVIDERS.indexOf(chosenProvider) === -1;
		}
		function syncObKeyStep() {
			if (!keyInput) {
				return;
			}
			var needsKey = obNeedsKey();
			keyInput.disabled = !needsKey;
			keyInput.placeholder = needsKey ? keyInput.getAttribute('placeholder') : '';
			if (keyDesc) {
				keyDesc.textContent = needsKey
					? keyDesc.getAttribute('data-lbai-with-key') || keyDesc.textContent
					: (keyDesc.getAttribute('data-lbai-no-key') || '');
			}
		}
		document.getElementById('lbai-ob-test-key').addEventListener('click', function () {
			var btn = this;
			var key = keyInput.value.trim();
			if (!chosenProvider) {
				toast(t('error'), 'error');
				return;
			}
			if (obNeedsKey() && !key) {
				toast(t('error'), 'error');
				return;
			}
			busy(btn, true, t('testingConnection'));
			setStatus(keyStatus, t('testingConnection'));
			var payload = { settings: {} };
			if (key !== '') {
				payload.settings['lbai_api_key_' + chosenProvider] = key;
			}
			api('settings', { method: 'POST', body: payload }).then(function () {
				return api('ai/test-connection', { method: 'POST', body: { provider: chosenProvider } });
			}).then(function (data) {
				// Never treat a non-valid response as success, even if the
				// request itself resolved (defense in depth: the REST endpoint
				// now also returns a proper error for valid:false).
				if (!data || data.valid !== true) {
					throw new Error((data && data.message) || t('connectionFailed'));
				}
				setStatus(keyStatus, t('connectionOk'));
				keyInput.value = '';
				show(5);
			}).catch(function (err) {
				setStatus(keyStatus, t('connectionFailed') + ': ' + err.message);
			}).finally(function () {
				busy(btn, false);
			});
		});
		document.getElementById('lbai-ob-skip-key').addEventListener('click', function () {
			show(5);
		});

		// Step 5: first scan.
		var scanStatus = document.getElementById('lbai-ob-scan-status');
		document.getElementById('lbai-ob-run-scan').addEventListener('click', function () {
			var btn = this;
			var postId = parseInt(document.getElementById('lbai-ob-post').value, 10) || 0;
			if (!postId) {
				toast(t('selectPage'), 'error');
				return;
			}
			busy(btn, true, t('analyzing'));
			setStatus(scanStatus, t('analyzing'));
			api('audit', { method: 'POST', body: { post_id: postId } }).then(function (data) {
				auditResult = data;
				var issues = (data.issues || []).filter(function (i) {
					return i.severity === 'critical' || i.severity === 'warning';
				}).slice(0, 5);
				var list = document.getElementById('lbai-ob-issues');
				list.innerHTML = issues.length
					? issues.map(function (i) {
						return '<li>' + badge(i.severity) + ' <strong>' + esc(i.problem || '') + '</strong>' +
							(i.action ? '<span class="lbai-list__meta">' + esc(i.action) + '</span>' : '') + '</li>';
					}).join('')
					: '<li class="lbai-list__empty">✓</li>';
				show(6);
			}).catch(function (err) {
				setStatus(scanStatus, err.message);
			}).finally(function () {
				busy(btn, false);
			});
		});

		// Step 7: finish.
		document.getElementById('lbai-ob-finish').addEventListener('click', function () {
			var btn = this;
			busy(btn, true, t('loading'));
			// Best effort: the REST layer may expose onboarding/finish.
			api('onboarding/finish', { method: 'POST' }).catch(function () {}).then(function () {
				window.location.href = 'admin.php?page=lbai-dashboard';
			});
		});

		show(1);
	}

	/* ---------- boot ---------- */

	document.addEventListener('DOMContentLoaded', function () {
		var page = document.querySelector('[data-lbai-page]');
		if (!page) {
			return;
		}
		var name = page.dataset.lbaiPage;
		var inits = {
			dashboard: initDashboard,
			audit: initAudit,
			optimizer: initOptimizer,
			local: initLocal,
			content: initContent,
			schema: initSchema,
			keywords: initKeywords,
			reports: initReports,
			'ai-settings': initAISettings,
			settings: initSettings,
			upgrade: initUpgrade,
			onboarding: initOnboarding
		};
		if (inits[name]) {
			try {
				inits[name]();
			} catch (e) {
				toast(t('error'), 'error');
			}
		}
	});
})();
