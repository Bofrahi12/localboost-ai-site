<?php
/**
 * Versioned database migrations.
 *
 * v1.1.0 adds the usage-reservation columns (status, provider, model,
 * tokens, error) plus supporting indexes to {prefix}lbai_usage. Existing
 * rows are backfilled to status='completed' so historical usage keeps
 * counting exactly as before; no data is deleted or reinterpreted.
 *
 * v1.2.0 adds composite indexes to {prefix}lbai_audits for the reporter's
 * grouped queries. Additive only.
 *
 * @package LocalBoostAI\Database
 */

namespace LocalBoostAI\Database;

if (!defined('ABSPATH')) {
    exit;
}

class Migrations {

    const DB_VERSION = '1.2.0';

    /**
     * Run any pending migrations, step by step.
     */
    public function migrate(): void {
        $stored = get_option('lbai_db_version', '0');
        if (version_compare($stored, '1.0.0', '<')) {
            $this->migrate_to_1_0_0();
            $stored = '1.0.0';
            update_option('lbai_db_version', $stored);
        }
        if (version_compare($stored, '1.1.0', '<')) {
            $this->migrate_to_1_1_0();
            update_option('lbai_db_version', '1.1.0');
        }
        if (version_compare($stored, '1.2.0', '<')) {
            $this->migrate_to_1_2_0();
            update_option('lbai_db_version', '1.2.0');
        }
    }

    /**
     * v1.0.0: create the audits, usage and reports tables.
     *
     * The usage table is created with the full v1.1.0 column set so fresh
     * installs never need the 1.1.0 ALTER pass.
     */
    private function migrate_to_1_0_0(): void {
        global $wpdb;

        if (!function_exists('dbDelta')) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        }

        $charset_collate = $wpdb->get_charset_collate();

        $audits  = $wpdb->prefix . 'lbai_audits';
        $usage   = $wpdb->prefix . 'lbai_usage';
        $reports = $wpdb->prefix . 'lbai_reports';

        // Table names are hardcoded plugin constants; no user input involved.
        dbDelta(
            "CREATE TABLE {$audits} (
                id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                post_id bigint(20) UNSIGNED NULL DEFAULT NULL,
                url varchar(255) NOT NULL DEFAULT '',
                score tinyint NOT NULL DEFAULT 0,
                categories text NULL,
                issues longtext NULL,
                created_at datetime NOT NULL,
                PRIMARY KEY  (id),
                KEY post_id (post_id),
                KEY created_at (created_at)
            ) {$charset_collate};"
        );

        dbDelta(
            "CREATE TABLE {$usage} (
                id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                feature varchar(50) NOT NULL,
                amount int NOT NULL DEFAULT 1,
                status varchar(20) NOT NULL DEFAULT 'completed',
                provider varchar(60) NOT NULL DEFAULT '',
                model varchar(80) NOT NULL DEFAULT '',
                tokens int NOT NULL DEFAULT 0,
                error text NULL,
                created_at datetime NOT NULL,
                PRIMARY KEY  (id),
                KEY feature_created (feature, created_at),
                KEY status (status)
            ) {$charset_collate};"
        );

        dbDelta(
            "CREATE TABLE {$reports} (
                id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                type varchar(50) NOT NULL,
                title varchar(191) NOT NULL DEFAULT '',
                data longtext NULL,
                created_at datetime NOT NULL,
                PRIMARY KEY  (id),
                KEY type (type)
            ) {$charset_collate};"
        );
    }

    /**
     * v1.1.0: usage reservation columns + indexes.
     *
     * Every ALTER is guarded by an existence check so the migration is
     * safe to re-run, and every change is additive — existing data and the
     * pre-existing single-column keys are left untouched.
     */
    private function migrate_to_1_1_0(): void {
        global $wpdb;

        $usage = $wpdb->prefix . 'lbai_usage';

        $columns = array(
            'status'   => "ADD COLUMN status varchar(20) NOT NULL DEFAULT 'completed'",
            'provider' => "ADD COLUMN provider varchar(60) NOT NULL DEFAULT ''",
            'model'    => "ADD COLUMN model varchar(80) NOT NULL DEFAULT ''",
            'tokens'   => "ADD COLUMN tokens int NOT NULL DEFAULT 0",
            'error'    => "ADD COLUMN error text NULL",
        );
        foreach ($columns as $column => $ddl) {
            if (!$this->column_exists($usage, $column)) {
                // Table name is prefix + hardcoded suffix; DDL is static.
                $wpdb->query("ALTER TABLE `{$usage}` {$ddl}");
            }
        }

        // Backfill: rows written before the status column existed represent
        // completed usage and must keep counting toward quota history.
        $wpdb->query(
            "UPDATE `{$usage}` SET `status` = 'completed' WHERE `status` IS NULL OR `status` = ''"
        );

        $indexes = array(
            'feature_created' => 'ADD INDEX feature_created (feature, created_at)',
            'status'          => 'ADD INDEX status (status)',
        );
        foreach ($indexes as $index => $ddl) {
            if (!$this->index_exists($usage, $index)) {
                // Table name is prefix + hardcoded suffix; DDL is static.
                $wpdb->query("ALTER TABLE `{$usage}` {$ddl}");
            }
        }
    }

    /**
     * v1.2.0: composite indexes on the audits table for the reporter's
     * grouped queries (latest audit per post, date-range scans).
     *
     * Every ALTER is guarded by an existence check so the migration is
     * safe to re-run, and every change is additive.
     */
    private function migrate_to_1_2_0(): void {
        global $wpdb;

        $audits = $wpdb->prefix . 'lbai_audits';

        $indexes = array(
            'post_id_id'     => 'ADD INDEX post_id_id (post_id, id)',
            'created_at_id'  => 'ADD INDEX created_at_id (created_at, id)',
            'created_at_post' => 'ADD INDEX created_at_post (created_at, post_id)',
        );
        foreach ($indexes as $index => $ddl) {
            if (!$this->index_exists($audits, $index)) {
                // Table name is prefix + hardcoded suffix; DDL is static.
                $wpdb->query("ALTER TABLE `{$audits}` {$ddl}");
            }
        }
    }

    /**
     * Whether a column exists on a table.
     *
     * @param string $table  Full table name (prefix + hardcoded suffix).
     * @param string $column Column name (static, from the migration map).
     * @return bool
     */
    private function column_exists(string $table, string $column): bool {
        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare("SHOW COLUMNS FROM `{$table}` LIKE %s", $column)
        );
        return null !== $row;
    }

    /**
     * Whether an index exists on a table.
     *
     * @param string $table Full table name (prefix + hardcoded suffix).
     * @param string $index Index name (static, from the migration map).
     * @return bool
     */
    private function index_exists(string $table, string $index): bool {
        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare("SHOW INDEX FROM `{$table}` WHERE Key_name = %s", $index)
        );
        return null !== $row;
    }
}
