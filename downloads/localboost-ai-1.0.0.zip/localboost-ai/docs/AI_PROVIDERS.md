# AI Providers — LocalBoost AI

LocalBoost AI is **not hard-coded to one provider**. All AI calls go through
`AIProviderInterface`; providers are registered in `Provider_Factory` and new
ones can be added with a filter — no core changes needed.

## Supported providers (v1)

| Provider id | How to get a key | Notes |
|---|---|---|
| `openai` | https://platform.openai.com → API keys | Models like `gpt-4o-mini`, `gpt-4o` |
| `anthropic` | https://console.anthropic.com → API keys | Models like `claude-3-5-sonnet-latest` |
| `gemini` | https://aistudio.google.com → Get API key | Models like `gemini-1.5-flash` |
| `meta` | Meta AI / Llama API access | ⚠️ Verify the current Meta API endpoint and model names in Meta's docs before use — this integration point must be confirmed against Meta's published API. |
| `opensource` | No key needed | Self-hosted OpenAI-compatible server (Ollama, LM Studio, llama.cpp). Set the **Server base URL** in AI Settings (defaults to Ollama's `http://localhost:11434/v1`). Model list is filterable via `lbai_opensource_models`. |

## Connecting a key

1. Go to **LocalBoost AI → AI Settings**.
2. Pick a provider card.
3. Choose a model (list refreshes per provider).
4. Paste the key into the password field and click **Save AI settings**.
   (The `opensource` provider needs no key — just point **Server base URL**
   at your local server.)
5. Click **Test connection** — the plugin sends one minimal request and reports success/failure.

Keys are encrypted at rest (Secure_Store), never rendered back to the browser,
never logged, and never sent anywhere except the provider's API over HTTPS.

## Model choice, temperature, tokens

- **Model**: cheaper/faster models are fine for titles and meta descriptions;
  use stronger models for long content generation.
- **Temperature** (0–2, default 0.7): lower = more factual and consistent,
  higher = more creative. Keep 0.3–0.7 for business content.
- **Max tokens** (default 1000): caps response length and cost. Raise for
  full page drafts, lower for titles/meta.

## Adding a new provider

Implement `AIProviderInterface` and register via the filter:

```php
add_filter( 'lbai_ai_providers', function ( $providers ) {
    // Map a provider id to a class implementing
    // LocalBoostAI\Providers\AI_Provider_Interface.
    $providers['my_provider'] = \MyPlugin\My_Provider::class;
    return $providers;
} );
```

Requirements for the class: implement `AIProviderInterface`
(`generate()`, `test_connection()`, `get_models()`), use `wp_remote_post`
with timeouts, never log keys, and return structured errors the UI can show
in plain language.

## Cost control

- Every generation is counted by the Usage Tracker against the monthly quota.
- Temperature/tokens are per-request; long content costs more.
- Scheduled audits do **not** call AI unless you enable AI re-checks (Pro).
