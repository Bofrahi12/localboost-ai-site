# Configuration — LocalBoost AI

All settings live under **LocalBoost AI** in wp-admin. Options marked 🔒 are
written through the REST API into encrypted storage, never through `options.php`.

## Business profile — Local SEO page

| Option key | Field | Used for |
|---|---|---|
| `lbai_business_name` | Business name | Schema, consistency checker |
| `lbai_business_type` | Business type (schema.org subtype) | Schema `@type` selection |
| `lbai_address` | Street address | Schema `address`, consistency |
| `lbai_city` | City | Schema, keyword defaults |
| `lbai_region` | State / Region | Schema `addressRegion` |
| `lbai_postal_code` | Postal code | Schema `postalCode` |
| `lbai_country` | Country (ISO code) | Schema `addressCountry` |
| `lbai_phone` | Phone | Schema `telephone`, consistency |
| `lbai_email` | Email | Schema `email` |
| `lbai_website` | Website | Schema `url`, consistency |
| `lbai_hours` | Opening hours (free text) | Schema `openingHours` |
| `lbai_services` | Services (one per line) | Schema `makesOffer` / `hasOfferCatalog` |
| `lbai_price_range` | Price range (e.g. `$$`) | Schema `priceRange` |
| `lbai_social_profiles` | Social URLs (one per line) | Schema `sameAs` |
| `lbai_latitude` / `lbai_longitude` | Coordinates (optional) | Schema `geo` |

The **NAP consistency checker** compares the saved name/address/phone/website/hours
against what is actually published on your pages and tells you exactly what to fix.

## AI — AI Settings page

| Option key | Meaning |
|---|---|
| `lbai_ai_provider` | Provider id, e.g. `openai`, `anthropic`, `gemini`, `meta`, `opensource` |
| `lbai_ai_model` | Model id for the chosen provider |
| `lbai_ai_temperature` | 0–2, default 0.7 |
| `lbai_ai_max_tokens` | Default 1000, max 8000 |
| 🔒 `api_key_<provider>` | Encrypted via Secure_Store; never rendered back |

## Monitoring — Settings page

| Option key | Meaning |
|---|---|
| `lbai_monitor_frequency` | `off` / `weekly` / `monthly` — drives one WP-Cron job |
| `lbai_monitored_pages` | Array of post IDs included in scheduled audits |
| `lbai_notify_audit_completed` | Email the admin when a scheduled audit finishes |
| `lbai_notify_critical_issue` | Email when a new critical issue appears |
| `lbai_notify_report_ready` | Email when a scheduled report is ready |
| `lbai_notify_usage_limit` | Email at 80% and 100% of the AI generation quota |

## Licensing / white label — Upgrade & Reports pages

| Option key | Meaning |
|---|---|
| `lbai_license_key` | Pro license key (validation = integration point, see ROADMAP.md) |
| `lbai_white_label_name` | Agency name on reports (Pro) |
| `lbai_white_label_logo` | Logo URL on reports (Pro) |

## Free vs Pro limits

Free: basic audit, **10 AI generations/month**, basic Local SEO, basic schema,
basic reports. Pro: 500 AI generations/month plus advanced audits, models,
reports, monitoring, schema types, agency features and white-label reports.
Limits are enforced by the Usage Tracker; the UI shows
"You have used X of Y AI generations this month" and never silently stops —
actions are blocked with a clear message and an upgrade prompt.

## Rate limiting

Semantics (canonical — see `Rate_Limiter` class docblock): **N requests per W
seconds, sliding window, per bucket**. A request at time T counts against the
limit while `(now - T) < W`; there are no fixed window boundaries.

Bucket key convention: `ai:<user_id>:<provider>` for per-user AI calls
(e.g. `ai:7:openai`), `audit:<user_id>` for audits, `monitor` for the
scheduled monitoring job.

Preferred call pattern (single call — counts the hit atomically with the
check):

```php
if ( ! Rate_Limiter::consume( $bucket, 20, 60 ) ) {
    // deny: more than 20 requests in the last 60 seconds
}
```

The legacy `check()` + `hit()` pair is kept for backward compatibility, but
new code should prefer `consume()`. Note: transient get-then-set is not
atomic, so under extreme concurrency the limit can be overshot by a tiny
amount — a slightly generous limit, never a security bypass. Hard,
billing-relevant quotas are enforced by the Usage Tracker reservation flow
(`reserve()` / `finalize()` / `release()`), not by the rate limiter.
