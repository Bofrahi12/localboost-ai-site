# Install — LocalBoost AI

## Requirements

- WordPress 6.0 or later
- PHP 7.4 or later
- MySQL 5.7+ / MariaDB 10.3+ (whatever your WordPress uses)
- An API key from an AI provider (OpenAI, Anthropic, Google Gemini, Meta AI, or a compatible open-source model endpoint). The key is optional at install time — the audit works without AI, AI features unlock once a key is connected.

## Installation

### From the WordPress admin

1. Go to **Plugins → Add New → Upload Plugin**.
2. Upload the `localboost-ai.zip` file and click **Install Now**.
3. Click **Activate Plugin**.

### Manual (FTP / SFTP)

1. Unzip `localboost-ai.zip`.
2. Upload the `localboost-ai` folder to `/wp-content/plugins/`.
3. Go to **Plugins** in wp-admin and activate **LocalBoost AI**.

## First-run onboarding

After activation, administrators are redirected once to a 7-step wizard:

1. **Welcome** — what the plugin does.
2. **Business information** — name, city, phone, website (saved to Settings).
3. **Choose AI provider** — radio list from the provider registry.
4. **Connect API** — paste your key; it is encrypted at rest and tested live.
5. **Run first SEO scan** — pick your homepage (or most important page).
6. **Recommendations** — top critical/warning issues with plain-language actions.
7. **Finish** — lands on the dashboard.

The whole flow takes under 5 minutes. You can re-run it any time via
`wp-admin/admin.php?page=lbai-onboarding`.

## Verifying the install

- **Menu**: a "LocalBoost AI" top-level menu (chart icon) should appear.
- **Cron**: the plugin schedules at most one monitoring job (`lbai_scheduled_audit`)
  and one usage-reset job (`lbai_usage_reset`). Verify with WP Crontrol or:
  `wp cron event list | grep lbai`
- **REST**: `GET /wp-json/lbai/v1/dashboard` as an admin should return the
  `{success, data}` envelope.

## Uninstall behavior

Deactivating keeps all data. **Deleting** the plugin (which runs `uninstall.php`):

- removes all `lbai_*` options, transients and custom tables,
- deletes stored audit results and usage counters,
- **never touches your posts, pages, media or other content**,
- does not delete data the AI provider may hold — see their privacy policy.

## Troubleshooting

| Symptom | Fix |
|---|---|
| Wizard redirect loops | Delete the `lbai_onboarding_pending` transient; the option `lbai_onboarding_done` gates it. |
| "Connection failed" on API test | Check the key, provider status page, and that your server can make outbound HTTPS requests (`wp_http`). |
| Admin pages look unstyled | Hard-refresh; CSS loads only on LocalBoost screens (`lbai-admin.css`). |
| Scheduled audits never run | WP-Cron needs traffic or a real cron hitting `wp-cron.php`. |
