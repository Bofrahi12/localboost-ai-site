# Known limitations — LocalBoost AI v1.0.0

Honest list of what v1 does **not** do. Nothing here is presented as working
in the UI — gated or missing features say so explicitly.

1. **No keyword search-volume data.** The keyword assistant produces
   AI-generated ideas grouped by intent. Any volume/competition figures would
   require a paid data provider, which is not connected. The UI labels this
   every time.
2. **Mobile checks are limited.** The audit detects what server-side HTML
   analysis can (viewport meta, tap-target hints via markup, responsive
   image attributes). It does not run a real mobile renderer or Core Web
   Vitals lab test.
3. **No PDF export.** Reports export to CSV. PDF is on the roadmap.
4. **Agency multi-site is conceptual.** The architecture anticipates managing
   multiple sites, but v1 operates on a single WordPress installation.
   White-label reports are the only agency surface shipped (Pro).
5. **No payment processing.** The Upgrade page collects a license key; plan
   purchase happens on the vendor website / payment provider. Stripe
   integration is planned, not present.
6. **Meta AI endpoint must be verified.** Provider abstraction includes Meta,
   but Meta's API endpoint and model names change — confirm against Meta's
   current docs before relying on it (see AI_PROVIDERS.md).
7. **AI quality depends on the provider/model.** Suggestions are only as good
   as the model; the review-before-apply flow exists precisely because AI
   output must be checked.
8. **Scheduled audits need WP-Cron.** On low-traffic sites without a real
   cron hitting `wp-cron.php`, weekly/monthly audits may run late.
9. **Schema is only as good as your data.** The generator refuses to invent
   opening hours, geo coordinates or reviews you did not enter — fields left
   empty are omitted, not guessed.
10. **No automatic GDPR compliance.** The plugin minimizes data collection and
    provides export + uninstall deletion, but compliance depends on your
    configuration, provider choice and policies.
11. **English-first admin.** All strings are translatable (`localboost-ai`
    text domain), but only English ships in v1; community translations welcome.
