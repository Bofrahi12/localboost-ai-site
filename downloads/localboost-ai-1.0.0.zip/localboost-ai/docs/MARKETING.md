# Marketing — LocalBoost AI

## Positioning

**LocalBoost AI** — the AI-powered Local SEO assistant for small businesses on
WordPress. Built for owners, not SEOs: it finds problems, explains them in
plain language, and drafts the fix — you approve everything.

Primary markets: US, Canada, UK, France, Germany, Spain, Italy, Netherlands,
Belgium, Portugal. Primary audiences: restaurants, dentists, doctors, lawyers,
real-estate businesses, salons, contractors, plumbers, electricians, cleaning
companies, local shops — plus the agencies and freelancers who serve them.

Tagline: *"Know what's wrong. Fix it with AI. Get found locally."*

## Feature list (marketing copy)

- **One-click SEO audit** — 20+ checks across technical, on-page, local,
  content and structured data, explained in plain English.
- **AI Optimizer** — better titles, meta descriptions, FAQs and calls to
  action, always with your approval first.
- **Local SEO hub** — business info, NAP consistency checker, valid
  Schema.org markup with preview.
- **Content generator** — service pages, FAQs and blog ideas in 7 languages.
- **Keyword ideas** — local keyword inspiration (honestly labelled, no fake data).
- **Reports** — progress your agency can show clients, CSV export included.
- **Your AI, your choice** — OpenAI, Anthropic, Gemini, Meta or open models.
- **Monitoring** — weekly/monthly check-ups with email alerts.

## Pricing structure

| | Free | Pro |
|---|---|---|
| Price | $0 | $19/mo or $190/yr (planned) |
| AI generations | 10/month | 500/month |
| SEO audit | Basic | Advanced + bulk + scheduled |
| AI models | Standard | Advanced models |
| Local SEO & schema | Basic | Advanced types |
| Reports | Basic + CSV | Advanced + white-label |
| Monitoring & alerts | — | Weekly/monthly + email |
| Agency features | — | Multi-site (roadmap), client reports |

Payments are handled by the chosen payment provider (Stripe integration
planned). The plugin itself never processes card data.

## FAQ (marketing)

**Do I need to know SEO?** No — every issue comes with a plain-language
explanation and a recommended action.

**Which AI does it use?** Whichever provider you connect. Your key, your bill,
your choice — switch any time.

**Is my data safe?** Your API key is encrypted on your server and never shown
again. Page content goes to your AI provider only when you request a
generation. See docs/SECURITY.md.

**Will it guarantee #1 on Google?** No honest tool can. It finds and helps fix
the real issues that hold local rankings back — that's what moves the needle.

**Can agencies use it?** Yes — white-label reports in Pro today, multi-site
management on the roadmap.

## Documentation structure

- `readme.txt` — WordPress.org listing
- `docs/INSTALL.md` — installation & first run
- `docs/CONFIGURATION.md` — every setting explained
- `docs/AI_PROVIDERS.md` — provider setup & adding providers
- `docs/TESTING.md` — QA checklist
- `docs/SECURITY.md` — threat model & measures
- `docs/LIMITATIONS.md` — honest limits
- `docs/ROADMAP.md` — what's next
- `docs/MARKETING.md` — this file
