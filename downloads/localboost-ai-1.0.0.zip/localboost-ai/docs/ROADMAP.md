# Roadmap — LocalBoost AI

## v1.1 — Reporting & polish

- PDF report export (agency-ready, white-labeled).
- Score history chart on the dashboard.
- Gutenberg sidebar: audit the post being edited, one-click AI actions inline.
- More schema subtypes and automatic FAQPage detection from page content.

## v1.2 — Pro monetization

- Stripe integration for Pro checkout (customer portal, webhooks → license provisioning).
- Real license validation against the licensing server (`lbai_license_key`).
- Usage-based billing hooks for agencies.

## v1.3 — Automation

- Background bulk audits (queue-based, chunked, resumable) for large sites.
- AI re-checks inside scheduled audits (Pro, opt-in, counts against quota).
- Slack/email digest of weekly changes.

## v2.0 — Agency platform

- Multi-site management: connect client sites via a secure site-token,
  aggregate scores and issues in one agency dashboard.
- Client seats, per-client quotas, client-facing report links.
- Keyword data provider integration (optional paid add-on) for real
  search-volume figures — only then will volume claims appear in the UI.

## Under consideration

- Rank tracking via Search Console API import.
- Review management (Google Business Profile API).
- Multilingual admin (FR/DE/ES/IT/NL/PT community packs).
- Headless/WooCommerce local-product schema.

## Non-goals

- We will not auto-publish AI content without review.
- We will not claim search-volume data without a real provider.
- We will not process payments inside wp-admin beyond PCI-safe hosted flows.
