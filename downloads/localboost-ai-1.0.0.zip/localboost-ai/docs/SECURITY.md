# Security — LocalBoost AI

## Threat model

The plugin runs in wp-admin for administrators, talks to third-party AI APIs
with a secret key, and writes to posts. Main risks: privilege escalation,
CSRF, XSS via AI output or business fields, key leakage, and SSRF-ish misuse
of the HTTP layer.

## Measures implemented

- **Capability checks**: every admin page and every REST endpoint requires
  `manage_options`. Post-modifying endpoints (`/ai/apply`, `/ai/undo`,
  `/audit`, `/ai/optimize`, `GET /audit/<id>`) additionally require
  `current_user_can('edit_post', $post_id)` on the target post. The central
  `Admin::render()` dies with 403 otherwise.
- **Nonces**: Settings API forms use `settings_fields()`; REST uses the
  `X-WP-Nonce` (`wp_rest`) header; per-post nonces (`lbai_apply_<id>`) guard
  `/ai/apply` and `/ai/undo`; the JS download path sends the nonce too.
- **Input validation**: REST args validated per endpoint (post IDs as absint,
  enums whitelisted, lengths capped); Settings API uses per-option
  `sanitize_callback`s.
- **Output escaping**: `esc_html()`, `esc_attr()`, `esc_url()`, `esc_textarea()`
  on all view output; JS uses a dedicated `esc()` for every `innerHTML` sink
  (audited — all interpolated values escaped) and `textContent` elsewhere.
- **SQL**: all DB access through `$wpdb` with `prepare()`; dynamic ORDER BY
  from strict allow-lists; LIMIT/OFFSET as `%d`; custom tables use indexed
  keys and guarded `dbDelta`/ALTER migrations.
- **API keys**: encrypted at rest via Secure_Store with versioned,
  authenticated payloads — v2 libsodium secretbox preferred, v3 AES-256-GCM
  fallback, legacy v1 (AES-256-CBC) readable and transparently migrated on
  first successful read. Tampered or wrong-key payloads fail closed and are
  treated as missing. Keys are write-only through `POST /settings`, masked
  (`sk-••••ab12`) everywhere else, never rendered raw, never logged, never
  in JS. The password field is always empty on page load.
- **SSRF protection**: AI base URLs are validated by `Url_Validator` both on
  settings save and on every outbound request. Only `http(s)`, no embedded
  credentials, host DNS-resolved and the resolved IP classified — private,
  loopback, link-local, multicast, reserved and cloud metadata addresses are
  blocked for ordinary providers. Remote providers additionally use
  `wp_safe_remote_*()` so WordPress re-validates redirect targets at send
  time. The self-hosted provider intentionally allows loopback (Ollama);
  the admin UI warns when a loopback endpoint is configured. Known
  limitation: DNS is resolved at request time, so hostile DNS rebinding
  between check and request cannot be fully ruled out (documented TOCTOU).
- **Rate limiting**: AI endpoints are throttled per user via an atomic
  `consume()` — N requests per W seconds, sliding window, documented in
  `CONFIGURATION.md`.
- **Connection-test honesty**: `POST /ai/test-connection` returns a proper
  REST error (non-2xx, `success:false`) when the key is missing or rejected,
  and the admin JS treats any non-`valid:true` response as failure.
- **CSV export**: formula-injection neutralized per OWASP (cells starting
  with `= + - @`, tab or CR are single-quote prefixed); exports stream in
  chunks with a hard row cap.
- **Secure HTTP**: provider calls use explicit timeouts over HTTPS; responses
  are validated before use.
- **Error handling**: friendly messages to users; raw errors/exceptions go to
  the debug log only when `WP_DEBUG` is on — never to the screen or API responses.
- **AI output treated as untrusted**: suggestions are shown as text for review
  and sanitized (kses) on apply.
- **Change safety**: optimizer apply creates a WP revision first, records a
  change-history entry (post, user, field, old/new, provider, model, time,
  status) and offers undo; `meta_description` integrates with Yoast/Rank Math
  keys when those plugins are active and is never double-printed.

## Residual risks

- The site admin's key is only as safe as the server: file-system or database
  read access by an attacker still exposes the encrypted blob (standard
  WordPress threat model — keep core, PHP and hosting patched).
- AI providers receive the page content you choose to optimize; review their
  data policies before connecting a key.
- `opensource` provider mode trusts the configured endpoint URL — only point
  it at infrastructure you control; loopback endpoints show an explicit
  admin warning.
- Environments without `openssl` cannot store API keys (key storage returns
  false); without `mbstring` the plugin uses a slower pure-PHP compatibility
  mode with an admin notice.

## Reporting a vulnerability

Email security@localboost.ai with a description and reproduction steps.
We aim to acknowledge within 2 business days. Please do not disclose
publicly before a fix is released.
