# Testing checklist — LocalBoost AI (production-fixed)

## Automated tests (PHP CLI, stub WordPress layer)

Run from the plugin root with any PHP 7.4–8.4 CLI:

```bash
for t in tests/test-*.php; do php "$t" || break; done
node --check assets/js/lbai-admin.js
```

CI (`.github/workflows/ci.yml`) runs the same on PHP 7.4–8.4 plus a PHP 8-only
syntax guard. Current suite (2026-09-24, all executed — see `TEST_REPORT.md`):

| File | Covers | Result |
|---|---|---|
| `tests/test-text-stats.php` | Readability/syllable helpers (pure PHP) | ALL PASSED |
| `tests/test-seo-scorer.php` | SEO scoring math (pure PHP) | All assertions passed |
| `tests/test-integration.php` | Cross-module contracts: options aliases, licensing, secure store, 5 providers incl. keyless `opensource`, schema + `</script>` escaping | 34 passed, 0 failed |
| `tests/test-field-registry.php` | Canonical fields, aliases, deprecated `h2_structure`, `improve`→`readability` | 57 passed, 0 failed |
| `tests/test-audit-fix-flow.php` | Issue contract, `ai_fix` rule, apply/undo, nonces, caps, history | 105 passed, 0 failed |
| `tests/test-monitor.php` | Cron transitions, idempotency, lock, retry, status | 51 passed, 0 failed |
| `tests/test-rate-limiter.php` | Sliding-window semantics, `consume()`, buckets, fail-closed | 28 passed, 0 failed |
| `tests/test-usage-limits.php` | Reserve→finalize/release, quota, reports, v1.1.0 migration | 55 passed, 0 failed |
| `tests/test-reporter.php` | Pagination, date filters, ORDER BY allow-list, CSV chunks + formula-injection | 66 passed, 0 failed |
| `tests/test-secure-store.php` | v1 legacy read+migrate, v2/v3 round-trip, tamper/wrong-key rejection | 24 passed, 0 failed |
| `tests/test-text-utils.php` | mbstring parity + pure-PHP fallback | 34 passed, 0 failed |
| `tests/test-url-validator.php` | SSRF cases incl. obfuscation, multicast, self-hosted exception | 38 passed, 0 failed |
| `tests/test-migrations.php` | v1.1.0→v1.2.0, index additions, idempotent re-run | 7 passed, 0 failed |

**Total: 499 passed, 0 failed** (+ scorer / text-stats suites).

Stub layers: `tests/bootstrap.php` (original WP stubs) and `tests/stub-wp-services.php`
(options, expiry-aware transients, cron recording, SQLite3-backed `$wpdb`).

## Static checks
- [x] `php -l` clean on every PHP file (CI runs it on PHP 7.4–8.4).
- [x] `node --check assets/js/lbai-admin.js` passes.
- [x] No PHP 8-only syntax (CI greps for `match`, `?->`, enums, `readonly`).
- [x] All user-facing strings use `__()`/`esc_html__()` with text domain `localboost-ai`.
- [ ] `bash languages/make-pot.sh` — **blocked**: needs WP-CLI, not installed here.

## What is NOT covered (recorded, never marked PASS)
- Live WordPress/MySQL end-to-end: **no WP install or MySQL in this environment.**
- Activation + `dbDelta` integration, true concurrent quota stress, 1k/10k/100k-row
  reporter load + `EXPLAIN`, DNS-dependent SSRF cases: **blocked — staging required.**
- RTL visual check of wp-admin: needs a live admin.
- Manual test matrix below: needs a staging WordPress.

## Manual test matrix (staging WordPress required)

### Onboarding
- [ ] Fresh activation redirects admin to the wizard exactly once.
- [ ] All 7 steps complete; business info persists; provider + key save; test connection works; first scan runs; recommendations show; finish lands on dashboard.

### Dashboard
- [ ] `GET /lbai/v1/dashboard` returns scores, counts, usage, improvements.
- [ ] Status cards show provider, monitor state, usage vs quota, recent audits — with empty states, no fake numbers.
- [ ] Score rings render; usage bar shows "X of Y"; consistency quick action works.

### SEO Audit
- [ ] Audit runs on a page and a post; progress state shows; results render score + category bars + issues table.
- [ ] Severity filter buttons work; "Fix with AI" appears only on AI-fixable issues and deep-links to the optimizer with post_id + field.

### AI Optimizer
- [ ] Generate shows CURRENT vs AI SUGGESTION modal; Discard changes nothing.
- [ ] Approve & apply writes the change, creates a revision, records change history; Undo restores the previous value.
- [ ] Non-admin (e.g. editor) gets 403 on apply for a post they cannot edit; wrong nonce → 403.
- [ ] Works without a key → friendly error, not a fatal.

### Local SEO & Schema
- [ ] Business profile saves via Settings API; values repopulate.
- [ ] Consistency check flags a deliberately changed phone number with exact correction text.
- [ ] Schema preview shows valid JSON-LD; enable toggle saves; invalid data produces shown errors, not broken markup.

### Content & Keywords
- [ ] Generator produces editable text; Shorten/Expand/Readability/Tone/Translate work; Copy works. `improve` behaves as Readability.
- [ ] Doorway-page warning is visible.
- [ ] Keywords render with the "AI-generated ideas — no search volume" disclaimer.

### Reports
- [ ] Summary loads with pagination and date filters; CSV downloads open correctly in a spreadsheet with formula cells neutralized.
- [ ] Usage report shows requests/successful/failed/tokens per feature.

### AI Settings
- [ ] Switching provider refreshes the model list; saving without a key keeps the old key; key field never shows a value; test connection reports success/failure honestly (failure shows the API message, not a false OK).
- [ ] Loopback base URL on the self-hosted provider shows the explicit warning; remote providers reject private/metadata IPs.

### Settings
- [ ] Monitor frequency + pages save; scheduling is idempotent (no duplicate cron events); notification toggles save; settings export downloads JSON.
- [ ] Monitoring status panel shows last/next run and last error.

### Upgrade
- [ ] Free/Pro table renders; license key saves; honest "no payment processed" note present.

## REST auth tests

- [ ] Logged-out `GET /lbai/v1/dashboard` → 401.
- [ ] Request with wrong nonce → 403.
- [ ] Non-admin (e.g. editor) → 403 on every endpoint.
- [ ] `POST /ai/apply` for a post the user cannot edit → 403 even for admins of other sites (multisite).
- [ ] Invalid `post_id` / unknown field → 400 with `{code, message}`.
- [ ] Invalid API key → friendly error, no stack trace, key not in response.

## Security spot checks

- [ ] View source of every admin page: no API key, no internal prompt text.
- [ ] Submit `<script>` in business name → stored sanitized, rendered escaped.
- [ ] `GET /lbai/v1/schema/preview?type=<script>` → 400, no reflection.

## Uninstall test

1. Create data: run an audit, generate content, save settings + key.
2. Deactivate → data remains.
3. Delete plugin → `lbai_*` options/tables gone; posts and pages untouched.

## Performance

- [ ] `lbai-admin.css`/`lbai-admin.js` load only on LocalBoost screens (check Network tab on Posts list).
- [ ] No audit runs on frontend page views; schema output is one small JSON-LD block.
- [ ] Repeated dashboard loads use cached audit results (no duplicate AI calls).
