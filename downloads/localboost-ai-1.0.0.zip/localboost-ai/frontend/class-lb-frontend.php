<?php
/**
 * Frontend output.
 *
 * Prints the AI-generated meta description and the validated JSON-LD
 * schema in wp_head. Everything is a single non-blocking tag; nothing
 * here enqueues assets or touches page rendering.
 *
 * @package LocalBoostAI\Frontend
 */

namespace LocalBoostAI\Frontend;

use LocalBoostAI\Includes\Options;
use LocalBoostAI\Services\Schema_Generator;

defined( 'ABSPATH' ) || exit;

class Frontend {

	/**
	 * Register frontend hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'wp_head', array( $this, 'output_meta_description' ), 5 );
		add_action( 'wp_head', array( $this, 'output_jsonld' ), 20 );
	}

	/**
	 * Output the AI-generated meta description on singular views.
	 *
	 * Skipped when Yoast SEO or Rank Math is active to avoid duplicate
	 * description tags.
	 *
	 * @return void
	 */
	public function output_meta_description(): void {
		if ( ! is_singular() ) {
			return;
		}

		$description = trim( (string) get_post_meta( get_queried_object_id(), '_lbai_meta_description', true ) );
		if ( '' === $description ) {
			return;
		}

		if ( defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) ) {
			return;
		}

		echo '<meta name="description" content="' . esc_attr( $description ) . '">' . "\n";
	}

	/**
	 * Output validated JSON-LD schema in a single script tag.
	 *
	 * Each configured business type is built and validated; invalid schemas
	 * are skipped so nothing misleading is ever printed.
	 *
	 * @return void
	 */
	public function output_jsonld(): void {
		if ( ! Options::get( 'lbai_schema_enabled' ) ) {
			return;
		}

		$types = Options::get( 'lbai_schema_types' );
		if ( empty( $types ) ) {
			$types = array( 'local_business' );
		}

		$schemas = array();
		foreach ( (array) $types as $type ) {
			$schema = Schema_Generator::build( sanitize_key( (string) $type ) );
			if ( empty( Schema_Generator::validate( $schema ) ) ) {
				$schemas[] = $schema;
			}
		}

		if ( empty( $schemas ) ) {
			return;
		}

		$payload = 1 === count( $schemas )
			? $schemas[0]
			: array(
				'@context' => 'https://schema.org',
				'@graph'   => $schemas,
			);

		echo '<script type="application/ld+json">' . Schema_Generator::to_jsonld( $payload ) . '</script>' . "\n";
	}
}
