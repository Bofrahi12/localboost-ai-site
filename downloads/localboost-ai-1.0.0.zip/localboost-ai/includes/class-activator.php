<?php
/**
 * Runs on plugin activation.
 *
 * @package LocalBoostAI\Includes
 */

namespace LocalBoostAI\Includes;

if (!defined('ABSPATH')) {
    exit;
}

class Activator {

    /**
     * Activate the plugin: environment checks, DB migrations, default
     * options, optional monitoring schedule, onboarding flag.
     */
    public static function activate(): void {
        if (version_compare(PHP_VERSION, '7.4', '<')) {
            wp_die(
                esc_html__('LocalBoost AI requires PHP 7.4 or higher. Please ask your hosting provider to upgrade PHP, then try activating again.', 'localboost-ai'),
                esc_html__('Plugin activation failed', 'localboost-ai'),
                array('back_link' => true)
            );
        }

        global $wp_version;
        if (version_compare($wp_version, '6.0', '<')) {
            wp_die(
                esc_html__('LocalBoost AI requires WordPress 6.0 or higher. Please update WordPress, then try activating again.', 'localboost-ai'),
                esc_html__('Plugin activation failed', 'localboost-ai'),
                array('back_link' => true)
            );
        }

        (new \LocalBoostAI\Database\Migrations())->migrate();

        Options::set_defaults();

        // (Re)apply the monitoring schedule idempotently: 'off' clears any
        // stale event, weekly/monthly (re)create exactly one event.
        if (class_exists(\LocalBoostAI\Services\Monitor::class)) {
            \LocalBoostAI\Services\Monitor::schedule(
                (string) Options::get('lbai_monitor_frequency', 'off')
            );
        }

        set_transient('lbai_onboarding_pending', 1, DAY_IN_SECONDS);
    }
}
