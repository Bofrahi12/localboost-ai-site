<?php
/**
 * Structured exception for AI provider failures.
 *
 * Carries a machine-readable string code (mapped to HTTP status codes by
 * the REST controller), a user-friendly message safe to display, and an
 * optional technical detail for logs. Raw provider internals must never
 * reach the user; raw API keys must never be logged.
 *
 * @package LocalBoostAI\Includes
 */

namespace LocalBoostAI\Includes;

if (!defined('ABSPATH')) {
    exit;
}

class AI_Exception extends \Exception {

    /**
     * @var string Machine-readable error code (e.g. "invalid_key").
     */
    private $error_code;

    /**
     * @var string User-friendly message, safe to display.
     */
    private $user_message;

    /**
     * @param string $code         Machine-readable error code.
     * @param string $user_message User-friendly message (translatable).
     * @param string $technical    Optional technical detail for logs only.
     */
    public function __construct(string $code, string $user_message, string $technical = '') {
        $this->error_code   = $code;
        $this->user_message = $user_message;
        parent::__construct($technical !== '' ? $technical : $user_message, 0);
    }

    /**
     * @return string Machine-readable error code.
     */
    public function get_error_code(): string {
        return $this->error_code;
    }

    /**
     * @return string User-friendly message, safe to display.
     */
    public function get_user_message(): string {
        return $this->user_message;
    }

    public static function invalid_key(): self {
        return new self(
            'invalid_key',
            __('The AI provider rejected the API key. Please check the key in AI Settings.', 'localboost-ai')
        );
    }

    public static function rate_limited(): self {
        return new self(
            'rate_limited',
            __('The AI provider is rate-limiting requests. Please wait a moment and try again.', 'localboost-ai')
        );
    }

    public static function timeout(): self {
        return new self(
            'timeout',
            __('The AI request timed out. Please try again.', 'localboost-ai')
        );
    }

    public static function provider_unavailable(): self {
        return new self(
            'provider_unavailable',
            __('The AI provider is currently unavailable. Please try again later.', 'localboost-ai')
        );
    }

    public static function empty_response(): self {
        return new self(
            'empty_response',
            __('The AI provider returned an empty response. Please try again.', 'localboost-ai')
        );
    }

    public static function not_configured(): self {
        return new self(
            'not_configured',
            __('No AI provider is configured. Add an API key in AI Settings first.', 'localboost-ai')
        );
    }

    /**
     * @param string $detail Optional safe detail about the invalid output.
     */
    public static function invalid_output(string $detail = ''): self {
        $message = __('The AI provider returned an invalid response. Please try again.', 'localboost-ai');
        return new self('invalid_output', $message, $detail);
    }
}
