<?php
/**
 * Runs on plugin deactivation.
 *
 * @package LocalBoostAI\Includes
 */

namespace LocalBoostAI\Includes;

if (!defined('ABSPATH')) {
    exit;
}

class Deactivator {

    /**
     * Deactivate the plugin. Clears the scheduled monitoring hook and any
     * stale run lock, so cron can never run while the plugin is disabled.
     * User data (options, tables) is intentionally kept; uninstall.php
     * handles full removal.
     */
    public static function deactivate(): void {
        wp_clear_scheduled_hook('lbai_scheduled_audit');
        if (class_exists(\LocalBoostAI\Services\Monitor::class)) {
            delete_transient(\LocalBoostAI\Services\Monitor::LOCK_TRANSIENT);
        }
    }
}
