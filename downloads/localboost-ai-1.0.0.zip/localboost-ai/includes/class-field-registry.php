<?php
/**
 * Canonical field registry for LocalBoost AI.
 *
 * Single source of truth for the optimizer field names used by the REST API,
 * the AI_Optimizer and Content_Generator services, the SEO auditor, the
 * admin UI, the admin JavaScript and the tests. Every layer must use the
 * canonical names below; legacy names are accepted only as aliases and are
 * normalized to their canonical form before any service is called.
 *
 * Canonical fields:
 *   title, meta_description, h1, introduction, faq, cta, alt_texts,
 *   internal_links
 *
 * Legacy aliases (accepted, normalized, never stored):
 *   seo_title        -> title
 *   image_alt        -> alt_texts
 *   service_description -> introduction
 *   h2_structure     -> h2_structure (DEPRECATED: no canonical target exists;
 *                       still accepted so old API clients keep working, but it
 *                       is hidden from the UI and must not be used in new code)
 *
 * Transform actions:
 *   shorten, expand, readability, tone, translate
 *   (improve is accepted as an alias of readability)
 *
 * @package LocalBoostAI\Includes
 * @since   1.0.0
 */

namespace LocalBoostAI\Includes;

defined( 'ABSPATH' ) || exit;

/**
 * Class Field_Registry
 */
final class Field_Registry {

	/**
	 * Canonical optimizer field names. Every layer uses these.
	 *
	 * @var string[]
	 */
	const CANONICAL_FIELDS = array(
		'title',
		'meta_description',
		'h1',
		'introduction',
		'faq',
		'cta',
		'alt_texts',
		'internal_links',
	);

	/**
	 * Legacy field names mapped to their canonical form.
	 *
	 * h2_structure maps to itself: it is a deprecated legacy field with no
	 * canonical target. It stays functional (accepted by the API and the
	 * optimizer) for backward compatibility, is reported by is_deprecated(),
	 * and is hidden from the admin UI.
	 *
	 * @var array<string,string>
	 */
	const ALIASES = array(
		'seo_title'           => 'title',
		'image_alt'           => 'alt_texts',
		'service_description' => 'introduction',
		'h2_structure'        => 'h2_structure',
	);

	/**
	 * Fields that are deprecated but still functional.
	 *
	 * @var string[]
	 */
	const DEPRECATED_FIELDS = array(
		'h2_structure',
	);

	/**
	 * Canonical text transform actions.
	 *
	 * @var string[]
	 */
	const TRANSFORM_ACTIONS = array(
		'shorten',
		'expand',
		'readability',
		'tone',
		'translate',
	);

	/**
	 * Legacy transform action aliases mapped to their canonical form.
	 *
	 * @var array<string,string>
	 */
	const TRANSFORM_ACTION_ALIASES = array(
		'improve' => 'readability',
	);

	/**
	 * Normalize a field name to its canonical form.
	 *
	 * Accepts canonical names and legacy aliases; returns null for unknown
	 * names so callers can reject them with a validation error.
	 *
	 * @param string $field Raw field name.
	 * @return string|null Canonical field name, or null when unknown.
	 */
	public static function canonicalize( string $field ): ?string {
		$field = strtolower( trim( $field ) );
		if ( in_array( $field, self::CANONICAL_FIELDS, true ) ) {
			return $field;
		}
		if ( isset( self::ALIASES[ $field ] ) ) {
			return self::ALIASES[ $field ];
		}
		return null;
	}

	/**
	 * Whether a field name is accepted (canonical or legacy alias).
	 *
	 * @param string $field Raw field name.
	 * @return bool
	 */
	public static function is_valid( string $field ): bool {
		return null !== self::canonicalize( $field );
	}

	/**
	 * Whether a field name is a deprecated legacy field.
	 *
	 * Deprecated fields stay functional but are hidden from the UI.
	 *
	 * @param string $field Raw field name.
	 * @return bool
	 */
	public static function is_deprecated( string $field ): bool {
		return in_array( strtolower( trim( $field ) ), self::DEPRECATED_FIELDS, true );
	}

	/**
	 * All canonical field names.
	 *
	 * @return string[]
	 */
	public static function all(): array {
		return self::CANONICAL_FIELDS;
	}

	/**
	 * Normalize a transform action to its canonical form.
	 *
	 * Accepts canonical actions and the legacy 'improve' alias (mapped to
	 * 'readability'); returns null for unknown actions.
	 *
	 * @param string $action Raw action name.
	 * @return string|null Canonical action name, or null when unknown.
	 */
	public static function canonicalize_action( string $action ): ?string {
		$action = strtolower( trim( $action ) );
		if ( in_array( $action, self::TRANSFORM_ACTIONS, true ) ) {
			return $action;
		}
		if ( isset( self::TRANSFORM_ACTION_ALIASES[ $action ] ) ) {
			return self::TRANSFORM_ACTION_ALIASES[ $action ];
		}
		return null;
	}

	/**
	 * Whether a transform action is accepted (canonical or alias).
	 *
	 * @param string $action Raw action name.
	 * @return bool
	 */
	public static function is_valid_action( string $action ): bool {
		return null !== self::canonicalize_action( $action );
	}
}
