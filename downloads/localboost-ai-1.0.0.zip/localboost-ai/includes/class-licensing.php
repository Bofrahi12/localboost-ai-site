<?php
/**
 * Freemium plan / licensing abstraction.
 *
 * The plugin itself never processes payments. Plan state is exposed through
 * the `lbai_is_pro` filter so a future licensing add-on (Stripe, etc.) can
 * plug in without touching this file.
 *
 * @package LocalBoostAI\Includes
 */

namespace LocalBoostAI\Includes;

if (!defined('ABSPATH')) {
    exit;
}

class Licensing {

    const PLAN_FREE = 'free';
    const PLAN_PRO  = 'pro';

    /**
     * Whether the Pro plan is active.
     *
     * @return bool
     */
    public static function is_pro(): bool {
        /**
         * Filters whether the Pro plan is active.
         *
         * @param bool $is_pro Default false.
         */
        return (bool) apply_filters('lbai_is_pro', false);
    }

    /**
     * Current plan slug ("free" or "pro").
     *
     * @return string
     */
    public static function get_plan(): string {
        return self::is_pro() ? self::PLAN_PRO : self::PLAN_FREE;
    }

    /**
     * Monthly usage limits per feature for the current plan.
     * A limit of -1 means unlimited.
     *
     * @return array Feature slug => int limit.
     */
    public static function get_limits(): array {
        $plan = self::get_plan();

        if ($plan === self::PLAN_PRO) {
            $defaults = array(
                'ai_generation' => -1,
                'audit'         => -1,
                'report'        => -1,
                'content'       => -1,
            );
        } else {
            $defaults = array(
                'ai_generation' => 10,
                'audit'         => 25,
                'report'        => 5,
                'content'       => 10,
            );
        }

        /**
         * Filters the usage limits for a plan.
         *
         * @param array  $defaults Feature slug => int limit (-1 = unlimited).
         * @param string $plan     Plan slug.
         */
        return apply_filters('lbai_plan_limits', $defaults, $plan);
    }

    /**
     * URL of the upgrade page.
     *
     * @return string
     */
    public static function upgrade_url(): string {
        /**
         * Filters the upgrade URL.
         *
         * @param string $url Default admin upgrade page.
         */
        return apply_filters('lbai_upgrade_url', admin_url('admin.php?page=lbai-upgrade'));
    }
}
