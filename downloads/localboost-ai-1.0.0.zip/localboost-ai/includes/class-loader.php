<?php
/**
 * Wires the plugin's modules into WordPress hooks.
 *
 * Every module is guarded with class_exists() so a missing or broken
 * module can never fatal the site.
 *
 * @package LocalBoostAI\Includes
 */

namespace LocalBoostAI\Includes;

if (!defined('ABSPATH')) {
    exit;
}

class Loader {

    /**
     * Register all plugin hooks.
     *
     * The Admin and Onboarding modules expose static register() methods
     * that hook themselves; the Settings action link is added by the
     * Admin module itself, so this loader does not duplicate it.
     */
    public function register(): void {
        if (class_exists('LocalBoostAI\Admin\Admin')) {
            \LocalBoostAI\Admin\Admin::register();
        }

        if (class_exists('LocalBoostAI\Api\Rest_Controller')) {
            (new \LocalBoostAI\Api\Rest_Controller())->register();
        }

        if (class_exists('LocalBoostAI\Frontend\Frontend')) {
            add_action('init', array(new \LocalBoostAI\Frontend\Frontend(), 'register'));
        }

        if (class_exists('LocalBoostAI\Admin\Onboarding')) {
            \LocalBoostAI\Admin\Onboarding::register();
        }

        if (class_exists('LocalBoostAI\Services\Monitor')) {
            add_action('lbai_scheduled_audit', array('LocalBoostAI\Services\Monitor', 'run'));
        }
    }
}
