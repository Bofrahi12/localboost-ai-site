<?php
/**
 * Branded HTML notification emails.
 *
 * All template data is escaped before output. These flows never handle
 * API keys, so none can leak here.
 *
 * @package LocalBoostAI\Includes
 */

namespace LocalBoostAI\Includes;

if (!defined('ABSPATH')) {
    exit;
}

class Mailer {

    /**
     * Send a templated notification email.
     *
     * @param string $to       Recipient email address.
     * @param string $subject  Email subject (already translated by caller).
     * @param string $template Template slug: audit_completed, critical_issue,
     *                         report_ready, usage_limit.
     * @param array  $data     Template data (all values escaped on render).
     * @return bool
     */
    public static function send(string $to, string $subject, string $template, array $data = array()): bool {
        $to = sanitize_email($to);
        if (!is_email($to)) {
            return false;
        }

        $body    = self::render($template, $data);
        $headers = array('Content-Type: text/html; charset=UTF-8');

        return wp_mail($to, $subject, $body, $headers);
    }

    /**
     * Render the full HTML email for a template.
     *
     * @param string $template Template slug.
     * @param array  $data     Raw template data.
     * @return string
     */
    private static function render(string $template, array $data): string {
        $text = function ($key) use ($data) {
            return isset($data[$key]) && is_scalar($data[$key])
                ? esc_html((string) $data[$key])
                : '';
        };
        $url = function ($key) use ($data) {
            return isset($data[$key]) && is_scalar($data[$key])
                ? esc_url((string) $data[$key])
                : '';
        };

        switch ($template) {
            case 'audit_completed':
                $heading = esc_html__('Your SEO audit is complete', 'localboost-ai');
                $inner   = '<p>' . sprintf(
                    /* translators: %s: SEO score wrapped in <strong>. */
                    esc_html__('Your LocalBoost SEO Score is %s.', 'localboost-ai'),
                    '<strong>' . $text('score') . '</strong>'
                ) . '</p>';
                if ($text('url') !== '') {
                    $inner .= '<p>' . esc_html__('Audited page:', 'localboost-ai') . ' ' . $text('url') . '</p>';
                }
                $inner .= self::button($url('dashboard_url'), esc_html__('View dashboard', 'localboost-ai'));
                break;

            case 'critical_issue':
                $heading = esc_html__('Critical SEO issue detected', 'localboost-ai');
                $inner   = '<p>' . $text('issue') . '</p>';
                if ($text('page_url') !== '') {
                    $inner .= '<p>' . esc_html__('Page:', 'localboost-ai') . ' ' . $text('page_url') . '</p>';
                }
                $inner .= self::button($url('dashboard_url'), esc_html__('Review issue', 'localboost-ai'));
                break;

            case 'report_ready':
                $heading = esc_html__('Your SEO report is ready', 'localboost-ai');
                $inner   = '<p>' . $text('title') . '</p>';
                $inner  .= self::button($url('download_url'), esc_html__('Download report', 'localboost-ai'));
                break;

            case 'usage_limit':
            default:
                $heading = esc_html__('You reached a usage limit', 'localboost-ai');
                $inner   = '<p>' . sprintf(
                    /* translators: 1: used count, 2: limit, 3: feature label. */
                    esc_html__('You have used %1$s of %2$s %3$s this month.', 'localboost-ai'),
                    '<strong>' . $text('used') . '</strong>',
                    '<strong>' . $text('limit') . '</strong>',
                    $text('feature')
                ) . '</p>';
                $inner .= self::button($url('upgrade_url'), esc_html__('Upgrade plan', 'localboost-ai'));
                break;
        }

        return self::wrap($heading, $inner);
    }

    /**
     * Wrap content in the branded email shell.
     *
     * @param string $heading Already-escaped heading.
     * @param string $inner   Already-escaped HTML content.
     * @return string
     */
    private static function wrap(string $heading, string $inner): string {
        $site_name = esc_html(get_bloginfo('name'));
        $footer    = esc_html__('Sent by LocalBoost AI.', 'localboost-ai');

        return '<!DOCTYPE html><html><body style="margin:0;padding:0;background:#f5f7fa;">'
            . '<div style="max-width:600px;margin:0 auto;padding:32px 16px;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;">'
            . '<div style="background:#ffffff;border-radius:8px;padding:32px;border:1px solid #e5e9f0;">'
            . '<div style="font-size:20px;font-weight:700;color:#1a1f36;margin-bottom:4px;">LocalBoost AI</div>'
            . '<div style="font-size:13px;color:#6b7280;margin-bottom:24px;">' . $site_name . '</div>'
            . '<h1 style="font-size:20px;color:#1a1f36;margin:0 0 16px;">' . $heading . '</h1>'
            . '<div style="font-size:15px;line-height:1.6;color:#374151;">' . $inner . '</div>'
            . '</div>'
            . '<div style="text-align:center;font-size:12px;color:#9ca3af;margin-top:16px;">' . $footer . '</div>'
            . '</div></body></html>';
    }

    /**
     * Render a call-to-action button. Empty href renders nothing.
     *
     * @param string $href  Already-escaped URL.
     * @param string $label Already-escaped label.
     * @return string
     */
    private static function button(string $href, string $label): string {
        if ($href === '') {
            return '';
        }
        return '<p style="margin:24px 0 8px;">'
            . '<a href="' . $href . '" style="display:inline-block;background:#2563eb;color:#ffffff;'
            . 'text-decoration:none;padding:12px 24px;border-radius:6px;font-weight:600;font-size:15px;">'
            . $label . '</a></p>';
    }
}
