<?php
/**
 * Central registry for all plugin options.
 *
 * @package LocalBoostAI\Includes
 */

namespace LocalBoostAI\Includes;

if (!defined('ABSPATH')) {
    exit;
}

class Options {

    /**
     * Default values for every lbai_* option.
     */
    const DEFAULTS = array(
        // Business information.
        'lbai_business_name'   => '',
        'lbai_business_type'   => 'local_shop',
        'lbai_address_street'  => '',
        'lbai_address_city'    => '',
        'lbai_address_region'  => '',
        'lbai_address_postal'  => '',
        'lbai_address_country' => '',
        'lbai_phone'           => '',
        'lbai_email'           => '',
        'lbai_website'         => '',
        'lbai_hours'           => array(),
        'lbai_services'        => array(),
        'lbai_price_range'     => '',
        'lbai_social'          => array(),
        'lbai_lat'             => '',
        'lbai_lng'             => '',
        // AI configuration.
        'lbai_ai_provider'    => 'openai',
        'lbai_ai_model'       => '',
        'lbai_ai_temperature' => 0.7,
        'lbai_ai_max_tokens'  => 500,
        'lbai_meta_base_url'  => 'https://api.meta.ai/v1',
        'lbai_opensource_base_url' => 'http://localhost:11434/v1',
        // Schema output.
        'lbai_schema_enabled' => 0,
        'lbai_schema_types'   => array('local_business'),
        // Automated monitoring.
        'lbai_monitor_frequency' => 'off',
        'lbai_monitor_pages'     => array(),
        // Email notifications.
        'lbai_notify_audit_completed' => 1,
        'lbai_notify_critical'        => 1,
        'lbai_notify_report'          => 1,
        'lbai_notify_usage'           => 1,
        // Plan / licensing.
        'lbai_plan'        => 'free',
        'lbai_license_key' => '',
        // White label (agency reports).
        'lbai_white_label_name' => '',
        'lbai_white_label_logo' => '',
        // Internal.
        'lbai_db_version'      => '1.0.0',
        'lbai_onboarding_done' => 0,
        // Misc.
        'lbai_content_language' => 'en',
        'lbai_hours_summary'    => '',
    );

    /**
     * Legacy/alternate key names mapped to their canonical key.
     *
     * Different modules historically used slightly different option names
     * (e.g. the Settings API form writes `lbai_city` while services read
     * `lbai_address_city`). The map below keeps every reader and writer in
     * sync: get() resolves any known name, set() always stores canonical.
     */
    const ALIASES = array(
        'lbai_address'            => 'lbai_address_street',
        'lbai_city'               => 'lbai_address_city',
        'lbai_region'             => 'lbai_address_region',
        'lbai_postal'             => 'lbai_address_postal',
        'lbai_postal_code'        => 'lbai_address_postal',
        'lbai_country'            => 'lbai_address_country',
        'lbai_social_profiles'    => 'lbai_social',
        'lbai_latitude'           => 'lbai_lat',
        'lbai_longitude'          => 'lbai_lng',
        'lbai_monitored_pages'    => 'lbai_monitor_pages',
        'lbai_notify_critical_issue' => 'lbai_notify_critical',
        'lbai_notify_report_ready'   => 'lbai_notify_report',
        'lbai_notify_usage_limit'    => 'lbai_notify_usage',
    );

    /**
     * Resolve any known option name to its canonical key.
     *
     * @param string $key Option name or alias.
     * @return string Canonical option name.
     */
    public static function canonical_key(string $key): string {
        return self::ALIASES[$key] ?? $key;
    }

    /**
     * Every option name the plugin may own (canonical + aliases).
     * Used by uninstall to leave no stale keys behind.
     *
     * @return string[]
     */
    public static function all_known_keys(): array {
        return array_unique(array_merge(array_keys(self::DEFAULTS), array_keys(self::ALIASES)));
    }

    /**
     * Get an option value.
     *
     * @param string $key     Option name.
     * @param mixed  $default Fallback when no default is registered.
     * @return mixed
     */
    public static function get(string $key, $default = null) {
        $canonical = self::canonical_key($key);

        // Check the canonical key first, then every alias that maps to it
        // (values may have been written directly, e.g. via the Settings API).
        $candidates = array($canonical);
        foreach (self::ALIASES as $alias => $target) {
            if ($target === $canonical && $alias !== $canonical) {
                $candidates[] = $alias;
            }
        }
        foreach ($candidates as $candidate) {
            $value = get_option($candidate, null);
            if ($value !== null) {
                return $value;
            }
        }

        if ($default !== null) {
            return $default;
        }
        return array_key_exists($canonical, self::DEFAULTS) ? self::DEFAULTS[$canonical] : null;
    }

    /**
     * Set an option value.
     *
     * Aliases are normalized to the canonical key; a stale copy under the
     * alias name is removed so reads stay unambiguous.
     *
     * @param string $key   Option name or alias.
     * @param mixed  $value Value (will be serialized by WordPress if needed).
     * @return bool
     */
    public static function set(string $key, $value): bool {
        $canonical = self::canonical_key($key);
        $result    = update_option($canonical, $value);
        if ($canonical !== $key) {
            delete_option($key);
        }
        return $result;
    }

    /**
     * Delete an option.
     *
     * @param string $key Option name.
     * @return bool
     */
    public static function delete(string $key): bool {
        return delete_option($key);
    }

    /**
     * Register default values for any option not already set.
     * Never overwrites existing values.
     */
    public static function set_defaults(): void {
        foreach (self::DEFAULTS as $key => $value) {
            if (get_option($key, null) === null) {
                add_option($key, $value);
            }
        }
    }

    /**
     * Get all registered options with their current values.
     *
     * @return array
     */
    public static function get_all(): array {
        $all = array();
        foreach (self::DEFAULTS as $key => $value) {
            $all[$key] = get_option($key, $value);
        }
        return $all;
    }
}
