<?php
/**
 * Sliding-window rate limiter.
 *
 * Canonical semantics (also documented in docs/CONFIGURATION.md):
 *
 *   consume( $key, $limit, $window ) allows at most $limit requests per
 *   $window seconds, measured on a SLIDING window and tracked independently
 *   per bucket key. A request at time T counts against the limit while
 *   (now - T) < $window; there are no fixed window boundaries.
 *
 * Bucket key convention:
 *   'ai:<user_id>:<provider>'  per-user AI calls, e.g. 'ai:7:openai'
 *   'audit:<user_id>'          per-user audit calls
 *   'monitor'                  the scheduled monitoring job
 *
 * Storage: one WP transient per bucket holding an array of hit timestamps
 * (microtime floats). Entries older than the window are pruned on every
 * read, which is what makes the window slide.
 *
 * Recommended call pattern (single call — no check/hit split):
 *
 *   if ( ! Rate_Limiter::consume( $bucket, 20, 60 ) ) {
 *       // deny: more than 20 requests in the last 60 seconds
 *   }
 *
 * The legacy check() + hit() pair is kept for backward compatibility, but
 * splitting the check from the increment widens the race window; new code
 * should prefer consume().
 *
 * Concurrency note: transient get-then-set is NOT atomic. Two requests
 * arriving at the same instant can both read the same hit list and both be
 * allowed, overshooting the limit by a tiny amount. The consequence is a
 * slightly generous limit under extreme concurrency — never a security
 * bypass. For hard, billing-relevant quota guarantees use the Usage_Tracker
 * reservation flow (reserve/finalize/release) instead.
 *
 * @package LocalBoostAI\Includes
 */

namespace LocalBoostAI\Includes;

if (!defined('ABSPATH')) {
    exit;
}

class Rate_Limiter {

    /**
     * Build the transient key for a bucket.
     *
     * @param string $key Bucket identifier.
     * @return string
     */
    private static function transient_key(string $key): string {
        return 'lbai_rl_' . md5($key);
    }

    /**
     * Read the hit timestamps for a bucket, pruning entries that fell out
     * of the sliding window.
     *
     * @param string $tkey   Transient key.
     * @param int    $window Window length in seconds.
     * @return float[] Hit timestamps (microtime), oldest first.
     */
    private static function read_hits(string $tkey, int $window): array {
        $hits = get_transient($tkey);
        if (!is_array($hits)) {
            return array();
        }
        $cutoff = microtime(true) - (float) $window;
        $fresh  = array();
        foreach ($hits as $t) {
            $t = (float) $t;
            if ($t > $cutoff) {
                $fresh[] = $t;
            }
        }
        return $fresh;
    }

    /**
     * Persist the hit list, keeping the transient TTL at the window length
     * so stale buckets disappear on their own.
     *
     * @param string $tkey   Transient key.
     * @param array  $hits   Hit timestamps.
     * @param int    $window Window length in seconds.
     * @return void
     */
    private static function store_hits(string $tkey, array $hits, int $window): void {
        set_transient($tkey, array_values($hits), max(1, $window));
    }

    /**
     * Consume one unit from a bucket.
     *
     * Increments the hit count and reports whether the request is within the
     * limit — a single read-modify-write so callers cannot forget the
     * increment (the old check()/hit() split had that bug in the AI service
     * layer). See the class docblock for the residual transient race.
     *
     * @param string $key    Bucket identifier, e.g. 'ai:7:openai'.
     * @param int    $limit  Max requests per window. <= 0 denies everything.
     * @param int    $window Window length in seconds. <= 0 denies everything.
     * @return bool True when the request is allowed (and was counted).
     */
    public static function consume(string $key, int $limit = 20, int $window = 60): bool {
        if ($limit <= 0 || $window <= 0) {
            return false;
        }
        $tkey = self::transient_key($key);
        $hits = self::read_hits($tkey, $window);
        if (count($hits) >= $limit) {
            self::store_hits($tkey, $hits, $window);
            return false;
        }
        $hits[] = microtime(true);
        self::store_hits($tkey, $hits, $window);
        return true;
    }

    /**
     * Check whether a bucket still has capacity, WITHOUT consuming.
     *
     * Backward-compatible with the original API. Prefer consume() for new
     * code: check() followed by a separate hit() is racy and easy to misuse
     * (a forgotten hit() disables limiting entirely).
     *
     * @param string $key    Bucket identifier.
     * @param int    $limit  Max requests per window.
     * @param int    $window Window length in seconds.
     * @return bool True when another request would be allowed.
     */
    public static function check(string $key, int $limit = 20, int $window = 60): bool {
        if ($limit <= 0 || $window <= 0) {
            return false;
        }
        return count(self::read_hits(self::transient_key($key), $window)) < $limit;
    }

    /**
     * Record a hit against a bucket.
     *
     * Backward-compatible with the original API. Prefer consume().
     *
     * @param string $key    Bucket identifier.
     * @param int    $window Window length in seconds.
     * @return int Hit count inside the current window after recording.
     */
    public static function hit(string $key, int $window = 60): int {
        if ($window <= 0) {
            return 0;
        }
        $tkey = self::transient_key($key);
        $hits = self::read_hits($tkey, $window);
        $hits[] = microtime(true);
        self::store_hits($tkey, $hits, $window);
        return count($hits);
    }

    /**
     * Clear a bucket (admin tooling / tests).
     *
     * @param string $key Bucket identifier.
     * @return void
     */
    public static function reset(string $key): void {
        delete_transient(self::transient_key($key));
    }
}
