<?php
/**
 * Encrypted storage for secrets (API keys).
 *
 * Payload versions:
 *   v1 — legacy AES-256-CBC, format base64(iv):base64(ciphertext). Read-only:
 *          no authentication tag, so it cannot detect tampering. On a
 *          successful read the value is transparently re-encrypted to the
 *          newest available format.
 *   v2 — libsodium secretbox (preferred when the sodium extension is
 *          available): "v2:" . base64(nonce || ciphertext). Authenticated.
 *   v3 — AES-256-GCM fallback: "v3:" . base64(iv || tag || ciphertext).
 *          Authenticated.
 *
 * The encryption key is derived from the site's AUTH_KEY / SECURE_AUTH_KEY
 * salts. Tampered or wrong-key payloads fail decryption and are treated as
 * missing (get() returns ''), so a modified ciphertext can never silently
 * decrypt to garbage — v2/v3 additionally refuse to authenticate.
 *
 * API keys are never exposed to frontend JavaScript and never logged.
 *
 * @package LocalBoostAI\Includes
 */

namespace LocalBoostAI\Includes;

if (!defined('ABSPATH')) {
    exit;
}

class Secure_Store {

    const OPTION_PREFIX = 'lbai_secure_';
    const CIPHER        = 'aes-256-cbc';

    const VERSION_LEGACY = 'v1';
    const VERSION_SODIUM = 'v2';
    const VERSION_GCM    = 'v3';

    /**
     * Derive the encryption key from the site salts.
     *
     * Two derivations exist on purpose:
     *  - legacy (hex string): byte-for-byte identical to the pre-1.0 key, so
     *    existing v1 payloads keep decrypting. OpenSSL truncates it to the
     *    first 32 bytes, exactly as before.
     *  - raw (32 bytes): full-strength key used for the new authenticated
     *    v2/v3 payloads.
     *
     * @param bool $raw True for the raw 32-byte key, false for the legacy hex key.
     * @return string
     * @throws \RuntimeException When the salts are not defined.
     */
    private static function encryption_key(bool $raw = false): string {
        if (!defined('AUTH_KEY') || !defined('SECURE_AUTH_KEY')) {
            throw new \RuntimeException('LocalBoost AI: AUTH_KEY / SECURE_AUTH_KEY salts are not defined.');
        }
        return hash('sha256', AUTH_KEY . '|' . SECURE_AUTH_KEY, $raw);
    }

    /**
     * Best payload version this environment can write.
     *
     * @return string One of the VERSION_* constants.
     */
    public static function best_version(): string {
        if (function_exists('sodium_crypto_secretbox')) {
            return self::VERSION_SODIUM;
        }
        if (function_exists('openssl_encrypt') && in_array('aes-256-gcm', openssl_get_cipher_methods(), true)) {
            return self::VERSION_GCM;
        }
        return self::VERSION_LEGACY;
    }

    /**
     * Store an encrypted value.
     *
     * @param string $key   Storage key (sanitized).
     * @param string $value Plain-text value.
     * @return bool
     */
    public static function set(string $key, string $value): bool {
        $stored = self::encrypt($value);
        if ($stored === null) {
            return false;
        }
        return update_option(self::OPTION_PREFIX . sanitize_key($key), $stored, false);
    }

    /**
     * Retrieve and decrypt a value.
     *
     * Returns '' when the value is missing, undecryptable, tampered with, or
     * encrypted under different salts. A successful legacy (v1) read is
     * transparently migrated to the newest available format.
     *
     * @param string $key Storage key.
     * @return string Decrypted value, or ''.
     */
    public static function get(string $key): string {
        $option = self::OPTION_PREFIX . sanitize_key($key);
        $stored = get_option($option, '');
        if (!is_string($stored) || $stored === '') {
            return '';
        }

        try {
            $plain = self::decrypt($stored);
        } catch (\RuntimeException $e) {
            return '';
        }
        if ($plain === null) {
            return '';
        }

        // Transparent migration: legacy reads are re-stored authenticated.
        if (self::payload_version($stored) === self::VERSION_LEGACY
            && self::best_version() !== self::VERSION_LEGACY
        ) {
            $migrated = self::encrypt($plain);
            if ($migrated !== null) {
                update_option($option, $migrated, false);
            }
        }

        return $plain;
    }

    /**
     * Delete a stored value.
     *
     * @param string $key Storage key.
     * @return bool
     */
    public static function delete(string $key): bool {
        return delete_option(self::OPTION_PREFIX . sanitize_key($key));
    }

    /**
     * Store an AI provider API key.
     *
     * @param string $provider Provider slug (e.g. "openai").
     * @param string $key      Raw API key.
     * @return bool
     */
    public static function set_api_key(string $provider, string $key): bool {
        return self::set('api_key_' . sanitize_key($provider), $key);
    }

    /**
     * Get an AI provider API key.
     *
     * @param string $provider Provider slug.
     * @return string Decrypted key, or '' when none is stored.
     */
    public static function get_api_key(string $provider): string {
        return self::get('api_key_' . sanitize_key($provider));
    }

    /**
     * Delete an AI provider API key.
     *
     * @param string $provider Provider slug.
     * @return bool
     */
    public static function delete_api_key(string $provider): bool {
        return self::delete('api_key_' . sanitize_key($provider));
    }

    /**
     * Whether an API key is stored for the provider.
     *
     * @param string $provider Provider slug.
     * @return bool
     */
    public static function has_api_key(string $provider): bool {
        return self::get_api_key($provider) !== '';
    }

    /**
     * Get a masked representation of the stored key, safe for display.
     * Example: "sk-••••ab12". Never returns the raw key.
     *
     * @param string $provider Provider slug.
     * @return string
     */
    public static function get_masked_key(string $provider): string {
        $key = self::get_api_key($provider);
        if ($key === '') {
            return __('Not set', 'localboost-ai');
        }
        $prefix = substr($key, 0, 3);
        $suffix = substr($key, -4);
        return $prefix . '••••' . $suffix;
    }

    /**
     * Which payload version a stored string uses.
     *
     * @param string $stored Stored payload.
     * @return string VERSION_* constant.
     */
    public static function payload_version(string $stored): string {
        if (strpos($stored, 'v2:') === 0) {
            return self::VERSION_SODIUM;
        }
        if (strpos($stored, 'v3:') === 0) {
            return self::VERSION_GCM;
        }
        return self::VERSION_LEGACY;
    }

    /**
     * Encrypt with the best available format.
     *
     * @param string $value Plain text.
     * @return string|null Stored payload, or null on failure.
     */
    private static function encrypt(string $value): ?string {
        $version = self::best_version();

        if ($version === self::VERSION_SODIUM) {
            $nonce  = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
            $cipher = sodium_crypto_secretbox($value, $nonce, self::encryption_key(true));
            return 'v2:' . base64_encode($nonce . $cipher);
        }

        if ($version === self::VERSION_GCM) {
            $iv    = random_bytes(12);
            $tag   = '';
            $cipher = openssl_encrypt($value, 'aes-256-gcm', self::encryption_key(true), OPENSSL_RAW_DATA, $iv, $tag);
            if ($cipher === false || $tag === '') {
                return null;
            }
            return 'v3:' . base64_encode($iv . $tag . $cipher);
        }

        // Legacy fallback (unauthenticated) — only when neither sodium nor
        // GCM is available.
        $iv_length = openssl_cipher_iv_length(self::CIPHER);
        if ($iv_length === false) {
            return null;
        }
        $iv     = random_bytes($iv_length);
        $cipher = openssl_encrypt($value, self::CIPHER, self::encryption_key(), OPENSSL_RAW_DATA, $iv);
        if ($cipher === false) {
            return null;
        }
        return base64_encode($iv) . ':' . base64_encode($cipher);
    }

    /**
     * Decrypt a stored payload of any supported version.
     *
     * @param string $stored Stored payload.
     * @return string|null Plain text, or null when undecryptable/tampered.
     * @throws \RuntimeException When the salts are not defined.
     */
    private static function decrypt(string $stored): ?string {
        if (strpos($stored, 'v2:') === 0) {
            if (!function_exists('sodium_crypto_secretbox_open')) {
                return null;
            }
            $raw = base64_decode(substr($stored, 3), true);
            if ($raw === false || strlen($raw) < SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) {
                return null;
            }
            $nonce  = substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
            $cipher = substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
            $plain  = sodium_crypto_secretbox_open($cipher, $nonce, self::encryption_key(true));
            return $plain === false ? null : $plain;
        }

        if (strpos($stored, 'v3:') === 0) {
            if (!function_exists('openssl_decrypt') || !in_array('aes-256-gcm', openssl_get_cipher_methods(), true)) {
                return null;
            }
            $raw = base64_decode(substr($stored, 3), true);
            if ($raw === false || strlen($raw) < 28) {
                return null;
            }
            $iv     = substr($raw, 0, 12);
            $tag    = substr($raw, 12, 16);
            $cipher = substr($raw, 28);
            $plain  = openssl_decrypt($cipher, 'aes-256-gcm', self::encryption_key(true), OPENSSL_RAW_DATA, $iv, $tag);
            return $plain === false ? null : $plain;
        }

        // Legacy v1: base64(iv):base64(ciphertext), AES-256-CBC, no auth tag.
        $parts = explode(':', $stored, 2);
        if (count($parts) !== 2) {
            return null;
        }
        $iv     = base64_decode($parts[0], true);
        $cipher = base64_decode($parts[1], true);
        if ($iv === false || $cipher === false) {
            return null;
        }
        $plain = openssl_decrypt($cipher, self::CIPHER, self::encryption_key(), OPENSSL_RAW_DATA, $iv);
        return $plain === false ? null : $plain;
    }
}
