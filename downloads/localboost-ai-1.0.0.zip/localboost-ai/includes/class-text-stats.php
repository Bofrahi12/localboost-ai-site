<?php
/**
 * Pure-PHP text statistics (no WordPress dependencies).
 *
 * Used for readability scoring and content-length checks. Safe to use
 * anywhere, including unit tests without WordPress loaded.
 *
 * @package LocalBoostAI\Includes
 */

namespace LocalBoostAI\Includes;

class Text_Stats {

    /**
     * Count words in HTML content.
     *
     * @param string $html HTML or plain text.
     * @return int
     */
    public static function word_count(string $html): int {
        $text = html_entity_decode(strip_tags($html), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = trim((string) preg_replace('/\s+/u', ' ', $text));
        if ($text === '') {
            return 0;
        }
        $count = preg_match_all('/[\p{L}\p{N}]+/u', $text);
        return $count === false ? 0 : (int) $count;
    }

    /**
     * Count sentences in text.
     *
     * @param string $text Plain text or HTML.
     * @return int 0 for empty text, at least 1 otherwise.
     */
    public static function sentence_count(string $text): int {
        $text = trim(strip_tags($text));
        if ($text === '') {
            return 0;
        }
        $count = preg_match_all('/[.!?…]+/u', $text);
        if ($count === false) {
            return 1;
        }
        return max(1, (int) $count);
    }

    /**
     * Flesch Reading Ease score (higher = easier to read).
     *
     * @param string $text Plain text or HTML.
     * @return float Rounded to 1 decimal; 0.0 for empty text.
     */
    public static function flesch_reading_ease(string $text): float {
        $words     = self::word_count($text);
        $sentences = self::sentence_count($text);
        if ($words === 0 || $sentences === 0) {
            return 0.0;
        }
        $syllables = self::syllable_count($text);
        $score     = 206.835 - 1.015 * ($words / $sentences) - 84.6 * ($syllables / $words);
        return round($score, 1);
    }

    /**
     * Average words per sentence.
     *
     * @param string $text Plain text or HTML.
     * @return float Rounded to 1 decimal; 0.0 for empty text.
     */
    public static function avg_words_per_sentence(string $text): float {
        $sentences = self::sentence_count($text);
        if ($sentences === 0) {
            return 0.0;
        }
        return round(self::word_count($text) / $sentences, 1);
    }

    /**
     * Estimate total syllables in text.
     *
     * @param string $text Plain text or HTML.
     * @return int
     */
    private static function syllable_count(string $text): int {
        $text  = html_entity_decode(strip_tags($text), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $words = preg_split('/[^\p{L}]+/u', $text, -1, PREG_SPLIT_NO_EMPTY);
        if ($words === false) {
            return 0;
        }
        $total = 0;
        foreach ($words as $word) {
            $total += self::syllables_in_word($word);
        }
        return $total;
    }

    /**
     * Heuristic syllable count for a single word: count vowel groups,
     * discount a trailing silent "e", minimum 1.
     *
     * @param string $word Single word.
     * @return int
     */
    private static function syllables_in_word(string $word): int {
        $word = trim($word);
        if ($word === '') {
            return 0;
        }
        $word  = function_exists('mb_strtolower') ? mb_strtolower($word, 'UTF-8') : strtolower($word);
        $count = preg_match_all('/[aeiouyàáâãäåæèéêëìíîïòóôõöøùúûüýÿ]+/u', $word);
        if ($count === false) {
            return 1;
        }
        if ($count > 1 && preg_match('/e$/u', $word) === 1) {
            $count--;
        }
        return max(1, (int) $count);
    }
}
