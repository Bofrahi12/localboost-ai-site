<?php
/**
 * Multibyte-safe string helpers with graceful mbstring fallback.
 *
 * The plugin prefers the mbstring extension, but it is not guaranteed on
 * every host. These wrappers use mb_* when available and fall back to
 * Unicode-aware pure-PHP implementations otherwise, so text statistics,
 * audits and AI prompts never fatal on mbstring-less installs.
 *
 * An admin notice (see Loader) informs the site owner that installing
 * mbstring is recommended for best accuracy.
 *
 * @package LocalBoostAI\Includes
 * @since   1.0.0
 */

namespace LocalBoostAI\Includes;

if (!defined('ABSPATH')) {
    exit;
}

class Text_Utils {

    /**
     * Force the pure-PHP fallback path even when mbstring is available.
     * Test-only escape hatch (@internal).
     *
     * @var bool
     */
    private static $force_fallback = false;

    /**
     * @internal For unit tests only.
     * @param bool $force
     */
    public static function set_force_fallback_for_tests(bool $force): void {
        self::$force_fallback = $force;
    }

    /**
     * @return bool Whether the mbstring extension is available.
     */
    public static function has_mbstring(): bool {
        return function_exists('mb_strlen');
    }

    /**
     * @return bool Whether mb_* will actually be used for the next call.
     */
    private static function use_mb(): bool {
        return !self::$force_fallback && self::has_mbstring();
    }

    /**
     * Character count (not byte count).
     *
     * @param string $string
     * @return int
     */
    public static function strlen(string $string): int {
        if (self::use_mb()) {
            return mb_strlen($string, 'UTF-8');
        }
        $count = preg_match_all('/./us', $string, $m);
        return $count === false ? strlen($string) : $count;
    }

    /**
     * Character-based substring.
     *
     * @param string   $string
     * @param int      $start  Character offset (may be negative).
     * @param int|null $length Character length, or null for the rest.
     * @return string
     */
    public static function substr(string $string, int $start, ?int $length = null): string {
        if (self::use_mb()) {
            return $length === null
                ? mb_substr($string, $start, null, 'UTF-8')
                : mb_substr($string, $start, $length, 'UTF-8');
        }
        $chars = self::chars($string);
        $total = count($chars);
        if ($start < 0) {
            $start = max(0, $total + $start);
        }
        if ($length === null) {
            $slice = array_slice($chars, $start);
        } else {
            if ($length < 0) {
                $length = max(0, $total - $start + $length);
            }
            $slice = array_slice($chars, $start, $length);
        }
        return implode('', $slice);
    }

    /**
     * Unicode-aware lowercase.
     *
     * The fallback lowercases ASCII exactly and leaves other bytes
     * untouched (strtolower() only ever affects A-Z bytes, so UTF-8
     * sequences cannot be corrupted — non-ASCII case mapping is simply
     * skipped without mbstring).
     *
     * @param string $string
     * @return string
     */
    public static function strtolower(string $string): string {
        if (self::use_mb()) {
            return mb_strtolower($string, 'UTF-8');
        }
        return strtolower($string);
    }

    /**
     * Character-based strpos. Returns character offset or false.
     *
     * @param string $haystack
     * @param string $needle
     * @param int    $offset Character offset.
     * @return int|false
     */
    public static function strpos(string $haystack, string $needle, int $offset = 0) {
        if (self::use_mb()) {
            return mb_strpos($haystack, $needle, $offset, 'UTF-8');
        }
        if ($needle === '') {
            return $offset;
        }
        $chars = self::chars($haystack);
        $total = count($chars);
        if ($offset < 0) {
            $offset = max(0, $total + $offset);
        }
        $nlen = self::strlen($needle);
        for ($i = $offset; $i <= $total - $nlen; $i++) {
            if (implode('', array_slice($chars, $i, $nlen)) === $needle) {
                return $i;
            }
        }
        return false;
    }

    /**
     * Case-insensitive character-based strpos. Returns character offset or false.
     *
     * @param string $haystack
     * @param string $needle
     * @param int    $offset Character offset.
     * @return int|false
     */
    public static function stripos(string $haystack, string $needle, int $offset = 0) {
        if (self::use_mb()) {
            return mb_stripos($haystack, $needle, $offset, 'UTF-8');
        }
        return self::strpos(self::strtolower($haystack), self::strtolower($needle), $offset);
    }

    /**
     * Split a UTF-8 string into an array of characters.
     *
     * @param string $string
     * @return array<int,string>
     */
    private static function chars(string $string): array {
        $chars = preg_split('//u', $string, -1, PREG_SPLIT_NO_EMPTY);
        return is_array($chars) ? $chars : str_split($string);
    }

    /**
     * Render the "mbstring missing" admin notice.
     *
     * Shown only to admins, only when the extension is absent. The plugin
     * keeps working via the pure-PHP fallback — this is advisory.
     */
    public static function render_mbstring_notice(): void {
        if (self::has_mbstring() || !function_exists('current_user_can') || !current_user_can('manage_options')) {
            return;
        }
        echo '<div class="notice notice-warning"><p>'
            . esc_html__(
                'LocalBoost AI: the PHP mbstring extension is not installed. The plugin will keep working with a slower compatibility mode, but installing mbstring is recommended for best accuracy.',
                'localboost-ai'
            )
            . '</p></div>';
    }
}

// Register the advisory notice as soon as this module loads. The plugin is
// lazy-loaded, so on requests where Text_Utils loads after admin_notices the
// notice appears on the next admin page view instead.
if (function_exists('add_action') && !Text_Utils::has_mbstring()) {
    add_action('admin_notices', array('LocalBoostAI\Includes\Text_Utils', 'render_mbstring_notice'));
}
