<?php
/**
 * SSRF protection for outbound AI endpoint URLs.
 *
 * Single choke point used both when a base URL is saved (settings) and on
 * every outbound provider request (defense in depth). Ordinary remote
 * providers may only talk to public http(s) hosts; the self-hosted
 * ("opensource") provider intentionally supports loopback endpoints such as
 * http://localhost:11434, which keep working but are flagged so the admin
 * UI can show an explicit warning.
 *
 * DNS is resolved and the *resolved IP* is classified — hostnames that
 * resolve to private, loopback, link-local, multicast, reserved or cloud
 * metadata addresses are rejected for remote providers. Note the inherent
 * TOCTOU caveat: DNS is re-resolved at request time, so a hostile DNS name
 * that flips answers between validation and request (DNS rebinding) cannot
 * be fully ruled out by validation alone. The abstract provider additionally
 * uses wp_safe_remote_*() for remote providers so WordPress re-validates the
 * effective URL (including redirects) at send time.
 *
 * @package LocalBoostAI\Includes
 * @since   1.0.0
 */

namespace LocalBoostAI\Includes;

if (!defined('ABSPATH')) {
    exit;
}

class Url_Validator {

    /**
     * Well-known cloud metadata endpoints. Most of these already fall inside
     * link-local ranges rejected below; they are listed explicitly so the
     * intent is obvious and so IPv4-mapped IPv6 forms are caught too.
     *
     * @var array<string>
     */
    private const METADATA_IPS = array(
        '169.254.169.254',   // AWS / GCP / Azure / DigitalOcean
        '100.100.100.200',   // Alibaba Cloud
        'fd00:ec2::254',     // AWS IPv6
        '::ffff:169.254.169.254',
        '::ffff:100.100.100.200',
    );

    /**
     * Validate an AI endpoint base URL.
     *
     * @param string $url     Raw base URL (e.g. "https://api.example.com/v1").
     * @param string $context 'remote' for ordinary providers, 'selfhosted'
     *                        for the self-hosted (Ollama-compatible) provider.
     * @return array{valid: bool, error: string} Human-readable error when invalid.
     */
    public static function validate(string $url, string $context = 'remote'): array {
        $url = trim($url);
        if ($url === '') {
            return self::invalid(__('The endpoint URL is empty.', 'localboost-ai'));
        }

        $parts = parse_url($url);
        if (!is_array($parts)) {
            return self::invalid(__('The endpoint URL is malformed.', 'localboost-ai'));
        }

        $scheme = strtolower((string) ($parts['scheme'] ?? ''));
        if ($scheme !== 'http' && $scheme !== 'https') {
            return self::invalid(__('Only http:// and https:// endpoint URLs are allowed.', 'localboost-ai'));
        }

        // Embedded credentials (http://user:pass@host/) are never legitimate
        // for an AI endpoint and are a classic SSRF smuggling vector.
        if (isset($parts['user']) || isset($parts['pass'])) {
            return self::invalid(__('Endpoint URLs must not contain credentials.', 'localboost-ai'));
        }

        $host = (string) ($parts['host'] ?? '');
        if ($host === '') {
            return self::invalid(__('The endpoint URL has no host.', 'localboost-ai'));
        }

        if (isset($parts['port'])) {
            $port = (int) $parts['port'];
            if ($port < 1 || $port > 65535) {
                return self::invalid(__('The endpoint URL has an invalid port.', 'localboost-ai'));
            }
        }

        $ips = self::resolve_host($host);
        if ($ips === null) {
            return self::invalid(__('The endpoint host is not a valid IP address or hostname.', 'localboost-ai'));
        }
        if ($ips === array()) {
            return self::invalid(__('The endpoint host could not be resolved.', 'localboost-ai'));
        }

        $allow_local = ($context === 'selfhosted');

        foreach ($ips as $ip) {
            $reason = self::classify_ip($ip, $allow_local);
            if ($reason !== '') {
                return self::invalid($reason);
            }
        }

        return array('valid' => true, 'error' => '');
    }

    /**
     * Whether a base URL points at a loopback endpoint.
     *
     * Used by the admin UI to surface an explicit "local server" warning for
     * the self-hosted provider. Never blocks — blocking is validate()'s job.
     *
     * @param string $url Raw base URL.
     * @return bool
     */
    public static function is_loopback_url(string $url): bool {
        $parts = parse_url(trim($url));
        if (!is_array($parts) || !isset($parts['host'])) {
            return false;
        }
        $host = strtolower((string) $parts['host']);
        if ($host === 'localhost') {
            return true;
        }
        $ips = self::resolve_host($host);
        if (!is_array($ips)) {
            return false;
        }
        foreach ($ips as $ip) {
            if (self::is_loopback_ip($ip)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Resolve a host to a list of IP addresses.
     *
     * @param string $host Hostname or IP literal.
     * @return array<string>|null Null when the host string itself is malformed.
     */
    private static function resolve_host(string $host): ?array {
        // parse_url() keeps the brackets on IPv6 literals ("[::1]").
        if (strlen($host) > 2 && $host[0] === '[' && substr($host, -1) === ']') {
            $host = substr($host, 1, -1);
        }

        // IP literal — or a numeric obfuscation of one (decimal "2130706433",
        // hex "0x7f.0.0.1", octal "0177.0.0.1", which some resolvers accept).
        // Anything in these shapes must validate as a real IP address,
        // otherwise the host string is malformed and rejected outright.
        if (strpos($host, ':') !== false
            || preg_match('/^[0-9.]+$/', $host)
            || preg_match('/^0x[0-9a-f.]+$/i', $host)
            || preg_match('/^0[0-7.]+$/', $host)
        ) {
            $ip = filter_var($host, FILTER_VALIDATE_IP);
            return $ip === false ? null : array($ip);
        }

        if ($host === 'localhost') {
            return array('127.0.0.1');
        }

        // DNS name sanity check before resolving.
        if (strlen($host) > 253 || !preg_match('/^[a-z0-9]([a-z0-9\-.]*[a-z0-9])?$/i', $host)) {
            return null;
        }

        $ips = array();
        $v4  = gethostbynamel($host);
        if (is_array($v4)) {
            foreach ($v4 as $ip) {
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                    $ips[] = $ip;
                }
            }
        }
        if (function_exists('dns_get_record')) {
            $aaaa = @dns_get_record($host, DNS_AAAA);
            if (is_array($aaaa)) {
                foreach ($aaaa as $rec) {
                    if (isset($rec['ipv6']) && filter_var($rec['ipv6'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
                        $ips[] = $rec['ipv6'];
                    }
                }
            }
        }

        return array_values(array_unique($ips));
    }

    /**
     * Classify a resolved IP. Returns '' when allowed, else a reason string.
     *
     * @param string $ip          IP address.
     * @param bool   $allow_local Whether loopback is permitted (self-hosted).
     * @return string
     */
    private static function classify_ip(string $ip, bool $allow_local): string {
        $lower = strtolower($ip);
        foreach (self::METADATA_IPS as $blocked) {
            if ($lower === strtolower($blocked)) {
                return __('Endpoint resolves to a cloud metadata address, which is blocked.', 'localboost-ai');
            }
        }

        if (self::is_loopback_ip($ip)) {
            if ($allow_local) {
                return '';
            }
            return __('Endpoint resolves to a loopback address. Loopback endpoints are only allowed for the self-hosted provider.', 'localboost-ai');
        }

        // NO_PRIV_RANGE covers 10/8, 172.16/12, 192.168/16 (and IPv6 ULA);
        // NO_RES_RANGE covers 0/8, 169.254/16, 192.0.2/24, etc. — but NOT
        // multicast, which must be rejected explicitly.
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            $first = (int) strtok($ip, '.');
            if ($first >= 224 && $first <= 239) {
                return __('Endpoint resolves to a multicast address, which is blocked.', 'localboost-ai');
            }
        } elseif (stripos($ip, 'ff') === 0) {
            return __('Endpoint resolves to a multicast address, which is blocked.', 'localboost-ai');
        }
        $public = filter_var(
            $ip,
            FILTER_VALIDATE_IP,
            FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
        );
        if ($public === false) {
            return __('Endpoint resolves to a private or reserved address, which is blocked.', 'localboost-ai');
        }

        return '';
    }

    /**
     * @param string $ip IP address.
     * @return bool Whether it is a loopback address (127/8 or ::1).
     */
    private static function is_loopback_ip(string $ip): bool {
        if ($ip === '::1') {
            return true;
        }
        $long = ip2long($ip);
        if ($long === false) {
            return false;
        }
        // 127.0.0.0/8.
        return ($long & 0xff000000) === 0x7f000000;
    }

    /**
     * @param string $error
     * @return array{valid: bool, error: string}
     */
    private static function invalid(string $error): array {
        return array('valid' => false, 'error' => $error);
    }
}
