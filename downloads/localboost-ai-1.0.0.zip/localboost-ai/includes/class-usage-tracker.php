<?php
/**
 * Tracks feature usage (AI generations, audits, reports) per calendar month.
 *
 * Safe reservation flow (Phase 5):
 *
 *   $reservation = Usage_Tracker::reserve( 'ai_generation', 'openai', 'gpt-4o-mini' );
 *   if ( false === $reservation ) {
 *       // quota exhausted — refuse before spending anything
 *   }
 *   try {
 *       $result = $provider->generate( ... );   // the expensive call
 *       Usage_Tracker::finalize( $reservation, $tokens_used );
 *   } catch ( \Throwable $e ) {
 *       Usage_Tracker::release( $reservation, $e->getMessage() ); // quota NOT charged
 *   }
 *
 * Reservation rows live in {prefix}lbai_usage with a status column:
 *   'reserved'  – quota tentatively held, call in flight
 *   'completed' – call succeeded; the ONLY status that counts toward quota
 *   'released'  – call failed / timed out / over-limit; never charged
 *
 * Concurrency design (documented honestly — there is no fully atomic
 * primitive here, only a bounded, self-correcting protocol):
 *
 *   1. reserve() first runs the cheap can_use() fast-path (UX gate; not
 *      authoritative).
 *   2. It then INSERTs a single 'reserved' row. The INSERT itself is atomic.
 *   3. It re-counts (completed + reserved) rows for the feature/month. If the
 *      count is over the limit, it immediately release()s its own reservation
 *      and returns false.
 *
 * Residual race: two reserves interleaved between step 2 and step 3 can both
 * briefly hold reservations past the limit, but each recheck observes the
 * other's row, so at least one of them releases itself. Overshoot is bounded
 * by the race window and self-corrects; it can never turn into a permanent
 * over-charge because quota is ONLY charged by finalize(), and failed,
 * timed-out or released calls never consume quota.
 *
 * Backward compatibility: record( $feature, $amount ) still works and is
 * implemented as reserve() + finalize(). get_monthly_usage(), can_use(),
 * remaining() and usage_message() keep their signatures and count only
 * 'completed' rows, exactly as before.
 *
 * @package LocalBoostAI\Includes
 */

namespace LocalBoostAI\Includes;

if (!defined('ABSPATH')) {
    exit;
}

class Usage_Tracker {

    const STATUS_RESERVED  = 'reserved';
    const STATUS_COMPLETED = 'completed';
    const STATUS_RELEASED  = 'released';

    /**
     * Human-readable labels for tracked features.
     */
    const FEATURE_LABELS = array(
        'ai_generation' => 'AI generations',
        'audit'         => 'audits',
        'report'        => 'reports',
        'content'       => 'content generations',
    );

    /**
     * First second of the current calendar month (GMT), matching the
     * current_time( 'mysql', true ) timestamps stored in the table.
     *
     * @return string
     */
    private static function month_start(): string {
        return gmdate('Y-m-01 00:00:00');
    }

    /**
     * Fetch a single usage row by id.
     *
     * @param int $id Row id.
     * @return array|null
     */
    private static function get_row_by_id(int $id): ?array {
        global $wpdb;
        $table = $wpdb->prefix . 'lbai_usage';
        $row   = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id, feature, amount, status, provider, model, tokens FROM {$table} WHERE id = %d",
                $id
            ),
            ARRAY_A
        );
        return is_array($row) ? $row : null;
    }

    /**
     * Units consumed this month, counting 'completed' rows only.
     *
     * @param string $feature Feature slug.
     * @param bool   $include_reserved Also count in-flight reservations.
     * @return int
     */
    private static function sum_monthly(string $feature, bool $include_reserved = false): int {
        global $wpdb;
        $table  = $wpdb->prefix . 'lbai_usage';
        $status = $include_reserved
            ? "AND status IN ('completed', 'reserved')"
            : "AND status = 'completed'";
        // Table name is prefix + hardcoded suffix; statuses are literals.
        $total  = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COALESCE(SUM(amount), 0) FROM {$table} WHERE feature = %s AND created_at >= %s {$status}",
                sanitize_key($feature),
                self::month_start()
            )
        );
        return (int) $total;
    }

    /**
     * Reserve quota for one upcoming call.
     *
     * Returns false without touching the database state when the quota is
     * already exhausted. Otherwise inserts a 'reserved' row and re-checks;
     * if the recheck finds the month over quota (a concurrent reservation
     * won the race), the reservation releases itself and false is returned.
     *
     * @param string $feature  Feature slug (e.g. "ai_generation").
     * @param string $provider Provider id, e.g. "openai" (may be '').
     * @param string $model    Model id (may be '').
     * @param int    $amount   Units to reserve.
     * @return int|false Reservation id, or false when quota is exhausted.
     */
    public static function reserve(string $feature, string $provider = '', string $model = '', int $amount = 1) {
        global $wpdb;

        $feature  = sanitize_key($feature);
        $provider = substr(sanitize_text_field($provider), 0, 60);
        $model    = substr(sanitize_text_field($model), 0, 80);
        $amount   = max(1, $amount);

        $limit = self::get_limit($feature);
        if ($limit >= 0 && !self::can_use($feature)) {
            return false;
        }

        $table = $wpdb->prefix . 'lbai_usage';
        $ok    = $wpdb->insert(
            $table,
            array(
                'feature'    => $feature,
                'amount'     => $amount,
                'status'     => self::STATUS_RESERVED,
                'provider'   => $provider,
                'model'      => $model,
                'tokens'     => 0,
                'created_at' => current_time('mysql', true),
            ),
            array('%s', '%d', '%s', '%s', '%s', '%d', '%s')
        );
        if (false === $ok) {
            return false;
        }
        $reservation_id = (int) $wpdb->insert_id;

        // Authoritative gate: count everything held this month, including
        // in-flight reservations. A lost race releases itself here.
        if ($limit >= 0 && self::sum_monthly($feature, true) > $limit) {
            self::release($reservation_id, 'quota_exceeded');
            return false;
        }

        return $reservation_id;
    }

    /**
     * Mark a reservation completed (the call succeeded) — this is the only
     * transition that charges quota.
     *
     * Idempotent: finalizing an already-completed reservation returns true
     * without double-counting. A released reservation can never be finalized.
     *
     * @param int $reservation_id Reservation id from reserve().
     * @param int $tokens         Tokens consumed, when reported by the provider.
     * @return bool
     */
    public static function finalize(int $reservation_id, int $tokens = 0): bool {
        global $wpdb;

        if ($reservation_id <= 0) {
            return false;
        }
        $row = self::get_row_by_id($reservation_id);
        if (null === $row) {
            return false;
        }
        if (self::STATUS_COMPLETED === $row['status']) {
            return true; // idempotent — already charged exactly once
        }
        if (self::STATUS_RELEASED === $row['status']) {
            return false; // a failed call must never become a charge
        }

        $table  = $wpdb->prefix . 'lbai_usage';
        $result = $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table} SET status = 'completed', tokens = %d WHERE id = %d",
                max(0, $tokens),
                $reservation_id
            )
        );
        return false !== $result;
    }

    /**
     * Release a reservation (call failed, timed out, or was never started).
     *
     * The reservation stops counting toward quota immediately and is kept as
     * a 'released' row so failure counts stay visible in reports.
     * Idempotent: releasing twice returns true. A completed reservation can
     * never be released (quota charges are final).
     *
     * @param int    $reservation_id Reservation id from reserve().
     * @param string $error          Short failure reason (stored, not charged).
     * @return bool
     */
    public static function release(int $reservation_id, string $error = ''): bool {
        global $wpdb;

        if ($reservation_id <= 0) {
            return false;
        }
        $row = self::get_row_by_id($reservation_id);
        if (null === $row) {
            return false;
        }
        if (self::STATUS_RELEASED === $row['status']) {
            return true; // idempotent
        }
        if (self::STATUS_COMPLETED === $row['status']) {
            return false; // completed charges are final
        }

        $table  = $wpdb->prefix . 'lbai_usage';
        $result = $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table} SET status = 'released', error = %s WHERE id = %d",
                substr(sanitize_text_field($error), 0, 1000),
                $reservation_id
            )
        );
        return false !== $result;
    }

    /**
     * Record usage of a feature (backward-compatible).
     *
     * Implemented as reserve() + finalize(): a failed insert or an
     * exhausted quota returns false and charges nothing.
     *
     * @param string $feature Feature slug (e.g. "ai_generation").
     * @param int    $amount  Units consumed.
     * @return bool
     */
    public static function record(string $feature, int $amount = 1): bool {
        $reservation_id = self::reserve($feature, '', '', $amount);
        if (false === $reservation_id) {
            return false;
        }
        return self::finalize($reservation_id);
    }

    /**
     * Total usage of a feature in the current calendar month (GMT).
     *
     * Counts 'completed' rows only — reservations and released rows never
     * inflate the number.
     *
     * @param string $feature Feature slug.
     * @return int
     */
    public static function get_monthly_usage(string $feature): int {
        return self::sum_monthly($feature, false);
    }

    /**
     * Monthly limit for a feature from the current plan.
     * -1 means unlimited.
     *
     * @param string $feature Feature slug.
     * @return int
     */
    public static function get_limit(string $feature): int {
        $limits = Licensing::get_limits();
        return isset($limits[$feature]) ? (int) $limits[$feature] : 0;
    }

    /**
     * Remaining units for a feature this month.
     * Returns -1 when the plan is unlimited.
     *
     * @param string $feature Feature slug.
     * @return int
     */
    public static function remaining(string $feature): int {
        $limit = self::get_limit($feature);
        if ($limit < 0) {
            return -1;
        }
        return max(0, $limit - self::get_monthly_usage($feature));
    }

    /**
     * Whether the feature may still be used this month.
     *
     * UX fast-path only; reserve() performs the authoritative check.
     *
     * @param string $feature Feature slug.
     * @return bool
     */
    public static function can_use(string $feature): bool {
        $limit = self::get_limit($feature);
        if ($limit < 0) {
            return true;
        }
        return self::get_monthly_usage($feature) < $limit;
    }

    /**
     * Detailed usage report for the dashboard (current calendar month, GMT).
     *
     * @param string $feature Feature slug.
     * @return array{
     *   feature: string,
     *   period: string,
     *   requests: int,
     *   successful: int,
     *   failed: int,
     *   tokens_total: int,
     *   provider_breakdown: array<string, array{requests: int, successful: int, failed: int, tokens: int}>,
     *   quota: int,
     *   remaining: int
     * }
     */
    public static function get_usage_report(string $feature): array {
        global $wpdb;

        $feature = sanitize_key($feature);
        $table   = $wpdb->prefix . 'lbai_usage';

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT status, provider, COUNT(*) AS n, COALESCE(SUM(amount), 0) AS units, COALESCE(SUM(tokens), 0) AS tokens
                 FROM {$table}
                 WHERE feature = %s AND created_at >= %s
                 GROUP BY status, provider",
                $feature,
                self::month_start()
            ),
            ARRAY_A
        );

        $successful = 0;
        $failed     = 0;
        $tokens     = 0;
        $breakdown  = array();

        foreach ((array) $rows as $row) {
            $provider = (string) ($row['provider'] ?? '');
            $n        = (int) ($row['n'] ?? 0);
            $is_ok    = self::STATUS_COMPLETED === ($row['status'] ?? '');

            if (!isset($breakdown[$provider])) {
                $breakdown[$provider] = array(
                    'requests'   => 0,
                    'successful' => 0,
                    'failed'     => 0,
                    'tokens'     => 0,
                );
            }
            $breakdown[$provider]['requests'] += $n;
            $breakdown[$provider]['tokens']   += (int) ($row['tokens'] ?? 0);

            if ($is_ok) {
                $successful += $n;
                $breakdown[$provider]['successful'] += $n;
                $tokens += (int) ($row['tokens'] ?? 0);
            } elseif (self::STATUS_RELEASED === ($row['status'] ?? '')) {
                // Released reservations = failed / timed-out attempts.
                $failed += $n;
                $breakdown[$provider]['failed'] += $n;
            }
            // 'reserved' rows still in flight are not counted as requests
            // until they finalize or release.
        }

        return array(
            'feature'            => $feature,
            'period'             => gmdate('Y-m'),
            'requests'           => $successful + $failed,
            'successful'         => $successful,
            'failed'             => $failed,
            'tokens_total'       => $tokens,
            'provider_breakdown' => $breakdown,
            'quota'              => self::get_limit($feature),
            'remaining'          => self::remaining($feature),
        );
    }

    /**
     * Friendly usage message, e.g. "You have used 8 of 10 AI generations this month."
     *
     * @param string $feature Feature slug.
     * @return string
     */
    public static function usage_message(string $feature): string {
        $used   = self::get_monthly_usage($feature);
        $limit  = self::get_limit($feature);
        $labels = self::FEATURE_LABELS;
        $label  = isset($labels[$feature]) ? $labels[$feature] : $feature;

        if ($limit < 0) {
            return sprintf(
                /* translators: 1: used count, 2: feature label */
                esc_html__('You have used %1$d %2$s this month (unlimited plan).', 'localboost-ai'),
                $used,
                $label
            );
        }

        return sprintf(
            /* translators: 1: used count, 2: limit, 3: feature label */
            esc_html__('You have used %1$d of %2$d %3$s this month.', 'localboost-ai'),
            $used,
            $limit,
            $label
        );
    }
}
