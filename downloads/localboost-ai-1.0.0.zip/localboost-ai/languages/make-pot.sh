#!/usr/bin/env bash
#
# Generate languages/localboost-ai.pot from the plugin source files.
#
# Requires the WordPress i18n tools:
#   wp i18n make-pot   (from the WP-CLI i18n command package)
#
# Usage: bash languages/make-pot.sh
#
set -euo pipefail

PLUGIN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
POT_FILE="$PLUGIN_DIR/languages/localboost-ai.pot"

if ! command -v wp >/dev/null 2>&1; then
  echo "Error: wp (WP-CLI) is not installed or not on PATH." >&2
  echo "Install WP-CLI and the i18n command: wp package install wp-cli/i18n-command" >&2
  exit 1
fi

wp i18n make-pot "$PLUGIN_DIR" "$POT_FILE" \
  --domain=localboost-ai \
  --exclude="tests,node_modules,vendor" \
  --package-name="LocalBoost AI"

echo "POT file written to $POT_FILE"
