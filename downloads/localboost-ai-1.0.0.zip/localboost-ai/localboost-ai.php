<?php
/**
 * Plugin Name:       LocalBoost AI
 * Plugin URI:        https://localboost.ai/
 * Description:       AI-powered Local SEO assistant for small businesses — audits, AI fixes, local SEO and schema.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            LocalBoost
 * Author URI:        https://localboost.ai/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       localboost-ai
 * Domain Path:       /languages
 *
 * @package LocalBoostAI
 */

if (!defined('ABSPATH')) {
    exit;
}

define('LBAI_VERSION', '1.0.0');
define('LBAI_PLUGIN_FILE', __FILE__);
define('LBAI_PATH', plugin_dir_path(__FILE__));
define('LBAI_URL', plugin_dir_url(__FILE__));
define('LBAI_TEXT_DOMAIN', 'localboost-ai');

/**
 * PSR-4-ish autoloader for the LocalBoostAI namespace.
 *
 * Rule: class LocalBoostAI\X\Y_Z        -> <lowercase-x>/class-<y-z-kebab>.php
 *       interface LocalBoostAI\X\Foo_I  -> <lowercase-x>/interface-foo.php
 *       (the trailing "_Interface" suffix is stripped for interface files)
 *
 * Only classes inside the LocalBoostAI namespace are ever loaded, and only
 * from inside this plugin's directory, so a missing module can never fatal.
 */
spl_autoload_register(function ($class) {
    $prefix = 'LocalBoostAI\\';
    if (strpos($class, $prefix) !== 0) {
        return;
    }

    $relative = substr($class, strlen($prefix));
    $parts    = explode('\\', $relative);
    $basename = array_pop($parts);

    foreach ($parts as $part) {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $part)) {
            return;
        }
    }
    if (!preg_match('/^[A-Za-z0-9_]+$/', $basename)) {
        return;
    }

    $dirs = array_map('strtolower', $parts);

    if (substr($basename, -10) === '_Interface') {
        $file = 'interface-' . strtolower(str_replace('_', '-', substr($basename, 0, -10))) . '.php';
    } else {
        $file = 'class-' . strtolower(str_replace('_', '-', $basename)) . '.php';
    }

    $path = LBAI_PATH . implode('/', $dirs) . '/' . $file;
    if (is_file($path)) {
        require_once $path;
        return;
    }

    // Back-compat fallback: some modules ship as class-lb-<kebab>.php
    // (e.g. admin/class-lb-admin.php). Primary mapping wins when present.
    if (strpos($file, 'class-') === 0) {
        $alt = LBAI_PATH . implode('/', $dirs) . '/class-lb-' . substr($file, 6);
        if (is_file($alt)) {
            require_once $alt;
        }
    }
});

register_activation_hook(__FILE__, 'LocalBoostAI\Includes\Activator::activate');
register_deactivation_hook(__FILE__, 'LocalBoostAI\Includes\Deactivator::deactivate');

add_action('init', function () {
    load_plugin_textdomain(
        LBAI_TEXT_DOMAIN,
        false,
        dirname(plugin_basename(LBAI_PLUGIN_FILE)) . '/languages'
    );
});

add_action('plugins_loaded', function () {
    (new \LocalBoostAI\Includes\Loader())->register();
});
