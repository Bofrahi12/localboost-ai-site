<?php
/**
 * Abstract AI provider.
 *
 * Shared HTTP plumbing, error mapping and per-call option overrides for all
 * providers. Concrete providers only implement endpoint, headers, payload
 * building and response parsing.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

namespace LocalBoostAI\Providers;

use LocalBoostAI\Includes\AI_Exception;
use LocalBoostAI\Includes\Url_Validator;

defined( 'ABSPATH' ) || exit;

/**
 * Class Abstract_AI_Provider
 */
abstract class Abstract_AI_Provider implements AI_Provider_Interface {

	/**
	 * Raw API key. Never exposed outside HTTP Authorization headers.
	 *
	 * @var string
	 */
	protected $api_key;

	/**
	 * Model id for this instance.
	 *
	 * @var string
	 */
	protected $model;

	/**
	 * Temperature override, or null to use the provider default.
	 *
	 * @var float|null
	 */
	protected $temperature;

	/**
	 * Max tokens override, or null to use the provider default.
	 *
	 * @var int|null
	 */
	protected $max_tokens;

	/**
	 * Constructor.
	 *
	 * @param array $config {
	 *     @type string     $api_key     Provider API key.
	 *     @type string     $model       Model id (falls back to get_default_model()).
	 *     @type float|null $temperature Optional temperature.
	 *     @type int|null   $max_tokens  Optional max tokens.
	 * }
	 */
	public function __construct( array $config ) {
		$this->api_key = (string) ( $config['api_key'] ?? '' );

		$model       = trim( (string) ( $config['model'] ?? '' ) );
		$this->model = '' !== $model ? $model : $this->get_default_model();

		$this->temperature = isset( $config['temperature'] ) && '' !== $config['temperature'] && null !== $config['temperature']
			? (float) $config['temperature']
			: null;

		$this->max_tokens = isset( $config['max_tokens'] ) && '' !== $config['max_tokens'] && null !== $config['max_tokens']
			? (int) $config['max_tokens']
			: null;
	}

	/**
	 * {@inheritdoc}
	 */
	public function generate( array $messages, array $options = [] ): array {
		if ( $this->requires_api_key() && '' === $this->api_key ) {
			throw AI_Exception::not_configured();
		}

		// Apply per-call overrides without mutating the instance state.
		$saved = [
			'model'       => $this->model,
			'temperature' => $this->temperature,
			'max_tokens'  => $this->max_tokens,
		];

		if ( isset( $options['model'] ) && '' !== trim( (string) $options['model'] ) ) {
			$this->model = trim( (string) $options['model'] );
		}
		if ( array_key_exists( 'temperature', $options ) ) {
			$this->temperature = null === $options['temperature'] ? null : (float) $options['temperature'];
		}
		if ( array_key_exists( 'max_tokens', $options ) ) {
			$this->max_tokens = null === $options['max_tokens'] ? null : (int) $options['max_tokens'];
		}

		try {
			$payload = $this->build_payload( $messages );
			$data    = $this->http_post( $this->get_endpoint(), $this->get_headers(), $payload );
			$parsed  = $this->parse_response( $data );
			$text    = trim( (string) ( $parsed['text'] ?? '' ) );

			if ( '' === $text ) {
				throw AI_Exception::empty_response();
			}

			return [
				'text'              => $text,
				'prompt_tokens'     => (int) ( $parsed['prompt_tokens'] ?? 0 ),
				'completion_tokens' => (int) ( $parsed['completion_tokens'] ?? 0 ),
				'model'             => (string) ( $parsed['model'] ?? $this->model ),
			];
		} finally {
			$this->model       = $saved['model'];
			$this->temperature = $saved['temperature'];
			$this->max_tokens  = $saved['max_tokens'];
		}
	}

	/**
	 * Chat endpoint URL for this provider.
	 *
	 * @return string
	 */
	abstract protected function get_endpoint(): string;

	/**
	 * Extra HTTP headers (authentication, versioning) for this provider.
	 *
	 * The API key must only ever leave the server inside these headers
	 * (or the provider's documented auth mechanism).
	 *
	 * @return array<string,string>
	 */
	abstract protected function get_headers(): array;

	/**
	 * Whether this provider needs an API key to generate.
	 *
	 * Self-hosted endpoints (e.g. Ollama) usually don't.
	 *
	 * @return bool
	 */
	public function requires_api_key(): bool {
		return true;
	}

	/**
	 * Build the provider-specific request payload.
	 *
	 * @param array $messages Normalized chat messages.
	 *
	 * @return array
	 */
	abstract protected function build_payload( array $messages ): array;

	/**
	 * Extract a normalized result from the decoded provider response.
	 *
	 * Must return at least [ 'text' => string ]; prompt_tokens,
	 * completion_tokens and model are optional.
	 *
	 * @param array $data Decoded JSON response.
	 *
	 * @return array
	 */
	abstract protected function parse_response( array $data ): array;

	/**
	 * Effective temperature, honoring the supports_temperature() flag.
	 *
	 * @return float|null
	 */
	protected function get_temperature() {
		if ( ! $this->supports_temperature() || null === $this->temperature ) {
			return null;
		}

		return max( 0.0, min( 2.0, $this->temperature ) );
	}

	/**
	 * Effective max tokens, honoring the supports_max_tokens() flag.
	 *
	 * @return int|null
	 */
	protected function get_max_tokens() {
		if ( ! $this->supports_max_tokens() || null === $this->max_tokens ) {
			return null;
		}

		return max( 1, $this->max_tokens );
	}

	/**
	 * Whether this provider may talk to loopback/local endpoints.
	 *
	 * False for ordinary remote providers (SSRF protection blocks private
	 * and loopback destinations). The self-hosted provider overrides this
	 * to true so http://localhost:11434 keeps working.
	 *
	 * @return bool
	 */
	protected function allows_local_endpoints(): bool {
		return false;
	}

	/**
	 * Validate an outbound endpoint URL against the SSRF policy.
	 *
	 * Runs on every request (defense in depth alongside the settings-save
	 * check): blocks non-http(s) schemes, embedded credentials, unresolvable
	 * hosts and private/loopback/link-local/metadata destinations for
	 * remote providers.
	 *
	 * @param string $url Endpoint URL.
	 *
	 * @throws AI_Exception When the URL violates the SSRF policy.
	 */
	protected function guard_endpoint_url( string $url ): void {
		$context = $this->allows_local_endpoints() ? 'selfhosted' : 'remote';
		$check   = Url_Validator::validate( $url, $context );
		if ( ! $check['valid'] ) {
			throw AI_Exception::invalid_output( 'Blocked unsafe endpoint URL' );
		}
	}

	/**
	 * Choose the WP HTTP API variant for this provider.
	 *
	 * Remote providers use wp_safe_remote_*() so WordPress itself rejects
	 * unsafe redirect targets at send time; the self-hosted provider must
	 * keep plain wp_remote_*() because loopback is its intended use.
	 *
	 * @param string $function 'post' or 'get'.
	 * @return callable
	 */
	protected function http_function( string $function ): callable {
		if ( $this->allows_local_endpoints() ) {
			return 'post' === $function ? 'wp_remote_post' : 'wp_remote_get';
		}
		return 'post' === $function ? 'wp_safe_remote_post' : 'wp_safe_remote_get';
	}

	/**
	 * POST a JSON body via the WordPress HTTP API.
	 *
	 * @param string $url     Endpoint URL.
	 * @param array  $headers Extra headers.
	 * @param array  $body    Payload, JSON-encoded automatically.
	 *
	 * @return array Decoded JSON response.
	 *
	 * @throws AI_Exception Mapped, user-friendly failure.
	 */
	protected function http_post( string $url, array $headers, array $body ): array {
		$this->guard_endpoint_url( $url );
		$fn       = $this->http_function( 'post' );
		$response = $fn(
			$url,
			[
				'timeout' => 60,
				'headers' => array_merge( [ 'Content-Type' => 'application/json' ], $headers ),
				'body'    => wp_json_encode( $body ),
			]
		);

		return $this->handle_http_response( $response );
	}

	/**
	 * GET via the WordPress HTTP API (used for credential validation).
	 *
	 * @param string $url     Endpoint URL.
	 * @param array  $headers Extra headers.
	 *
	 * @return array Decoded JSON response.
	 *
	 * @throws AI_Exception Mapped, user-friendly failure.
	 */
	protected function http_get( string $url, array $headers ): array {
		$this->guard_endpoint_url( $url );
		$fn       = $this->http_function( 'get' );
		$response = $fn(
			$url,
			[
				'timeout' => 30,
				'headers' => $headers,
			]
		);

		return $this->handle_http_response( $response );
	}

	/**
	 * Map an HTTP response (or transport error) to decoded data or AI_Exception.
	 *
	 * Raw provider error bodies are never surfaced to the caller.
	 *
	 * @param array|\WP_Error $response wp_remote_* response.
	 *
	 * @return array Decoded JSON response.
	 *
	 * @throws AI_Exception
	 */
	protected function handle_http_response( $response ): array {
		if ( is_wp_error( $response ) ) {
			$message = strtolower( (string) $response->get_error_message() );

			if (
				false !== strpos( $message, 'timed out' )
				|| false !== strpos( $message, 'timeout' )
				|| false !== strpos( $message, 'curl error 28' )
			) {
				throw AI_Exception::timeout();
			}

			throw AI_Exception::provider_unavailable();
		}

		$code = (int) wp_remote_retrieve_response_code( $response );

		if ( 401 === $code || 403 === $code ) {
			throw AI_Exception::invalid_key();
		}

		if ( 429 === $code ) {
			throw AI_Exception::rate_limited();
		}

		if ( $code >= 500 ) {
			throw AI_Exception::provider_unavailable();
		}

		if ( $code < 200 || $code >= 300 ) {
			throw AI_Exception::invalid_output( 'HTTP ' . $code );
		}

		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( ! is_array( $data ) ) {
			throw AI_Exception::invalid_output();
		}

		return $data;
	}
}
