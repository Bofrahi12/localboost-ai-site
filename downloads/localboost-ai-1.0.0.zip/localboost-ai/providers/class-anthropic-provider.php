<?php
/**
 * Anthropic provider.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

namespace LocalBoostAI\Providers;

use LocalBoostAI\Includes\AI_Exception;

defined( 'ABSPATH' ) || exit;

/**
 * Class Anthropic_Provider
 */
class Anthropic_Provider extends Abstract_AI_Provider {

	/**
	 * Anthropic messages endpoint.
	 */
	const API_ENDPOINT = 'https://api.anthropic.com/v1/messages';

	/**
	 * Anthropic API version header.
	 */
	const API_VERSION = '2023-06-01';

	/**
	 * {@inheritdoc}
	 */
	public function get_id(): string {
		return 'anthropic';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_label(): string {
		return __( 'Anthropic', 'localboost-ai' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_models(): array {
		return [
			'claude-3-5-haiku-latest'  => __( 'Claude 3.5 Haiku (fast, affordable)', 'localboost-ai' ),
			'claude-3-5-sonnet-latest' => __( 'Claude 3.5 Sonnet (most capable)', 'localboost-ai' ),
		];
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_default_model(): string {
		return 'claude-3-5-haiku-latest';
	}

	/**
	 * {@inheritdoc}
	 */
	public function supports_temperature(): bool {
		return true;
	}

	/**
	 * {@inheritdoc}
	 */
	public function supports_max_tokens(): bool {
		return true;
	}

	/**
	 * {@inheritdoc}
	 */
	protected function get_endpoint(): string {
		return self::API_ENDPOINT;
	}

	/**
	 * {@inheritdoc}
	 */
	protected function get_headers(): array {
		return [
			'x-api-key'         => $this->api_key,
			'anthropic-version' => self::API_VERSION,
		];
	}

	/**
	 * {@inheritdoc}
	 */
	protected function build_payload( array $messages ): array {
		$system       = '';
		$api_messages = [];

		foreach ( $messages as $message ) {
			$role    = isset( $message['role'] ) ? (string) $message['role'] : 'user';
			$content = isset( $message['content'] ) ? (string) $message['content'] : '';

			// Anthropic takes the system prompt as a top-level parameter.
			if ( 'system' === $role ) {
				$system .= ( '' !== $system ? "\n\n" : '' ) . $content;
				continue;
			}

			if ( ! in_array( $role, [ 'user', 'assistant' ], true ) ) {
				$role = 'user';
			}

			$api_messages[] = [
				'role'    => $role,
				'content' => $content,
			];
		}

		$payload = [
			'model'      => $this->model,
			// max_tokens is required by the Anthropic API.
			'max_tokens' => $this->get_max_tokens() ?? 1024,
			'messages'   => $api_messages,
		];

		if ( '' !== $system ) {
			$payload['system'] = $system;
		}

		$temperature = $this->get_temperature();
		if ( null !== $temperature ) {
			$payload['temperature'] = $temperature;
		}

		return $payload;
	}

	/**
	 * {@inheritdoc}
	 */
	protected function parse_response( array $data ): array {
		$text = '';

		$content = isset( $data['content'] ) && is_array( $data['content'] ) ? $data['content'] : [];
		foreach ( $content as $block ) {
			if ( isset( $block['type'], $block['text'] ) && 'text' === $block['type'] ) {
				$text .= (string) $block['text'];
			}
		}

		$usage = isset( $data['usage'] ) && is_array( $data['usage'] ) ? $data['usage'] : [];

		return [
			'text'              => $text,
			'prompt_tokens'     => (int) ( $usage['input_tokens'] ?? 0 ),
			'completion_tokens' => (int) ( $usage['output_tokens'] ?? 0 ),
			'model'             => isset( $data['model'] ) ? (string) $data['model'] : $this->model,
		];
	}

	/**
	 * {@inheritdoc}
	 *
	 * Validates with a minimal messages call (max_tokens = 1) so the check is
	 * cheap. A 401/403 surfaces as AI_Exception::invalid_key() via the shared
	 * HTTP handler and maps to false here.
	 */
	public function validate_credentials( string $api_key ): bool {
		try {
			$this->http_post(
				self::API_ENDPOINT,
				[
					'x-api-key'         => $api_key,
					'anthropic-version' => self::API_VERSION,
				],
				[
					'model'      => $this->get_default_model(),
					'max_tokens' => 1,
					'messages'   => [
						[
							'role'    => 'user',
							'content' => 'Hi',
						],
					],
				]
			);

			return true;
		} catch ( AI_Exception $e ) {
			return false;
		}
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_setup_hint(): string {
		return __( 'Create an API key at console.anthropic.com under API keys. Usage is billed to your Anthropic account.', 'localboost-ai' );
	}
}
