<?php
/**
 * Google Gemini provider.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

namespace LocalBoostAI\Providers;

use LocalBoostAI\Includes\AI_Exception;

defined( 'ABSPATH' ) || exit;

/**
 * Class Gemini_Provider
 */
class Gemini_Provider extends Abstract_AI_Provider {

	/**
	 * {@inheritdoc}
	 */
	public function get_id(): string {
		return 'gemini';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_label(): string {
		return __( 'Google Gemini', 'localboost-ai' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_models(): array {
		return [
			'gemini-2.0-flash' => __( 'Gemini 2.0 Flash (fast, affordable)', 'localboost-ai' ),
			'gemini-1.5-pro'   => __( 'Gemini 1.5 Pro (most capable)', 'localboost-ai' ),
		];
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_default_model(): string {
		return 'gemini-2.0-flash';
	}

	/**
	 * {@inheritdoc}
	 */
	public function supports_temperature(): bool {
		return true;
	}

	/**
	 * {@inheritdoc}
	 */
	public function supports_max_tokens(): bool {
		return true;
	}

	/**
	 * {@inheritdoc}
	 */
	protected function get_endpoint(): string {
		return 'https://generativelanguage.googleapis.com/v1beta/models/' . $this->model . ':generateContent';
	}

	/**
	 * {@inheritdoc}
	 *
	 * Gemini accepts the API key via the X-Goog-Api-Key header, which keeps it
	 * out of URLs and server access logs.
	 */
	protected function get_headers(): array {
		return [
			'X-Goog-Api-Key' => $this->api_key,
		];
	}

	/**
	 * {@inheritdoc}
	 */
	protected function build_payload( array $messages ): array {
		$system   = '';
		$contents = [];

		foreach ( $messages as $message ) {
			$role    = isset( $message['role'] ) ? (string) $message['role'] : 'user';
			$content = isset( $message['content'] ) ? (string) $message['content'] : '';

			// Gemini takes the system prompt as a top-level system_instruction.
			if ( 'system' === $role ) {
				$system .= ( '' !== $system ? "\n\n" : '' ) . $content;
				continue;
			}

			$api_role = ( 'assistant' === $role ) ? 'model' : 'user';

			// Gemini expects alternating user/model turns; merge consecutive
			// same-role messages into one content block.
			$last = count( $contents ) - 1;
			if ( $last >= 0 && $contents[ $last ]['role'] === $api_role ) {
				$contents[ $last ]['parts'][] = [ 'text' => $content ];
			} else {
				$contents[] = [
					'role'  => $api_role,
					'parts' => [
						[ 'text' => $content ],
					],
				];
			}
		}

		$payload = [ 'contents' => $contents ];

		if ( '' !== $system ) {
			$payload['system_instruction'] = [
				'parts' => [
					[ 'text' => $system ],
				],
			];
		}

		$config      = [];
		$temperature = $this->get_temperature();
		if ( null !== $temperature ) {
			$config['temperature'] = $temperature;
		}

		$max_tokens = $this->get_max_tokens();
		if ( null !== $max_tokens ) {
			$config['maxOutputTokens'] = $max_tokens;
		}

		if ( ! empty( $config ) ) {
			$payload['generationConfig'] = $config;
		}

		return $payload;
	}

	/**
	 * {@inheritdoc}
	 */
	protected function parse_response( array $data ): array {
		$text = '';

		$candidate = isset( $data['candidates'][0] ) && is_array( $data['candidates'][0] ) ? $data['candidates'][0] : [];
		$parts     = isset( $candidate['content']['parts'] ) && is_array( $candidate['content']['parts'] )
			? $candidate['content']['parts']
			: [];

		foreach ( $parts as $part ) {
			if ( isset( $part['text'] ) ) {
				$text .= (string) $part['text'];
			}
		}

		$usage = isset( $data['usageMetadata'] ) && is_array( $data['usageMetadata'] ) ? $data['usageMetadata'] : [];

		return [
			'text'              => $text,
			'prompt_tokens'     => (int) ( $usage['promptTokenCount'] ?? 0 ),
			'completion_tokens' => (int) ( $usage['candidatesTokenCount'] ?? 0 ),
			'model'             => $this->model,
		];
	}

	/**
	 * {@inheritdoc}
	 */
	public function validate_credentials( string $api_key ): bool {
		try {
			$this->http_get(
				'https://generativelanguage.googleapis.com/v1beta/models',
				[ 'X-Goog-Api-Key' => $api_key ]
			);

			return true;
		} catch ( AI_Exception $e ) {
			return false;
		}
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_setup_hint(): string {
		return __( 'Get a free API key at Google AI Studio (aistudio.google.com) via "Get API key".', 'localboost-ai' );
	}
}
