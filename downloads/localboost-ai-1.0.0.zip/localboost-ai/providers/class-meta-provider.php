<?php
/**
 * Meta AI provider (OpenAI-compatible chat completions).
 *
 * Uses a configurable base URL because Meta AI API endpoints vary by
 * deployment. The base URL is read from the 'lbai_meta_base_url' option and
 * defaults to https://api.meta.ai/v1.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

namespace LocalBoostAI\Providers;

use LocalBoostAI\Includes\AI_Exception;
use LocalBoostAI\Includes\Options;

defined( 'ABSPATH' ) || exit;

/**
 * Class Meta_Provider
 */
class Meta_Provider extends OpenAI_Provider {

	/**
	 * {@inheritdoc}
	 */
	public function get_id(): string {
		return 'meta';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_label(): string {
		return __( 'Meta AI', 'localboost-ai' );
	}

	/**
	 * {@inheritdoc}
	 *
	 * The model list is filterable because Meta AI model availability depends
	 * on the configured endpoint.
	 *
	 * @return array<string,string>
	 */
	public function get_models(): array {
		/**
		 * Filters the Meta AI model list (id => label).
		 *
		 * @param array<string,string> $models Default model list.
		 */
		return apply_filters(
			'lbai_meta_models',
			[
				'llama-3-3-70b-versatile' => __( 'Llama 3.3 70B', 'localboost-ai' ),
			]
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_default_model(): string {
		$ids = array_keys( $this->get_models() );

		return $ids ? (string) $ids[0] : 'llama-3-3-70b-versatile';
	}

	/**
	 * Configured API base URL, without trailing slash.
	 *
	 * @return string
	 */
	protected function get_base_url(): string {
		$base = Options::get( 'lbai_meta_base_url' );
		$base = is_string( $base ) ? trim( $base ) : '';

		if ( '' === $base ) {
			$base = 'https://api.meta.ai/v1';
		}

		return rtrim( $base, '/' );
	}

	/**
	 * {@inheritdoc}
	 */
	protected function get_endpoint(): string {
		return $this->get_base_url() . '/chat/completions';
	}

	/**
	 * {@inheritdoc}
	 */
	public function validate_credentials( string $api_key ): bool {
		try {
			$this->http_get(
				$this->get_base_url() . '/models',
				[ 'Authorization' => 'Bearer ' . $api_key ]
			);

			return true;
		} catch ( AI_Exception $e ) {
			return false;
		}
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_setup_hint(): string {
		return __( 'Meta AI needs an API-compatible endpoint and key. Verify the endpoint URL and your credentials with your Meta AI API provider before saving — LocalBoost AI cannot provision Meta access for you.', 'localboost-ai' );
	}
}
