<?php
/**
 * OpenAI provider.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

namespace LocalBoostAI\Providers;

use LocalBoostAI\Includes\AI_Exception;

defined( 'ABSPATH' ) || exit;

/**
 * Class OpenAI_Provider
 */
class OpenAI_Provider extends Abstract_AI_Provider {

	/**
	 * OpenAI API base URL.
	 */
	const API_BASE = 'https://api.openai.com/v1';

	/**
	 * {@inheritdoc}
	 */
	public function get_id(): string {
		return 'openai';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_label(): string {
		return __( 'OpenAI', 'localboost-ai' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_models(): array {
		return [
			'gpt-4o-mini' => __( 'GPT-4o mini (fast, affordable)', 'localboost-ai' ),
			'gpt-4o'      => __( 'GPT-4o (most capable)', 'localboost-ai' ),
		];
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_default_model(): string {
		return 'gpt-4o-mini';
	}

	/**
	 * {@inheritdoc}
	 */
	public function supports_temperature(): bool {
		return true;
	}

	/**
	 * {@inheritdoc}
	 */
	public function supports_max_tokens(): bool {
		return true;
	}

	/**
	 * {@inheritdoc}
	 */
	protected function get_endpoint(): string {
		return self::API_BASE . '/chat/completions';
	}

	/**
	 * {@inheritdoc}
	 */
	protected function get_headers(): array {
		return [
			'Authorization' => 'Bearer ' . $this->api_key,
		];
	}

	/**
	 * {@inheritdoc}
	 */
	protected function build_payload( array $messages ): array {
		$payload = [
			'model'    => $this->model,
			'messages' => $this->normalize_messages( $messages ),
		];

		$temperature = $this->get_temperature();
		if ( null !== $temperature ) {
			$payload['temperature'] = $temperature;
		}

		$max_tokens = $this->get_max_tokens();
		if ( null !== $max_tokens ) {
			$payload['max_tokens'] = $max_tokens;
		}

		return $payload;
	}

	/**
	 * Keep only role/content pairs with valid chat roles.
	 *
	 * @param array $messages Raw messages.
	 *
	 * @return array
	 */
	protected function normalize_messages( array $messages ): array {
		$normalized = [];

		foreach ( $messages as $message ) {
			$role    = isset( $message['role'] ) ? (string) $message['role'] : 'user';
			$content = isset( $message['content'] ) ? (string) $message['content'] : '';

			if ( ! in_array( $role, [ 'system', 'user', 'assistant' ], true ) ) {
				$role = 'user';
			}

			$normalized[] = [
				'role'    => $role,
				'content' => $content,
			];
		}

		return $normalized;
	}

	/**
	 * {@inheritdoc}
	 */
	protected function parse_response( array $data ): array {
		$choice = isset( $data['choices'][0] ) && is_array( $data['choices'][0] ) ? $data['choices'][0] : [];
		$text   = isset( $choice['message']['content'] ) ? (string) $choice['message']['content'] : '';
		$usage  = isset( $data['usage'] ) && is_array( $data['usage'] ) ? $data['usage'] : [];

		return [
			'text'              => $text,
			'prompt_tokens'     => (int) ( $usage['prompt_tokens'] ?? 0 ),
			'completion_tokens' => (int) ( $usage['completion_tokens'] ?? 0 ),
			'model'             => isset( $data['model'] ) ? (string) $data['model'] : $this->model,
		];
	}

	/**
	 * {@inheritdoc}
	 */
	public function validate_credentials( string $api_key ): bool {
		try {
			$this->http_get(
				self::API_BASE . '/models',
				[ 'Authorization' => 'Bearer ' . $api_key ]
			);

			return true;
		} catch ( AI_Exception $e ) {
			return false;
		}
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_setup_hint(): string {
		return __( 'Create an API key at platform.openai.com under API keys. Billing must be enabled on your OpenAI account.', 'localboost-ai' );
	}
}
