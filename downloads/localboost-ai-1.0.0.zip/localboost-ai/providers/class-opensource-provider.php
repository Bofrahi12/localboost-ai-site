<?php
/**
 * Open-source provider (self-hosted, OpenAI-compatible endpoint).
 *
 * Talks to any OpenAI-compatible chat-completions server such as Ollama
 * (`ollama serve` exposes http://localhost:11434/v1), LM Studio or a
 * llama.cpp server. The base URL is configurable; most local servers need
 * no API key at all.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

namespace LocalBoostAI\Providers;

use LocalBoostAI\Includes\AI_Exception;
use LocalBoostAI\Includes\Options;

defined( 'ABSPATH' ) || exit;

/**
 * Class Opensource_Provider
 */
class Opensource_Provider extends OpenAI_Provider {

	/**
	 * {@inheritdoc}
	 */
	public function get_id(): string {
		return 'opensource';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_label(): string {
		return __( 'Open-source (self-hosted)', 'localboost-ai' );
	}

	/**
	 * {@inheritdoc}
	 *
	 * Local model availability depends entirely on the configured server,
	 * so the list is filterable.
	 *
	 * @return array<string,string>
	 */
	public function get_models(): array {
		/**
		 * Filters the open-source model list (id => label).
		 *
		 * @param array<string,string> $models Default model list.
		 */
		return apply_filters(
			'lbai_opensource_models',
			[
				'llama3.1' => __( 'Llama 3.1', 'localboost-ai' ),
			]
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_default_model(): string {
		$ids = array_keys( $this->get_models() );

		return $ids ? (string) $ids[0] : 'llama3.1';
	}

	/**
	 * Local servers usually need no API key.
	 *
	 * @return bool
	 */
	public function requires_api_key(): bool {
		return false;
	}

	/**
	 * Self-hosted endpoints intentionally live on loopback (e.g. Ollama at
	 * http://localhost:11434). SSRF protection stays on for everything else:
	 * only loopback is additionally permitted, never private LAN ranges or
	 * cloud metadata addresses.
	 *
	 * @return bool
	 */
	protected function allows_local_endpoints(): bool {
		return true;
	}

	/**
	 * Whether the currently configured base URL is a loopback endpoint.
	 *
	 * The admin UI should surface an explicit warning when this is true
	 * ("requests go to a server on this machine").
	 *
	 * @return bool
	 */
	public function uses_loopback_endpoint(): bool {
		return \LocalBoostAI\Includes\Url_Validator::is_loopback_url( $this->get_base_url() );
	}

	/**
	 * Configured server base URL, without trailing slash.
	 *
	 * @return string
	 */
	protected function get_base_url(): string {
		$base = Options::get( 'lbai_opensource_base_url' );
		$base = is_string( $base ) ? trim( $base ) : '';

		if ( '' === $base ) {
			$base = 'http://localhost:11434/v1';
		}

		return rtrim( $base, '/' );
	}

	/**
	 * {@inheritdoc}
	 */
	protected function get_endpoint(): string {
		return $this->get_base_url() . '/chat/completions';
	}

	/**
	 * {@inheritdoc}
	 */
	protected function get_headers(): array {
		$headers = [ 'Content-Type' => 'application/json' ];

		if ( '' !== $this->api_key ) {
			$headers['Authorization'] = 'Bearer ' . $this->api_key;
		}

		return $headers;
	}

	/**
	 * {@inheritdoc}
	 */
	public function validate_credentials( string $api_key ): bool {
		$headers = [];
		if ( '' !== $api_key ) {
			$headers['Authorization'] = 'Bearer ' . $api_key;
		}

		try {
			$this->http_get( $this->get_base_url() . '/models', $headers );

			return true;
		} catch ( AI_Exception $e ) {
			return false;
		}
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_setup_hint(): string {
		return __( 'Run an OpenAI-compatible local server — e.g. Ollama (`ollama serve`), LM Studio, or a llama.cpp server — and point the base URL at its /v1 endpoint. Most local servers need no API key.', 'localboost-ai' );
	}
}
