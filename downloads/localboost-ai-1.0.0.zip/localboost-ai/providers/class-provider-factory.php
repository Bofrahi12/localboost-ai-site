<?php
/**
 * AI provider factory.
 *
 * Resolves the configured provider, assembles its configuration from the
 * encrypted Secure_Store (API key) and plugin options (model, temperature,
 * max tokens), and hands back a ready-to-use provider instance.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

namespace LocalBoostAI\Providers;

use LocalBoostAI\Includes\AI_Exception;
use LocalBoostAI\Includes\Options;
use LocalBoostAI\Includes\Secure_Store;

defined( 'ABSPATH' ) || exit;

/**
 * Class Provider_Factory
 */
final class Provider_Factory {

	/**
	 * All registered providers as id => class-name pairs.
	 *
	 * @return array<string,class-string<AI_Provider_Interface>>
	 */
	public static function get_available_providers(): array {
		/**
		 * Filters the registered AI providers.
		 *
		 * Add a custom provider by mapping its id to a class implementing
		 * LocalBoostAI\Providers\AI_Provider_Interface.
		 *
		 * @param array<string,class-string<AI_Provider_Interface>> $providers Provider map.
		 */
		return apply_filters(
			'lbai_ai_providers',
			[
				'openai'     => OpenAI_Provider::class,
				'anthropic'  => Anthropic_Provider::class,
				'gemini'     => Gemini_Provider::class,
				'meta'       => Meta_Provider::class,
				'opensource' => Opensource_Provider::class,
			]
		);
	}

	/**
	 * Create a configured provider instance.
	 *
	 * The API key is read from the encrypted Secure_Store and is never
	 * written to options, logs or output.
	 *
	 * @param string $id Provider id.
	 *
	 * @return AI_Provider_Interface
	 *
	 * @throws AI_Exception When the id is unknown or no key is configured.
	 */
	public static function create( string $id ): AI_Provider_Interface {
		$providers = self::get_available_providers();

		if ( ! isset( $providers[ $id ] ) || ! class_exists( $providers[ $id ] ) ) {
			throw AI_Exception::invalid_output( 'Unknown provider' );
		}

		$class   = $providers[ $id ];
		$api_key = Secure_Store::get_api_key( $id );

		/** @var AI_Provider_Interface $probe Lightweight instance for defaults. */
		$probe = new $class( [ 'api_key' => $api_key ] );

		// Providers that don't extend the abstract base are assumed to need a key.
		$needs_key = ! method_exists( $probe, 'requires_api_key' ) || $probe->requires_api_key();

		if ( '' === trim( (string) $api_key ) && $needs_key ) {
			throw AI_Exception::not_configured();
		}

		$models = $probe->get_models();

		$model = Options::get( 'lbai_ai_model' );
		$model = is_string( $model ) ? trim( $model ) : '';
		if ( '' === $model || ! array_key_exists( $model, $models ) ) {
			$model = $probe->get_default_model();
		}

		return new $class(
			[
				'api_key'     => $api_key,
				'model'       => $model,
				'temperature' => Options::get( 'lbai_ai_temperature' ),
				'max_tokens'  => Options::get( 'lbai_ai_max_tokens' ),
			]
		);
	}

	/**
	 * Create the provider selected in the plugin settings.
	 *
	 * @return AI_Provider_Interface
	 *
	 * @throws AI_Exception When nothing usable is configured.
	 */
	public static function get_configured_provider(): AI_Provider_Interface {
		$id = Options::get( 'lbai_ai_provider' );
		$id = is_string( $id ) ? sanitize_key( $id ) : '';

		if ( '' === $id ) {
			$id = 'openai';
		}

		return self::create( $id );
	}
}
