<?php
/**
 * AI provider interface.
 *
 * Contract every AI provider implementation must fulfil. Implementations must
 * never leak API keys, raw provider error payloads, or internal prompts —
 * all failures are reported as \LocalBoostAI\Includes\AI_Exception carrying
 * a user-friendly, translatable message.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

namespace LocalBoostAI\Providers;

defined( 'ABSPATH' ) || exit;

/**
 * Interface AI_Provider_Interface
 */
interface AI_Provider_Interface {

	/**
	 * Machine-readable provider id, e.g. 'openai'.
	 *
	 * @return string
	 */
	public function get_id(): string;

	/**
	 * Human-readable provider label.
	 *
	 * @return string
	 */
	public function get_label(): string;

	/**
	 * Available models as id => label pairs.
	 *
	 * @return array<string,string>
	 */
	public function get_models(): array;

	/**
	 * Default model id, used when none is configured.
	 *
	 * @return string
	 */
	public function get_default_model(): string;

	/**
	 * Whether the provider honours a temperature parameter.
	 *
	 * @return bool
	 */
	public function supports_temperature(): bool;

	/**
	 * Whether the provider honours a max-tokens parameter.
	 *
	 * @return bool
	 */
	public function supports_max_tokens(): bool;

	/**
	 * Send chat messages to the provider.
	 *
	 * @param array $messages List of [ 'role' => 'system|user|assistant', 'content' => string ].
	 * @param array $options  Optional per-call overrides: model, temperature, max_tokens.
	 *
	 * @return array{ text: string, prompt_tokens: int, completion_tokens: int, model: string }
	 *
	 * @throws \LocalBoostAI\Includes\AI_Exception On any failure.
	 */
	public function generate( array $messages, array $options = [] ): array;

	/**
	 * Check whether an API key is accepted by the provider.
	 *
	 * The key is used for a single lightweight request and is never stored.
	 *
	 * @param string $api_key Raw API key to test.
	 *
	 * @return bool True when the key is accepted.
	 */
	public function validate_credentials( string $api_key ): bool;

	/**
	 * Translatable hint telling the user where to obtain an API key.
	 *
	 * @return string
	 */
	public function get_setup_hint(): string;
}
