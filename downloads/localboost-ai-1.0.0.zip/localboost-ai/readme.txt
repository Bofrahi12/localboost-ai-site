=== LocalBoost AI ===
Contributors: localboost
Tags: seo, local seo, ai, schema, google business
Requires at least: 6.0
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI-powered Local SEO assistant for small businesses: audit your site, fix issues with AI, manage local business info and schema.

== Description ==

LocalBoost AI helps local businesses — restaurants, dentists, lawyers, contractors, salons, shops and more — discover SEO problems and fix them with AI, without needing to understand SEO.

**Scan → Find problems → Explain → Generate fixes → Review → Apply → Monitor**

= What it does =

* **SEO Audit** — analyzes titles, meta descriptions, headings, content length, images and alt text, links, canonical URLs, robots directives, Open Graph data, structured data and local business information. Issues are categorized as Critical, Warning, Recommendation or Passed, each with an explanation and a "Fix with AI" button.
* **AI Optimizer** — improves titles, meta descriptions, H1s, introductions, FAQs, calls to action and image alt text. Every suggestion is shown side-by-side with the current content — nothing is applied without your explicit approval.
* **Local SEO** — manage your business name, address, phone, hours, services and social profiles in one place, with a consistency checker that flags differences across your site.
* **Schema** — generates valid Schema.org JSON-LD (LocalBusiness, Organization, Service, FAQPage, BreadcrumbList) with a preview before activation.
* **Content generator** — service pages, location pages, FAQs, blog ideas and more in 7 languages, with a clear warning against low-quality doorway pages.
* **Keyword assistant** — local keyword ideas, clearly labelled as AI-generated ideas (no fake search volume data).
* **Reports** — score history, issues fixed, AI usage, CSV export and white-label branding (Pro).
* **Monitoring** — scheduled weekly/monthly audits with email notifications.

= AI providers =

LocalBoost AI is not locked to one provider. Connect OpenAI, Anthropic, Google Gemini, Meta AI or open-source models through a clean provider abstraction. Your API key is stored encrypted on your server and is never exposed to front-end JavaScript.

= Free vs Pro =

Free includes the basic SEO audit, limited AI generations, basic Local SEO, basic schema and basic reports. Pro adds advanced audits, higher AI limits, advanced models, advanced reports, automated monitoring, advanced schema, agency features and white-label reports. No payment is processed inside the plugin — upgrade handling connects to your chosen payment provider.

== Installation ==

1. Upload the `localboost-ai` folder to `/wp-content/plugins/` or install from the Plugins screen.2. Activate the plugin through the **Plugins** menu in WordPress.
3. You will be guided through a 7-step setup: business info → AI provider → API key → first scan → recommendations.
4. Open **LocalBoost AI → AI Settings** any time to change provider or key.

See `docs/INSTALL.md` for detailed instructions.

= Requirements =

* WordPress 6.0 or higher, PHP 7.4–8.4 (all plugin code is verified compatible with this range).
* The PHP `mbstring` extension is recommended for best text-analysis accuracy; the plugin falls back to a pure-PHP compatibility mode when it is absent (an admin notice is shown in that case).
* The `openssl` extension is required for encrypted API-key storage; `libsodium` is used when available for authenticated encryption.
* Outbound HTTPS requests to the configured AI provider (or a local server such as Ollama for the self-hosted provider).

== Frequently Asked Questions ==

= Do I need SEO knowledge to use this plugin? =

No. Every issue is explained in plain language with a recommended action, and AI fixes always require your approval before anything changes.

= Which AI providers are supported? =

OpenAI, Anthropic, Google Gemini, Meta AI and open-source models through the provider abstraction. You bring your own API key from the provider of your choice. See `docs/AI_PROVIDERS.md`.

= Is my API key safe? =

Keys are stored encrypted on your server, never shown again after saving, and never exposed to front-end JavaScript or logs.

= Does the plugin slow down my website? =

No. Admin assets load only on LocalBoost AI screens, audits run on demand or on a WP-Cron schedule (never on every page load), and schema output is a single small JSON-LD block.

= Is the plugin GDPR compliant? =

The plugin does not claim automatic GDPR compliance — no plugin can. It is built privacy-consciously: minimal data collection, page content is sent to your chosen AI provider only when you request a generation, and it provides settings export plus uninstall-time data deletion. See `docs/SECURITY.md` and configure the plugin appropriately for your situation.

= Will the SEO score improve my Google ranking? =

The "LocalBoost SEO Score" is an internal health metric (0–100) based on technical, on-page, local, content and structured-data checks. It is not an official Google ranking score. Fixing real issues is what helps rankings.

== Screenshots ==

1. Dashboard — overall and local SEO scores, issue counts, AI usage, quick actions.
2. SEO Audit — issue list with severity badges and Fix with AI buttons.
3. AI Optimizer — current vs AI suggestion review dialog.
4. Local SEO — business profile and NAP consistency checker.
5. Schema — JSON-LD preview before activation.
6. Reports — score history and CSV export.

== Changelog ==

= 1.0.0 =
* Initial release.
* Admin dashboard with LocalBoost SEO Score, issue counts and usage tracking.
* Real SEO auditing engine (technical, on-page, local, content, structured data).
* AI Optimizer with current-vs-suggestion review and explicit approval.
* Provider abstraction: OpenAI, Anthropic, Google Gemini, Meta AI, open-source models.
* Local SEO profile, NAP consistency checker, Schema.org JSON-LD generation with preview.
* AI content generator (7 languages) with doorway-page warning.
* Local keyword assistant (AI-generated ideas, no fake volume data).
* Reports with CSV export; white-label branding (Pro).
* Freemium architecture with honest Pro gating; no payment processing in-plugin.
* Weekly/monthly monitoring via WP-Cron with email notifications.
* Security: capability checks, nonces, sanitization, escaping, encrypted API keys, REST permission callbacks.
* Internationalization: all strings translatable, text domain `localboost-ai`.
* 7-step onboarding wizard.
