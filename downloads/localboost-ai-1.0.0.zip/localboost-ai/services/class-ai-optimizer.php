<?php
/**
 * AI SEO optimizer service.
 *
 * Generates AI improvement suggestions for individual on-page SEO fields and
 * applies them only through an explicit, user-approved apply step. Nothing is
 * ever overwritten automatically. Every applied change is recorded in
 * Change_History with its previous value, and a WordPress revision is
 * created before overwriting post_title or post_content.
 *
 * Field names follow the canonical vocabulary of Field_Registry
 * (title, meta_description, h1, introduction, faq, cta, alt_texts,
 * internal_links). Legacy aliases are accepted and normalized; the
 * deprecated h2_structure is still accepted for compatibility but hidden
 * from new UI.
 *
 * Apply behavior per field:
 * - title: overwrites post_title.
 * - meta_description: writes the active SEO plugin's meta key when one is
 *   detected (Yoast: _yoast_wpseo_metadesc, Rank Math: rank_math_description),
 *   otherwise the plugin's own _lbai_meta_description key. This mirrors
 *   frontend/class-lb-frontend.php, which skips its own meta tag output
 *   when Yoast or Rank Math is active, so the description is never printed
 *   twice.
 * - h1, introduction, faq, cta, h2_structure: require explicit placement
 *   (prepend|append) into post_content.
 * - alt_texts: rewrites missing alt attributes in post_content from the
 *   AI-provided per-line alt texts.
 * - internal_links: advisory only — the suggestion is guidance for the
 *   editor, not something the service inserts automatically.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

namespace LocalBoostAI\Services;

use LocalBoostAI\Includes\AI_Exception;
use LocalBoostAI\Includes\Field_Registry;
use LocalBoostAI\Includes\Options;
use LocalBoostAI\Includes\Rate_Limiter;
use LocalBoostAI\Includes\Text_Utils;
use LocalBoostAI\Includes\Usage_Tracker;
use LocalBoostAI\Providers\Provider_Factory;

defined( 'ABSPATH' ) || exit;

/**
 * Class AI_Optimizer
 */
class AI_Optimizer {

	/**
	 * Optimizable fields. Labels are stored in English and translated at the
	 * use site so the constant stays a plain data structure.
	 *
	 * The deprecated h2_structure is accepted for backward compatibility
	 * but hidden from new UI.
	 */
	const FIELDS = [
		'title'            => [
			'label' => 'SEO title',
			'max'   => 60,
		],
		'meta_description' => [
			'label' => 'Meta description',
			'max'   => 160,
		],
		'h1'               => [
			'label' => 'H1 heading',
			'max'   => 0,
		],
		'introduction'     => [
			'label' => 'Introduction',
			'max'   => 0,
		],
		'faq'              => [
			'label' => 'FAQ section',
			'max'   => 0,
		],
		'cta'              => [
			'label' => 'Call to action',
			'max'   => 0,
		],
		'alt_texts'        => [
			'label' => 'Image alt texts',
			'max'   => 0,
		],
		'internal_links'   => [
			'label' => 'Internal linking suggestions',
			'max'   => 0,
		],
		'h2_structure'     => [
			'label'      => 'H2 structure',
			'max'        => 0,
			'deprecated' => true,
		],
	];

	/**
	 * Supported content language codes => language names (for AI prompts).
	 */
	const LANGUAGES = [
		'en' => 'English',
		'fr' => 'French',
		'de' => 'German',
		'es' => 'Spanish',
		'it' => 'Italian',
		'nl' => 'Dutch',
		'pt' => 'Portuguese',
	];

	/**
	 * Generate an AI suggestion for a single SEO field of a post.
	 *
	 * Returns a current-vs-suggestion pair for explicit user review; nothing
	 * is written to the post here. Use apply_suggestion() to apply.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $field   Canonical field key (legacy aliases are normalized).
	 * @param array  $args    Optional. { @type string $keyword  Primary keyword hint.
	 *                                   @type string $language Language code override. }
	 *
	 * @return array{
	 *     field: string,
	 *     label: string,
	 *     current: string,
	 *     suggestion: string,
	 *     current_value: string,
	 *     suggested_value: string,
	 *     model: string,
	 *     tokens: array{ prompt: int, completion: int }
	 * }
	 *
	 * @throws AI_Exception
	 */
	public function optimize_field( int $post_id, string $field, array $args = [] ): array {
		$post = get_post( $post_id );
		if ( ! $post instanceof \WP_Post ) {
			throw AI_Exception::invalid_output( __( 'Post not found.', 'localboost-ai' ) );
		}

		$field = Field_Registry::canonicalize( $field );
		if ( null === $field || ! isset( self::FIELDS[ $field ] ) ) {
			throw AI_Exception::invalid_output( __( 'Unknown optimization field.', 'localboost-ai' ) );
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			throw new AI_Exception( 'permission_denied', __( 'You are not allowed to edit this post.', 'localboost-ai' ) );
		}

		if ( ! Usage_Tracker::can_use( 'ai_generation' ) ) {
			throw new AI_Exception( 'limit_reached', Usage_Tracker::usage_message( 'ai_generation' ) );
		}

		$this->check_rate_limit( 'lbai_ai_generate' );

		$current   = $this->get_current_value( $post, $field );
		$business  = $this->get_business_context();
		$language  = $this->language_name( isset( $args['language'] ) ? (string) $args['language'] : '' );
		$biz_parts = array_filter(
			[
				$business['name'],
				$business['type'],
				$business['city'],
				$business['country'],
			]
		);

		$system = sprintf(
			'You are an SEO copywriter for local businesses. Business: %s. Language: %s. Respond with ONLY the optimized text, no explanations.',
			$biz_parts ? implode( ', ', $biz_parts ) : 'a local business',
			$language
		);

		$prompt = $this->build_field_prompt( $field, $post, $current, $business, $args );

		$provider = Provider_Factory::get_configured_provider();
		$result   = $provider->generate(
			[
				[
					'role'    => 'system',
					'content' => $system,
				],
				[
					'role'    => 'user',
					'content' => $prompt,
				],
			]
		);

		Usage_Tracker::record( 'ai_generation' );

		return [
			'field'           => $field,
			'label'           => __( self::FIELDS[ $field ]['label'], 'localboost-ai' ),
			// Canonical preview keys; 'current'/'suggestion' are kept as
			// backward-compatible aliases.
			'current_value'   => $current,
			'suggested_value' => $result['text'],
			'current'         => $current,
			'suggestion'      => $result['text'],
			'model'           => $result['model'],
			'tokens'          => [
				'prompt'     => $result['prompt_tokens'],
				'completion' => $result['completion_tokens'],
			],
		];
	}

	/**
	 * Apply a previously reviewed AI suggestion to a post.
	 *
	 * This is the ONLY method that writes AI output to a post, and it runs
	 * only on explicit user approval (one suggestion at a time). A revision
	 * safety net is created before overwriting post_title/post_content, and
	 * the change (with its previous value) is recorded in Change_History so
	 * it can be undone.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $field   Canonical field key (legacy aliases are normalized).
	 * @param string $value   Reviewed suggestion to apply.
	 * @param array  $args    Optional. { @type string $placement 'prepend'|'append' for content fields.
	 *                                   @type string $provider  AI provider name (recorded in history).
	 *                                   @type string $model     AI model name (recorded in history). }
	 *
	 * @return array{ success: bool, message: string, revision_id: int, change_id: int }
	 *
	 * @throws AI_Exception
	 */
	public function apply_suggestion( int $post_id, string $field, string $value, array $args = [] ): array {
		$post = get_post( $post_id );
		if ( ! $post instanceof \WP_Post ) {
			throw AI_Exception::invalid_output( __( 'Post not found.', 'localboost-ai' ) );
		}

		$field = Field_Registry::canonicalize( $field );
		if ( null === $field || ! isset( self::FIELDS[ $field ] ) ) {
			throw AI_Exception::invalid_output( __( 'Unknown optimization field.', 'localboost-ai' ) );
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			throw new AI_Exception( 'permission_denied', __( 'You are not allowed to edit this post.', 'localboost-ai' ) );
		}

		// Advisory-only fields are guidance, not insertable content.
		if ( 'internal_links' === $field ) {
			throw AI_Exception::invalid_output( __( 'Internal link suggestions are advisory: add the links manually in the post editor where they help the reader.', 'localboost-ai' ) );
		}

		$value = $this->sanitize_field_value( $field, $value );

		if ( '' === trim( $value ) ) {
			throw AI_Exception::invalid_output( __( 'The suggestion is empty; nothing to apply.', 'localboost-ai' ) );
		}

		$max = (int) self::FIELDS[ $field ]['max'];
		if ( $max > 0 && Text_Utils::strlen( $value ) > $max ) {
			$value = Text_Utils::substr( $value, 0, $max );
		}

		$new_stored = $this->compute_stored_value( $post, $field, $value, $args );
		$old_stored = $this->get_stored_value( $post, $field );

		if ( '' !== $new_stored && $new_stored === $old_stored ) {
			throw AI_Exception::invalid_output( __( 'The suggestion is identical to the current value; nothing to apply.', 'localboost-ai' ) );
		}

		// Revision safety net before overwriting.
		$revision_id = function_exists( 'wp_save_post_revision' ) ? (int) wp_save_post_revision( $post_id ) : 0;

		try {
			$this->write_field_value( $post_id, $field, $new_stored );
		} catch ( AI_Exception $e ) {
			// Record the failed write so the change history stays truthful,
			// then re-throw for the caller.
			Change_History::record(
				array(
					'post_id'   => $post_id,
					'user_id'   => function_exists( 'get_current_user_id' ) ? get_current_user_id() : 0,
					'field'     => $field,
					'old_value' => $old_stored,
					'new_value' => $new_stored,
					'provider'  => isset( $args['provider'] ) ? (string) $args['provider'] : '',
					'model'     => isset( $args['model'] ) ? (string) $args['model'] : '',
					'status'    => 'failed',
				)
			);
			throw $e;
		}

		$change_id = Change_History::record(
			array(
				'post_id'   => $post_id,
				'user_id'   => function_exists( 'get_current_user_id' ) ? get_current_user_id() : 0,
				'field'     => $field,
				'old_value' => $old_stored,
				'new_value' => $new_stored,
				'provider'  => isset( $args['provider'] ) ? (string) $args['provider'] : '',
				'model'     => isset( $args['model'] ) ? (string) $args['model'] : '',
				'status'    => 'applied',
			)
		);

		return [
			'success'     => true,
			'message'     => __( 'Applied successfully.', 'localboost-ai' ),
			'revision_id' => $revision_id,
			'change_id'   => (int) $change_id,
		];
	}

	/**
	 * Sanitize a suggestion value according to its field type.
	 *
	 * Plain-text fields (title, meta_description) strip all HTML; the
	 * alt_texts field is plain text too, one suggestion per line, so each
	 * line is sanitized individually; rich fields (h1, introduction, faq,
	 * cta, h2_structure) allow the safe HTML subset of wp_kses_post().
	 *
	 * @param string $field Canonical field key.
	 * @param string $value Raw suggestion.
	 * @return string
	 */
	public function sanitize_field_value( string $field, string $value ): string {
		if ( in_array( $field, array( 'title', 'meta_description' ), true ) ) {
			return sanitize_text_field( $value );
		}
		if ( 'alt_texts' === $field ) {
			// Alt text is plain text, never HTML: sanitize line by line so
			// markup can never reach an alt attribute.
			$lines = explode( "\n", str_replace( array( "\r\n", "\r" ), "\n", $value ) );
			$lines = array_map( 'sanitize_text_field', $lines );
			return implode( "\n", $lines );
		}
		return wp_kses_post( $value );
	}

	/**
	 * Post meta key used when writing the AI meta description.
	 *
	 * Mirrors frontend/class-lb-frontend.php: when Yoast SEO or Rank Math is
	 * active, their key is used and the frontend skips its own output, so
	 * the description is never printed twice. Otherwise the plugin's own
	 * key is used; the legacy _lbai_meta_description key is preserved for
	 * backward compatibility with stored data.
	 *
	 * @return string
	 */
	public function meta_description_key(): string {
		if ( defined( 'WPSEO_VERSION' ) ) {
			return '_yoast_wpseo_metadesc';
		}
		if ( defined( 'RANK_MATH_VERSION' ) ) {
			return 'rank_math_description';
		}
		return '_lbai_meta_description';
	}

	/**
	 * Read the meta description, preferring the active SEO plugin's key.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	protected function get_meta_description( int $post_id ): string {
		$keys = array_unique(
			array(
				$this->meta_description_key(),
				'_lbai_meta_description',
				'lbai_meta_description',
				'_yoast_wpseo_metadesc',
				'rank_math_description',
			)
		);
		foreach ( $keys as $key ) {
			$value = get_post_meta( $post_id, $key, true );
			if ( '' !== trim( (string) $value ) ) {
				return (string) $value;
			}
		}
		return '';
	}

	/**
	 * Read the raw currently-stored value for a field's write channel.
	 *
	 * @param \WP_Post $post  Post being optimized.
	 * @param string   $field Canonical field key.
	 * @return string
	 */
	protected function get_stored_value( \WP_Post $post, string $field ): string {
		if ( 'title' === $field ) {
			return (string) $post->post_title;
		}
		if ( 'meta_description' === $field ) {
			return $this->get_meta_description( (int) $post->ID );
		}
		return (string) $post->post_content;
	}

	/**
	 * Compute the full stored value for a field from a reviewed suggestion.
	 *
	 * @param \WP_Post $post  Post being optimized.
	 * @param string   $field Canonical field key.
	 * @param string   $value Sanitized suggestion.
	 * @param array    $args  Caller args (placement for content fields).
	 * @return string
	 * @throws AI_Exception
	 */
	protected function compute_stored_value( \WP_Post $post, string $field, string $value, array $args ): string {
		if ( 'title' === $field || 'meta_description' === $field ) {
			return $value;
		}

		if ( 'alt_texts' === $field ) {
			return $this->apply_alt_texts( (string) $post->post_content, $value );
		}

		// h1, introduction, faq, cta, h2_structure: explicit placement only.
		$placement = isset( $args['placement'] ) ? (string) $args['placement'] : '';
		if ( ! in_array( $placement, array( 'prepend', 'append' ), true ) ) {
			throw AI_Exception::invalid_output( __( 'Choose where to insert the content: prepend or append.', 'localboost-ai' ) );
		}

		return ( 'prepend' === $placement )
			? $value . "\n\n" . (string) $post->post_content
			: (string) $post->post_content . "\n\n" . $value;
	}

	/**
	 * Write a sanitized, fully-computed value to its storage channel.
	 *
	 * Also used by Change_History::undo_last() to restore a previous value.
	 * Callers must have verified capabilities and created any revision
	 * safety net.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $field   Canonical field key (aliases accepted).
	 * @param string $value   Fully-computed stored value.
	 * @return void
	 * @throws AI_Exception
	 */
	public function write_field_value( int $post_id, string $field, string $value ): void {
		$field = Field_Registry::canonicalize( $field );
		if ( null === $field || ! isset( self::FIELDS[ $field ] ) ) {
			throw AI_Exception::invalid_output( __( 'Unknown optimization field.', 'localboost-ai' ) );
		}

		if ( 'title' === $field ) {
			$updated = wp_update_post(
				array(
					'ID'         => $post_id,
					'post_title' => $value,
				),
				true
			);
		} elseif ( 'meta_description' === $field ) {
			update_post_meta( $post_id, $this->meta_description_key(), $value );
			$updated = $post_id;
		} else {
			$updated = wp_update_post(
				array(
					'ID'           => $post_id,
					'post_content' => $value,
				),
				true
			);
		}

		if ( is_wp_error( $updated ) || ! $updated ) {
			throw AI_Exception::invalid_output( __( 'Could not apply the suggestion. Please try again.', 'localboost-ai' ) );
		}
	}

	/**
	 * Rewrite missing alt attributes in post content from AI alt texts.
	 *
	 * The AI suggestion lists one alt text per line, in the order the images
	 * were presented by get_images_missing_alt() (document order). Images
	 * that already carry alt text are left untouched; when the suggestion
	 * has fewer lines than missing-alt images, the remaining images are left
	 * untouched.
	 *
	 * @param string $content   Post content.
	 * @param string $alt_texts One alt text per line.
	 * @return string Updated post content.
	 * @throws AI_Exception When no image was updated.
	 */
	protected function apply_alt_texts( string $content, string $alt_texts ): string {
		$lines = array_values(
			array_filter(
				array_map( 'trim', explode( "\n", str_replace( array( "\r\n", "\r" ), "\n", $alt_texts ) ) ),
				function ( $line ) {
					return '' !== $line;
				}
			)
		);

		if ( empty( $lines ) ) {
			throw AI_Exception::invalid_output( __( 'The AI suggestion contains no alt texts to apply.', 'localboost-ai' ) );
		}

		$index = 0;
		$total = count( $lines );

		$new_content = preg_replace_callback(
			'/<img\b[^>]*>/i',
			function ( $matches ) use ( $lines, $total, &$index ) {
				$tag = $matches[0];

				// Leave images that already have usable alt text untouched.
				if ( preg_match( '/\salt\s*=\s*(?:"([^"]*)"|\'([^\']*)\')/i', $tag, $alt_match ) ) {
					$existing = isset( $alt_match[1] ) && '' !== $alt_match[1]
						? $alt_match[1]
						: (string) ( $alt_match[2] ?? '' );
					if ( '' !== trim( $existing ) ) {
						return $tag;
					}
				}

				if ( $index >= $total ) {
					return $tag;
				}

				$alt = $lines[ $index ];
				$index++;

				// Remove any empty alt attribute, then insert the new one.
				$tag = (string) preg_replace( '/\salt\s*=\s*(?:"[^"]*"|\'[^\']*\')/i', '', $tag );
				$tag = rtrim( $tag );
				if ( '>' !== substr( $tag, -1 ) ) {
					return $matches[0];
				}
				if ( '/>' === substr( $tag, -2 ) ) {
					$tag = substr( $tag, 0, -2 ) . ' alt="' . esc_attr( $alt ) . '" />';
				} else {
					$tag = substr( $tag, 0, -1 ) . ' alt="' . esc_attr( $alt ) . '">';
				}
				return $tag;
			},
			$content
		);

		if ( 0 === $index ) {
			throw AI_Exception::invalid_output( __( 'No images missing alt text were found to update.', 'localboost-ai' ) );
		}

		return (string) $new_content;
	}

	/**
	 * Build the per-field user prompt.
	 *
	 * @param string   $field    Field key.
	 * @param \WP_Post $post     Post being optimized.
	 * @param string   $current  Current field value (may be empty).
	 * @param array    $business Business context.
	 * @param array    $args     Caller args.
	 *
	 * @return string
	 */
	protected function build_field_prompt( string $field, \WP_Post $post, string $current, array $business, array $args ): string {
		$title   = get_the_title( $post );
		$city    = $business['city'];
		$keyword = isset( $args['keyword'] ) ? sanitize_text_field( (string) $args['keyword'] ) : '';

		switch ( $field ) {
			case 'title':
				$prompt = 'Current SEO title: "' . $current . '". Write an improved SEO title of max 60 characters';
				if ( '' !== $keyword ) {
					$prompt .= ', naturally including the keyword "' . $keyword . '"';
				}
				if ( '' !== $city ) {
					$prompt .= ' and mentioning "' . $city . '" where it fits naturally';
				}
				return $prompt . '.';

			case 'meta_description':
				$prompt = 'Current meta description: "' . $current . '". Write a compelling meta description of max 160 characters with a clear call to action';
				if ( '' !== $business['name'] ) {
					$prompt .= ' for "' . $business['name'] . '"';
				}
				if ( '' !== $city ) {
					$prompt .= ' in ' . $city;
				}
				return $prompt . '.';

			case 'h1':
				$prompt = 'Page title: "' . $title . '".';
				if ( '' !== $current ) {
					$prompt .= ' Current H1: "' . $current . '".';
				}
				$prompt .= ' Write a single compelling H1 heading';
				if ( '' !== $city ) {
					$prompt .= ', mentioning "' . $city . '" where natural';
				}
				return $prompt . '.';

			case 'introduction':
				$prompt = 'Current introduction: "' . $current . '". Rewrite a more engaging 2-3 sentence introduction';
				if ( '' !== $business['name'] ) {
					$prompt .= ' for "' . $business['name'] . '"';
				}
				if ( '' !== $city ) {
					$prompt .= ' in ' . $city;
				}
				return $prompt . '.';

			case 'faq':
				$prompt = 'Write 4 concise frequently asked questions with short answers for the page "' . $title . '"';
				if ( '' !== $business['name'] ) {
					$prompt .= ' of "' . $business['name'] . '"';
				}
				if ( '' !== $city ) {
					$prompt .= ' in ' . $city;
				}
				return $prompt . ' Format as HTML using <h3> for each question and <p> for each answer.';

			case 'cta':
				$prompt = 'Write a persuasive 1-2 sentence call to action encouraging visitors to contact';
				$prompt .= '' !== $business['name'] ? ' "' . $business['name'] . '"' : ' the business';
				if ( '' !== $business['phone'] ) {
					$prompt .= ' at ' . $business['phone'];
				}
				return $prompt . '.';

			case 'alt_texts':
				if ( '' === $current ) {
					return 'The page has no images missing alt text that I could detect. Reply with a single short sentence saying there is nothing to improve.';
				}
				return 'The following image file names are missing descriptive alt text (one per line):' . "\n" . $current . "\nWrite one concise descriptive alt text of max 125 characters per image, in the same order, one per line.";

			case 'internal_links':
				$excerpt = Text_Utils::substr( trim( wp_strip_all_tags( $post->post_content ) ), 0, 600 );
				$prompt  = 'Page title: "' . $title . '".';
				if ( '' !== $excerpt ) {
					$prompt .= ' Page excerpt: "' . $excerpt . '".';
				}
				return $prompt . ' Suggest 3-5 internal linking opportunities as a plain-text list, one per line, in the format "Anchor text -> suggested target page".';

			case 'h2_structure':
				return 'Page title: "' . $title . '". Suggest a clear H2 subheading structure for this page as a plain-text outline, one subheading per line.';

			default:
				return 'Improve the following text for SEO while keeping its meaning: "' . $current . '".';
		}
	}

	/**
	 * Read the current value of a field from the post.
	 *
	 * @param \WP_Post $post  Post.
	 * @param string   $field Field key.
	 *
	 * @return string
	 */
	protected function get_current_value( \WP_Post $post, string $field ): string {
		switch ( $field ) {
			case 'title':
				return get_the_title( $post );

			case 'meta_description':
				return $this->get_meta_description( (int) $post->ID );

			case 'h1':
				if ( preg_match( '/<h1[^>]*>(.*?)<\/h1>/is', $post->post_content, $m ) ) {
					return trim( wp_strip_all_tags( $m[1] ) );
				}
				return '';

			case 'introduction':
				if ( preg_match( '/<p[^>]*>(.*?)<\/p>/is', $post->post_content, $m ) ) {
					$text = trim( wp_strip_all_tags( $m[1] ) );
					if ( '' !== $text ) {
						return $text;
					}
				}
				return Text_Utils::substr( trim( wp_strip_all_tags( $post->post_content ) ), 0, 300 );

			case 'alt_texts':
				return $this->get_images_missing_alt( $post->post_content );

			default:
				return '';
		}
	}

	/**
	 * List image file names in the content that lack a usable alt attribute.
	 *
	 * @param string $content Post content.
	 *
	 * @return string One file name per line (max 5), empty when none found.
	 */
	protected function get_images_missing_alt( string $content ): string {
		if ( ! preg_match_all( '/<img\b[^>]*>/i', $content, $matches ) ) {
			return '';
		}

		$missing = [];
		foreach ( $matches[0] as $img ) {
			if ( preg_match( '/\salt\s*=\s*(?:"([^"]*)"|\'([^\']*)\')/i', $img, $alt ) ) {
				$value = isset( $alt[1] ) && '' !== $alt[1] ? $alt[1] : ( $alt[2] ?? '' );
				if ( '' !== trim( (string) $value ) ) {
					continue;
				}
			}

			if ( preg_match( '/\ssrc\s*=\s*["\']([^"\']+)["\']/i', $img, $src ) ) {
				$missing[] = wp_basename( $src[1] );
			}

			if ( count( $missing ) >= 5 ) {
				break;
			}
		}

		return implode( "\n", array_unique( $missing ) );
	}

	/**
	 * Business context for AI prompts, from the Local SEO settings.
	 *
	 * @return array{ name: string, type: string, city: string, country: string, phone: string }
	 */
	protected function get_business_context(): array {
		return [
			'name'    => (string) Options::get( 'lbai_business_name' ),
			'type'    => (string) Options::get( 'lbai_business_type' ),
			'city'    => (string) Options::get( 'lbai_city' ),
			'country' => (string) Options::get( 'lbai_country' ),
			'phone'   => (string) Options::get( 'lbai_phone' ),
		];
	}

	/**
	 * Resolve a language code against the whitelist, falling back to the
	 * configured content language and finally to English.
	 *
	 * @param string $code Requested code.
	 *
	 * @return string Valid code.
	 */
	protected function resolve_language( string $code ): string {
		$code = strtolower( trim( $code ) );
		if ( isset( self::LANGUAGES[ $code ] ) ) {
			return $code;
		}

		$option = Options::get( 'lbai_content_language' );
		$code   = is_string( $option ) ? strtolower( trim( $option ) ) : '';

		return isset( self::LANGUAGES[ $code ] ) ? $code : 'en';
	}

	/**
	 * Language name for AI prompts.
	 *
	 * @param string $code Language code.
	 *
	 * @return string
	 */
	protected function language_name( string $code ): string {
		return self::LANGUAGES[ $this->resolve_language( $code ) ];
	}

	/**
	 * Per-user rate limiting for AI calls.
	 *
	 * @param string $action Rate limit bucket.
	 *
	 * @throws AI_Exception When the limit is exceeded.
	 */
	protected function check_rate_limit( string $action ): void {
		$key     = 'lbai_' . $action . '_' . get_current_user_id();
		$allowed = Rate_Limiter::check( $key, 20, 60 );

		if ( false === $allowed ) {
			throw AI_Exception::rate_limited();
		}
	}
}
