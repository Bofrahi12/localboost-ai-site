<?php
/**
 * Change history for AI-applied optimizations.
 *
 * Every value written by AI_Optimizer::apply_suggestion() is recorded here
 * with its previous value, so an applied change can be reviewed and undone.
 * The table is created on demand via ensure_table() (dbDelta), keeping this
 * service self-contained.
 *
 * Capability checks are the caller's responsibility.
 *
 * @package LocalBoostAI\Services
 * @since   1.1.0
 */

namespace LocalBoostAI\Services;

use LocalBoostAI\Includes\Field_Registry;

defined( 'ABSPATH' ) || exit;

final class Change_History {

	const TABLE = 'lbai_changes';

	/**
	 * Whether ensure_table() already ran during this request.
	 *
	 * @var bool
	 */
	private static $ensured = false;

	/**
	 * Full table name with the WordPress prefix.
	 *
	 * @return string
	 */
	public static function table_name(): string {
		global $wpdb;
		return $wpdb->prefix . self::TABLE;
	}

	/**
	 * Create the history table when it does not exist yet.
	 *
	 * Safe to call on every write: dbDelta() is a no-op once the table
	 * exists, and a static flag keeps it to a single check per request.
	 *
	 * @return void
	 */
	public static function ensure_table(): void {
		if ( self::$ensured ) {
			return;
		}
		self::$ensured = true;

		global $wpdb;
		$table   = self::table_name();
		$charset = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			post_id bigint(20) unsigned NOT NULL,
			user_id bigint(20) unsigned NOT NULL,
			field varchar(50) NOT NULL,
			old_value longtext NOT NULL,
			new_value longtext NOT NULL,
			provider varchar(50) NOT NULL DEFAULT '',
			model varchar(100) NOT NULL DEFAULT '',
			status varchar(20) NOT NULL DEFAULT 'applied',
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY post_field (post_id, field),
			KEY created_at (created_at)
		) {$charset};";

		if ( ! function_exists( 'dbDelta' ) ) {
			$upgrade = ABSPATH . 'wp-admin/includes/upgrade.php';
			if ( is_file( $upgrade ) ) {
				require_once $upgrade;
			}
		}
		if ( function_exists( 'dbDelta' ) ) {
			dbDelta( $sql );
		}
	}

	/**
	 * Record a change attempt.
	 *
	 * @param array $data {
	 *     @type int    $post_id   Post the change applies to.
	 *     @type int    $user_id   User who applied the change.
	 *     @type string $field     Canonical optimizer field name.
	 *     @type string $old_value Value before the change.
	 *     @type string $new_value Value after the change.
	 *     @type string $provider  AI provider used (optional).
	 *     @type string $model     AI model used (optional).
	 *     @type string $status    applied|undone|failed.
	 * }
	 * @return int|false Insert id, or false when the field is unknown.
	 */
	public static function record( array $data ) {
		global $wpdb;

		$field = isset( $data['field'] ) ? Field_Registry::canonicalize( (string) $data['field'] ) : null;
		if ( null === $field ) {
			return false;
		}

		self::ensure_table();

		$inserted = $wpdb->insert(
			self::table_name(),
			array(
				'post_id'    => (int) ( $data['post_id'] ?? 0 ),
				'user_id'    => (int) ( $data['user_id'] ?? 0 ),
				'field'      => $field,
				'old_value'  => (string) ( $data['old_value'] ?? '' ),
				'new_value'  => (string) ( $data['new_value'] ?? '' ),
				'provider'   => sanitize_text_field( (string) ( $data['provider'] ?? '' ) ),
				'model'      => sanitize_text_field( (string) ( $data['model'] ?? '' ) ),
				'status'     => self::normalize_status( $data['status'] ?? 'applied' ),
				'created_at' => current_time( 'mysql' ),
			),
			array( '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		return $inserted ? (int) $wpdb->insert_id : false;
	}

	/**
	 * Undo the most recent applied change for a post + field.
	 *
	 * Restores the recorded previous value through AI_Optimizer's write
	 * path (with a revision safety net), marks the original entry as
	 * undone, and records a compensating entry so the history stays
	 * complete.
	 *
	 * Capability checks (edit_post) are the caller's responsibility.
	 *
	 * @param int    $post_id Post id.
	 * @param string $field   Canonical optimizer field name (aliases accepted).
	 * @return array|\WP_Error {
	 *     @type bool $restored    True on success.
	 *     @type int  $change_id   History id that was undone.
	 *     @type int  $revision_id Revision created before restoring (0 when unavailable).
	 * } WP_Error when there is nothing to undo or the restore fails.
	 */
	public static function undo_last( int $post_id, string $field ) {
		global $wpdb;

		$field = Field_Registry::canonicalize( $field );
		if ( null === $field ) {
			return new \WP_Error( 'lbai_invalid_field', __( 'Unknown optimization field.', 'localboost-ai' ) );
		}

		self::ensure_table();
		$table = self::table_name();

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE post_id = %d AND field = %s AND status = %s ORDER BY id DESC LIMIT 1",
				$post_id,
				$field,
				'applied'
			),
			ARRAY_A
		);

		if ( ! is_array( $row ) || ! isset( $row['id'] ) ) {
			return new \WP_Error( 'lbai_nothing_to_undo', __( 'There is no applied change to undo for this field.', 'localboost-ai' ) );
		}

		if ( ! class_exists( AI_Optimizer::class ) ) {
			return new \WP_Error( 'lbai_service_unavailable', __( 'The optimizer service is not available.', 'localboost-ai' ) );
		}

		$old_value = (string) $row['old_value'];

		try {
			$revision_id = function_exists( 'wp_save_post_revision' ) ? (int) wp_save_post_revision( $post_id ) : 0;
			$optimizer   = new AI_Optimizer();
			$optimizer->write_field_value( $post_id, $field, $old_value );
		} catch ( \Throwable $e ) {
			return new \WP_Error( 'lbai_undo_failed', __( 'Could not restore the previous value. Please try again.', 'localboost-ai' ) );
		}

		$wpdb->update(
			$table,
			array( 'status' => 'undone' ),
			array( 'id' => (int) $row['id'] ),
			array( '%s' ),
			array( '%d' )
		);

		self::record(
			array(
				'post_id'   => $post_id,
				'user_id'   => function_exists( 'get_current_user_id' ) ? get_current_user_id() : 0,
				'field'     => $field,
				'old_value' => (string) $row['new_value'],
				'new_value' => $old_value,
				'provider'  => (string) ( $row['provider'] ?? '' ),
				'model'     => (string) ( $row['model'] ?? '' ),
				'status'    => 'undone',
			)
		);

		return array(
			'restored'    => true,
			'change_id'   => (int) $row['id'],
			'revision_id' => $revision_id,
		);
	}

	/**
	 * Most recent history entries for a post (newest first).
	 *
	 * @param int $post_id Post id.
	 * @param int $limit   Maximum entries.
	 * @return array
	 */
	public static function recent( int $post_id, int $limit = 20 ): array {
		global $wpdb;

		self::ensure_table();
		$table = self::table_name();

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, post_id, user_id, field, provider, model, status, created_at FROM {$table} WHERE post_id = %d ORDER BY id DESC LIMIT %d",
				$post_id,
				max( 1, $limit )
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Normalize a status value to the allowed set.
	 *
	 * @param mixed $status Raw status.
	 * @return string
	 */
	private static function normalize_status( $status ): string {
		$status = (string) $status;
		return in_array( $status, array( 'applied', 'undone', 'failed' ), true ) ? $status : 'applied';
	}
}
