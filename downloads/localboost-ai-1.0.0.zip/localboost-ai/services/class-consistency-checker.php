<?php
/**
 * Local SEO consistency checker.
 *
 * Compares the canonical business details from the Local SEO settings
 * against what is actually published on the site's posts and pages, and
 * flags every difference with an exact correction.
 *
 * Performance: a single bounded query (up to 50 recent published posts and
 * pages); all analysis happens in memory.
 *
 * @package LocalBoostAI\Services
 */

namespace LocalBoostAI\Services;

use LocalBoostAI\Includes\Options;
use LocalBoostAI\Includes\Text_Utils;

defined( 'ABSPATH' ) || exit;

class Consistency_Checker {

	/**
	 * Maximum number of posts/pages scanned per check run.
	 *
	 * @var int
	 */
	const SAMPLE_SIZE = 50;

	/**
	 * Run the consistency check for all business fields.
	 *
	 * @return array List of per-field results: field, label, canonical,
	 *               status (consistent|inconsistent|not_found|not_configured),
	 *               found (distinct variants), message.
	 */
	public function check(): array {
		$contents = $this->sample_contents();

		return array(
			$this->check_name( $contents ),
			$this->check_phone( $contents ),
			$this->check_address( $contents ),
			$this->check_website( $contents ),
			$this->check_hours( $contents ),
		);
	}

	/**
	 * Fetch plain-text content of the most recent published posts/pages.
	 *
	 * @return array List of plain-text strings.
	 */
	private function sample_contents(): array {
		global $wpdb;

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_content FROM {$wpdb->posts}
				 WHERE post_status = 'publish' AND post_type IN ('post', 'page')
				 ORDER BY post_date DESC LIMIT %d",
				self::SAMPLE_SIZE
			),
			ARRAY_A
		);

		if ( ! is_array( $rows ) ) {
			return array();
		}

		$contents = array();
		foreach ( $rows as $row ) {
			$plain = trim( wp_strip_all_tags( (string) $row['post_content'] ) );
			if ( '' !== $plain ) {
				$contents[] = $plain;
			}
		}

		return $contents;
	}

	/**
	 * Check the business name.
	 *
	 * @param array $contents Plain-text page contents.
	 * @return array Field result.
	 */
	private function check_name( array $contents ): array {
		$name  = trim( (string) Options::get( 'lbai_business_name' ) );
		$label = __( 'Business name', 'localboost-ai' );

		if ( '' === $name ) {
			return $this->result(
				'business_name',
				$label,
				'',
				'not_configured',
				array(),
				__( 'Add your business name in the Local SEO settings so it can be checked across your site.', 'localboost-ai' )
			);
		}

		// Anchor on the longest distinctive word, then collect the phrases
		// around it that share at least half of the name's words.
		$name_words = preg_split( '/\s+/u', Text_Utils::strtolower( $name ) );
		$name_words = array_values( array_filter( (array) $name_words ) );
		$anchor     = '';
		foreach ( $name_words as $word ) {
			if ( Text_Utils::strlen( $word ) >= 4 && Text_Utils::strlen( $word ) > Text_Utils::strlen( $anchor ) ) {
				$anchor = $word;
			}
		}
		if ( '' === $anchor ) {
			$anchor = $name_words[0];
		}

		$span      = count( $name_words ) + 1;
		$pattern   = '/((?:[\p{L}\p{N}\'&.,-]+\s+){0,' . $span . '}' . preg_quote( $anchor, '/' ) . '(?:\s+[\p{L}\p{N}\'&.,-]+){0,' . $span . '})/iu';
		$variants  = array();
		$canonical = $this->normalize( $name );

		foreach ( $contents as $text ) {
			if ( ! preg_match_all( $pattern, $text, $matches ) ) {
				continue;
			}
			foreach ( $matches[1] as $candidate ) {
				$candidate_norm  = $this->normalize( $candidate );
				$candidate_words = preg_split( '/\s+/u', $candidate_norm );
				$shared          = count( array_intersect( $name_words, (array) $candidate_words ) );
				if ( $shared / max( 1, count( $name_words ) ) >= 0.5 ) {
					$variants[ $candidate_norm ] = trim( (string) $candidate );
				}
			}
		}

		if ( empty( $variants ) ) {
			return $this->result(
				'business_name',
				$label,
				$name,
				'not_found',
				array(),
				sprintf(
					/* translators: %s: business name. */
					__( 'Your business name "%s" was not found in the %d most recent posts/pages. Add it exactly as configured to your key pages (homepage, contact page, service pages).', 'localboost-ai' ),
					$name,
					self::SAMPLE_SIZE
				)
			);
		}

		if ( 1 === count( $variants ) && isset( $variants[ $canonical ] ) ) {
			return $this->result(
				'business_name',
				$label,
				$name,
				'consistent',
				array_values( $variants ),
				__( 'Your business name appears consistently across your site.', 'localboost-ai' )
			);
		}

		return $this->result(
			'business_name',
			$label,
			$name,
			'inconsistent',
			array_values( $variants ),
			sprintf(
				/* translators: 1: business name, 2: comma-separated list of variants found. */
				__( 'Your business name appears in different forms: %2$s. Standardize every page to exactly "%1$s".', 'localboost-ai' ),
				$name,
				implode( '; ', array_values( $variants ) )
			)
		);
	}

	/**
	 * Check the phone number.
	 *
	 * @param array $contents Plain-text page contents.
	 * @return array Field result.
	 */
	private function check_phone( array $contents ): array {
		$raw_phone = trim( (string) Options::get( 'lbai_phone' ) );
		$digits    = preg_replace( '/\D/', '', $raw_phone );
		$label     = __( 'Phone number', 'localboost-ai' );

		if ( strlen( (string) $digits ) < 7 ) {
			return $this->result(
				'phone',
				$label,
				$raw_phone,
				'not_configured',
				array(),
				__( 'Add your phone number in the Local SEO settings so it can be checked across your site.', 'localboost-ai' )
			);
		}

		$variants = array();
		foreach ( $contents as $text ) {
			if ( ! preg_match_all( '/\+?[\d][\d\s().-]{5,}[\d]/u', $text, $matches ) ) {
				continue;
			}
			foreach ( $matches[0] as $candidate ) {
				$candidate_digits = preg_replace( '/\D/', '', $candidate );
				$len              = strlen( (string) $candidate_digits );
				if ( $len >= 7 && $len <= 15 ) {
					$variants[ $candidate_digits ] = trim( $candidate );
				}
			}
		}

		if ( empty( $variants ) ) {
			return $this->result(
				'phone',
				$label,
				$raw_phone,
				'not_found',
				array(),
				sprintf(
					/* translators: %s: phone number. */
					__( 'No phone number was found in the %d most recent posts/pages. Add %s to your key pages so customers can reach you.', 'localboost-ai' ),
					self::SAMPLE_SIZE,
					$raw_phone
				)
			);
		}

		$canonical_present = isset( $variants[ $digits ] );
		if ( 1 === count( $variants ) && $canonical_present ) {
			return $this->result(
				'phone',
				$label,
				$raw_phone,
				'consistent',
				array_values( $variants ),
				__( 'Your phone number appears consistently across your site.', 'localboost-ai' )
			);
		}

		return $this->result(
			'phone',
			$label,
			$raw_phone,
			'inconsistent',
			array_values( $variants ),
			sprintf(
				/* translators: 1: phone number, 2: comma-separated list of variants found. */
				__( 'Different phone numbers were found: %2$s. Standardize every page to exactly "%1$s".', 'localboost-ai' ),
				$raw_phone,
				implode( '; ', array_values( $variants ) )
			)
		);
	}

	/**
	 * Check the address.
	 *
	 * @param array $contents Plain-text page contents.
	 * @return array Field result.
	 */
	private function check_address( array $contents ): array {
		$street = trim( (string) Options::get( 'lbai_street' ) );
		$city   = trim( (string) Options::get( 'lbai_city' ) );
		$postal = trim( (string) Options::get( 'lbai_postal' ) );
		$label  = __( 'Address', 'localboost-ai' );

		if ( '' === $street && '' === $city && '' === $postal ) {
			return $this->result(
				'address',
				$label,
				'',
				'not_configured',
				array(),
				__( 'Add your street, city and postal code in the Local SEO settings so your address can be checked across your site.', 'localboost-ai' )
			);
		}

		$canonical = implode( ', ', array_filter( array( $street, trim( $postal . ' ' . $city ) ) ) );
		$anchor    = '' !== $street ? $street : $city;

		$variants = array();
		foreach ( $contents as $text ) {
			$pattern = '/.{0,80}' . preg_quote( $anchor, '/' ) . '.{0,80}/iu';
			if ( ! preg_match_all( $pattern, $text, $matches ) ) {
				continue;
			}
			foreach ( $matches[0] as $candidate ) {
				$normalized = $this->normalize( $candidate );
				$variants[ $normalized ] = trim( (string) $candidate );
			}
		}

		if ( empty( $variants ) ) {
			return $this->result(
				'address',
				$label,
				$canonical,
				'not_found',
				array(),
				sprintf(
					/* translators: %s: address. */
					__( 'Your address was not found in the %d most recent posts/pages. Add "%s" to your contact page and footer.', 'localboost-ai' ),
					self::SAMPLE_SIZE,
					$canonical
				)
			);
		}

		if ( 1 === count( $variants ) ) {
			return $this->result(
				'address',
				$label,
				$canonical,
				'consistent',
				array_values( $variants ),
				__( 'Your address appears consistently across your site.', 'localboost-ai' )
			);
		}

		return $this->result(
			'address',
			$label,
			$canonical,
			'inconsistent',
			array_values( $variants ),
			sprintf(
				/* translators: 1: address, 2: semicolon-separated list of variants found. */
				__( 'Your address appears in different forms: %2$s. Standardize every page to exactly "%1$s".', 'localboost-ai' ),
				$canonical,
				implode( '; ', array_values( $variants ) )
			)
		);
	}

	/**
	 * Check the website URL.
	 *
	 * @param array $contents Plain-text page contents.
	 * @return array Field result.
	 */
	private function check_website( array $contents ): array {
		$configured = trim( (string) Options::get( 'lbai_website' ) );
		$label      = __( 'Website', 'localboost-ai' );

		if ( '' === $configured ) {
			return $this->result(
				'website',
				$label,
				home_url(),
				'not_configured',
				array(),
				__( 'Add your website URL in the Local SEO settings so it can be checked across your site.', 'localboost-ai' )
			);
		}

		$canonical_host = $this->normalize_host( $configured );
		$variants       = array();

		foreach ( $contents as $text ) {
			if ( ! preg_match_all( '#https?://[^\s"\'<>]+#i', $text, $matches ) ) {
				continue;
			}
			foreach ( $matches[0] as $url ) {
				$host = $this->normalize_host( $url );
				if ( '' !== $host ) {
					$variants[ $host ] = $host;
				}
			}
		}

		if ( empty( $variants ) ) {
			return $this->result(
				'website',
				$label,
				$configured,
				'not_found',
				array(),
				__( 'No website URLs were found in your page content. This is unusual; make sure your pages link to your own domain.', 'localboost-ai' )
			);
		}

		if ( 1 === count( $variants ) && isset( $variants[ $canonical_host ] ) ) {
			return $this->result(
				'website',
				$label,
				$configured,
				'consistent',
				array_values( $variants ),
				__( 'Your website URL appears consistently across your site.', 'localboost-ai' )
			);
		}

		return $this->result(
			'website',
			$label,
			$configured,
			'inconsistent',
			array_values( $variants ),
			sprintf(
				/* translators: 1: website URL, 2: comma-separated list of domains found. */
				__( 'Different website domains were found: %2$s. Use exactly "%1$s" everywhere.', 'localboost-ai' ),
				$configured,
				implode( ', ', array_values( $variants ) )
			)
		);
	}

	/**
	 * Check the opening hours.
	 *
	 * Note: hours are free-form text on most sites, so variant detection is
	 * not reliable. This check honestly reports presence of the configured
	 * hours summary instead of guessing variants.
	 *
	 * @param array $contents Plain-text page contents.
	 * @return array Field result.
	 */
	private function check_hours( array $contents ): array {
		$summary = trim( (string) Options::get( 'lbai_hours_summary' ) );
		$label   = __( 'Opening hours', 'localboost-ai' );

		if ( '' === $summary ) {
			return $this->result(
				'hours',
				$label,
				'',
				'not_configured',
				array(),
				__( 'Add your opening hours in the Local SEO settings so they can be checked across your site.', 'localboost-ai' )
			);
		}

		$needle = $this->normalize( $summary );
		$found  = false;
		foreach ( $contents as $text ) {
			if ( false !== Text_Utils::strpos( $this->normalize( $text ), $needle ) ) {
				$found = true;
				break;
			}
		}

		if ( ! $found ) {
			return $this->result(
				'hours',
				$label,
				$summary,
				'not_found',
				array(),
				sprintf(
					/* translators: %s: opening hours summary. */
					__( 'Your opening hours ("%s") were not found in the %d most recent posts/pages. Add them to your contact page and footer. Note: automatic variant detection is not reliable for free-form hours, so this check only verifies the exact configured text.', 'localboost-ai' ),
					$summary,
					self::SAMPLE_SIZE
				)
			);
		}

		return $this->result(
			'hours',
			$label,
			$summary,
			'consistent',
			array( $summary ),
			__( 'Your configured opening hours were found on your site.', 'localboost-ai' )
		);
	}

	/**
	 * Build a normalized field result array.
	 *
	 * @param string $field     Field key.
	 * @param string $label     Translated field label.
	 * @param string $canonical Canonical configured value.
	 * @param string $status    consistent|inconsistent|not_found|not_configured.
	 * @param array  $found     Distinct variants found.
	 * @param string $message   Translated explanation and correction.
	 * @return array
	 */
	private function result( string $field, string $label, string $canonical, string $status, array $found, string $message ): array {
		return array(
			'field'     => $field,
			'label'     => $label,
			'canonical' => $canonical,
			'status'    => $status,
			'found'     => array_values( $found ),
			'message'   => $message,
		);
	}

	/**
	 * Normalize a string for comparison: lowercase, collapsed whitespace.
	 *
	 * @param string $value Input.
	 * @return string
	 */
	private function normalize( string $value ): string {
		$value = Text_Utils::strtolower( trim( $value ) );
		$value = preg_replace( '/\s+/u', ' ', $value );
		return trim( (string) $value, " \t\n\r\0\x0B.,;" );
	}

	/**
	 * Normalize a URL host for comparison (lowercase, no leading www.).
	 *
	 * @param string $url URL or host.
	 * @return string
	 */
	private function normalize_host( string $url ): string {
		$host = parse_url( trim( $url ), PHP_URL_HOST );
		if ( ! is_string( $host ) || '' === $host ) {
			return '';
		}
		$host = Text_Utils::strtolower( $host );
		if ( 0 === strpos( $host, 'www.' ) ) {
			$host = substr( $host, 4 );
		}
		return $host;
	}
}
