<?php
/**
 * AI content generator service.
 *
 * Generates local-business content (service pages, FAQs, outlines, meta
 * texts, ...) via the configured AI provider. Generated content always
 * carries an anti-doorway warning for page types that are commonly abused,
 * and is sanitized before it is returned.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

namespace LocalBoostAI\Services;

use LocalBoostAI\Includes\AI_Exception;
use LocalBoostAI\Includes\Field_Registry;
use LocalBoostAI\Includes\Options;
use LocalBoostAI\Includes\Rate_Limiter;
use LocalBoostAI\Includes\Text_Utils;
use LocalBoostAI\Includes\Usage_Tracker;
use LocalBoostAI\Providers\Provider_Factory;

defined( 'ABSPATH' ) || exit;

/**
 * Class Content_Generator
 */
class Content_Generator {

	/**
	 * Supported content types.
	 */
	const TYPES = [
		'service_page',
		'location_page',
		'faq',
		'about',
		'service_description',
		'landing_outline',
		'blog_ideas',
		'blog_outline',
		'meta_description',
		'seo_title',
	];

	/**
	 * Supported content language codes => language names (for AI prompts).
	 */
	const LANGUAGES = [
		'en' => 'English',
		'fr' => 'French',
		'de' => 'German',
		'es' => 'Spanish',
		'it' => 'Italian',
		'nl' => 'Dutch',
		'pt' => 'Portuguese',
	];

	/**
	 * Allowed text transform actions.
	 */
	const TRANSFORMS = [
		'shorten',
		'expand',
		'readability',
		'tone',
		'translate',
	];

	/**
	 * Generate content of the given type.
	 *
	 * @param string $type   Content type from self::TYPES.
	 * @param array  $params Optional. {
	 *     @type string $service   Service name.
	 *     @type string $city      City override (defaults to the business city).
	 *     @type string $region    Region/state.
	 *     @type string $country   Country override.
	 *     @type string $audience  Target audience description.
	 *     @type string $tone      Desired tone, e.g. "friendly".
	 *     @type string $keywords  Keywords to weave in naturally.
	 *     @type string $topic     Topic (blog outline / ideas).
	 *     @type string $language  Language code override.
	 * }
	 *
	 * @return array{
	 *     type: string,
	 *     title: string,
	 *     content: string,
	 *     meta_description: string,
	 *     warnings: string[]
	 * }
	 *
	 * @throws AI_Exception
	 */
	public function generate( string $type, array $params ): array {
		if ( ! in_array( $type, self::TYPES, true ) ) {
			throw AI_Exception::invalid_output( __( 'Unknown content type.', 'localboost-ai' ) );
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			throw new AI_Exception( 'permission_denied', __( 'You are not allowed to generate content.', 'localboost-ai' ) );
		}

		if ( ! Usage_Tracker::can_use( 'content' ) ) {
			throw new AI_Exception( 'limit_reached', Usage_Tracker::usage_message( 'content' ) );
		}

		$this->check_rate_limit( 'lbai_content' );

		$business = $this->get_business_context();
		$language = $this->language_name( isset( $params['language'] ) ? (string) $params['language'] : '' );

		$c = [
			'service'  => isset( $params['service'] ) ? sanitize_text_field( (string) $params['service'] ) : '',
			'city'     => isset( $params['city'] ) ? sanitize_text_field( (string) $params['city'] ) : $business['city'],
			'region'   => isset( $params['region'] ) ? sanitize_text_field( (string) $params['region'] ) : $business['region'],
			'country'  => isset( $params['country'] ) ? sanitize_text_field( (string) $params['country'] ) : $business['country'],
			'audience' => isset( $params['audience'] ) ? sanitize_text_field( (string) $params['audience'] ) : '',
			'tone'     => isset( $params['tone'] ) ? sanitize_text_field( (string) $params['tone'] ) : '',
			'keywords' => isset( $params['keywords'] ) ? sanitize_text_field( (string) $params['keywords'] ) : '',
			'topic'    => isset( $params['topic'] ) ? sanitize_text_field( (string) $params['topic'] ) : '',
		];

		$system = sprintf(
			'You are an expert local SEO copywriter. Write genuinely useful, unique content for this specific business and location. Never produce thin, duplicated or doorway-style pages. Business: %s. Language: %s. Format the main content as clean HTML using only h2, h3, p, ul, ol, li, strong and em tags.',
			$this->describe_business( $business ),
			$language
		);

		$provider = Provider_Factory::get_configured_provider();
		$result   = $provider->generate(
			[
				[
					'role'    => 'system',
					'content' => $system,
				],
				[
					'role'    => 'user',
					'content' => $this->build_type_prompt( $type, $c, $business ),
				],
			]
		);

		Usage_Tracker::record( 'content' );

		$content = wp_kses_post( $result['text'] );
		$title   = $this->build_title( $type, $c, $business );
		$meta    = '';

		if ( 'seo_title' === $type ) {
			$plain   = trim( wp_strip_all_tags( $content ) );
			$title   = Text_Utils::substr( $plain, 0, 60 );
			$content = $plain;
		} elseif ( 'meta_description' === $type ) {
			$plain   = trim( wp_strip_all_tags( $content ) );
			$meta    = Text_Utils::substr( $plain, 0, 160 );
			$content = $plain;
		} else {
			$meta = Text_Utils::substr( wp_trim_words( wp_strip_all_tags( $content ), 30, '' ), 0, 160 );
		}

		$warnings = [
			__( 'Always review AI-generated content before publishing.', 'localboost-ai' ),
		];

		if ( in_array( $type, [ 'location_page', 'service_page' ], true ) ) {
			$warnings[] = __( 'Avoid publishing many near-duplicate location pages — each page must offer unique, genuinely useful information.', 'localboost-ai' );
		}

		return [
			'type'             => $type,
			'title'            => $title,
			'content'          => $content,
			'meta_description' => $meta,
			'warnings'         => $warnings,
		];
	}

	/**
	 * Transform existing text: shorten, expand, improve readability, change
	 * tone, or translate it.
	 *
	 * @param string $action Transform action (canonical; legacy 'improve' is normalized to 'readability').
	 * @param string $text   Source text.
	 * @param array  $args   Optional. { @type string $tone            Target tone for the 'tone' action.
	 *                                  @type string $target_language Language code for the 'translate' action. }
	 *
	 * @return array{ result: string }
	 *
	 * @throws AI_Exception
	 */
	public function transform( string $action, string $text, array $args = [] ): array {
		// Normalize legacy action names ('improve' -> 'readability').
		$action = Field_Registry::canonicalize_action( $action );
		if ( null === $action || ! in_array( $action, self::TRANSFORMS, true ) ) {
			throw AI_Exception::invalid_output( __( 'Unknown transform action.', 'localboost-ai' ) );
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			throw new AI_Exception( 'permission_denied', __( 'You are not allowed to transform content.', 'localboost-ai' ) );
		}

		$text = trim( $text );
		if ( '' === $text ) {
			throw AI_Exception::invalid_output( __( 'There is no text to transform.', 'localboost-ai' ) );
		}

		if ( ! Usage_Tracker::can_use( 'ai_generation' ) ) {
			throw new AI_Exception( 'limit_reached', Usage_Tracker::usage_message( 'ai_generation' ) );
		}

		$this->check_rate_limit( 'lbai_transform' );

		$prompt = $this->build_transform_prompt( $action, $args );

		$provider = Provider_Factory::get_configured_provider();
		$result   = $provider->generate(
			[
				[
					'role'    => 'system',
					'content' => 'You are a professional copy editor. Respond with ONLY the transformed text, no explanations.',
				],
				[
					'role'    => 'user',
					'content' => $prompt . "\n\nText:\n" . $text,
				],
			]
		);

		Usage_Tracker::record( 'ai_generation' );

		return [
			'result' => $result['text'],
		];
	}

	/**
	 * Build the user prompt for a content type.
	 *
	 * @param string $type     Content type.
	 * @param array  $c        Sanitized params.
	 * @param array  $business Business context.
	 *
	 * @return string
	 */
	protected function build_type_prompt( string $type, array $c, array $business ): string {
		$service  = '' !== $c['service'] ? $c['service'] : __( 'its services', 'localboost-ai' );
		$city     = '' !== $c['city'] ? $c['city'] : __( 'its area', 'localboost-ai' );
		$audience = '' !== $c['audience'] ? $c['audience'] : __( 'local customers', 'localboost-ai' );
		$tone     = '' !== $c['tone'] ? $c['tone'] : __( 'professional and friendly', 'localboost-ai' );
		$name     = '' !== $business['name'] ? $business['name'] : __( 'the business', 'localboost-ai' );

		$keywords = '';
		if ( '' !== $c['keywords'] ) {
			$keywords = ' Weave in these keywords naturally: ' . $c['keywords'] . '.';
		}

		switch ( $type ) {
			case 'service_page':
				return 'Write a complete, persuasive service page for "' . $service . '" in ' . $city . '. Target audience: ' . $audience . '. Tone: ' . $tone . '.' . $keywords . ' Structure: compelling headline, introduction, key benefits, what is included, why choose ' . $name . ' locally, 3 FAQs, and a strong call to action' . ( '' !== $business['phone'] ? ' mentioning phone ' . $business['phone'] : '' ) . '.';

			case 'location_page':
				return 'Write a location page for "' . $service . '" in ' . $city . ( '' !== $c['region'] ? ', ' . $c['region'] : '' ) . '. This page must be genuinely unique to this location: reference local neighborhoods, landmarks and practical local details relevant to ' . $service . ', and avoid generic filler that could apply to any city. Tone: ' . $tone . '.' . $keywords . ' Include: headline, introduction, locally relevant service details, 3 FAQs and a call to action.';

			case 'faq':
				return 'Write 6 frequently asked questions with concise, helpful answers about "' . $service . '" in ' . $city . '. Tone: ' . $tone . '.' . $keywords;

			case 'about':
				return 'Write an "About us" section for ' . $name . ', a ' . ( '' !== $business['type'] ? $business['type'] : __( 'local business', 'localboost-ai' ) ) . ' serving ' . $city . '. Tone: ' . $tone . '. Include: story, values, local roots, and a short call to action.';

			case 'service_description':
				return 'Write a concise 120-150 word service description for "' . $service . '" by ' . $name . ' in ' . $city . '. Tone: ' . $tone . '.' . $keywords;

			case 'landing_outline':
				return 'Create a landing page outline for "' . $service . '" in ' . $city . ' targeting ' . $audience . '. Provide: 3 headline options, section headings with a 1-2 sentence note for each, and call-to-action placement notes. Keep it an outline, not full copy.';

			case 'blog_ideas':
				$topic = '' !== $c['topic'] ? ' around "' . $c['topic'] . '"' : '';
				return 'Suggest 10 blog article ideas (titles only, one per line) that would attract ' . $audience . ' searching for "' . $service . '" in ' . $city . $topic . '. Make each idea specific and useful, not generic.';

			case 'blog_outline':
				$topic = '' !== $c['topic'] ? $c['topic'] : $service . ' in ' . $city;
				return 'Create a detailed blog article outline for "' . $topic . '" targeting ' . $audience . '. Provide: a working title, introduction hook notes, h2/h3 section headings with 1-2 sentence notes each, and a conclusion with call to action. Keep it an outline, not full copy.';

			case 'meta_description':
				return 'Write a single compelling meta description of max 160 characters for "' . $service . '" in ' . $city . ' by ' . $name . ', with a clear call to action.';

			case 'seo_title':
				return 'Write a single SEO title of max 60 characters for "' . $service . '" in ' . $city . ' by ' . $name . '.';

			default:
				return 'Write useful local business content about "' . $service . '" in ' . $city . '.';
		}
	}

	/**
	 * Build the user prompt for a transform action.
	 *
	 * @param string $action Transform action.
	 * @param array  $args   Caller args.
	 *
	 * @return string
	 *
	 * @throws AI_Exception When a required argument is missing.
	 */
	protected function build_transform_prompt( string $action, array $args ): string {
		switch ( $action ) {
			case 'shorten':
				return 'Rewrite the following text more concisely, keeping all key information.';

			case 'expand':
				return 'Expand the following text with useful, specific detail while keeping it focused.';

			case 'readability':
				return 'Rewrite the following text for clarity and readability: short sentences, simple words, clear structure.';

			case 'tone':
				$tone = isset( $args['tone'] ) ? sanitize_text_field( (string) $args['tone'] ) : '';
				if ( '' === $tone ) {
					throw AI_Exception::invalid_output( __( 'Please choose a target tone.', 'localboost-ai' ) );
				}
				return 'Rewrite the following text in a ' . $tone . ' tone.';

			case 'translate':
				$target = isset( $args['target_language'] ) ? (string) $args['target_language'] : '';
				return 'Translate the following text into ' . $this->language_name( $target ) . '.';

			default:
				throw AI_Exception::invalid_output( __( 'Unknown transform action.', 'localboost-ai' ) );
		}
	}

	/**
	 * Deterministic title for the generated content.
	 *
	 * @param string $type     Content type.
	 * @param array  $c        Sanitized params.
	 * @param array  $business Business context.
	 *
	 * @return string
	 */
	protected function build_title( string $type, array $c, array $business ): string {
		$service = '' !== $c['service'] ? $c['service'] : ( '' !== $c['topic'] ? $c['topic'] : '' );
		$city    = $c['city'];
		$name    = $business['name'];

		switch ( $type ) {
			case 'blog_ideas':
				/* translators: %s: service name */
				return sprintf( __( 'Blog ideas: %s', 'localboost-ai' ), $service );

			case 'blog_outline':
				/* translators: %s: topic */
				return sprintf( __( 'Outline: %s', 'localboost-ai' ), $service );

			case 'meta_description':
				/* translators: 1: service, 2: city */
				return sprintf( __( 'Meta description: %1$s in %2$s', 'localboost-ai' ), $service, $city );

			case 'seo_title':
				return '';

			default:
				$title = trim( $service . ( '' !== $city ? ' in ' . $city : '' ) );
				if ( '' !== $name ) {
					$title .= ' | ' . $name;
				}
				return $title;
		}
	}

	/**
	 * One-line business description for AI prompts.
	 *
	 * @param array $business Business context.
	 *
	 * @return string
	 */
	protected function describe_business( array $business ): string {
		$parts = array_filter(
			[
				$business['name'],
				$business['type'],
				$business['city'],
				$business['country'],
			]
		);

		return $parts ? implode( ', ', $parts ) : 'a local business';
	}

	/**
	 * Business context for AI prompts, from the Local SEO settings.
	 *
	 * @return array{ name: string, type: string, city: string, region: string, country: string, phone: string }
	 */
	protected function get_business_context(): array {
		return [
			'name'    => (string) Options::get( 'lbai_business_name' ),
			'type'    => (string) Options::get( 'lbai_business_type' ),
			'city'    => (string) Options::get( 'lbai_city' ),
			'region'  => (string) Options::get( 'lbai_region' ),
			'country' => (string) Options::get( 'lbai_country' ),
			'phone'   => (string) Options::get( 'lbai_phone' ),
		];
	}

	/**
	 * Resolve a language code against the whitelist, falling back to the
	 * configured content language and finally to English.
	 *
	 * @param string $code Requested code.
	 *
	 * @return string Valid code.
	 */
	protected function resolve_language( string $code ): string {
		$code = strtolower( trim( $code ) );
		if ( isset( self::LANGUAGES[ $code ] ) ) {
			return $code;
		}

		$option = Options::get( 'lbai_content_language' );
		$code   = is_string( $option ) ? strtolower( trim( $option ) ) : '';

		return isset( self::LANGUAGES[ $code ] ) ? $code : 'en';
	}

	/**
	 * Language name for AI prompts.
	 *
	 * @param string $code Language code.
	 *
	 * @return string
	 */
	protected function language_name( string $code ): string {
		return self::LANGUAGES[ $this->resolve_language( $code ) ];
	}

	/**
	 * Per-user rate limiting for AI calls.
	 *
	 * @param string $action Rate limit bucket.
	 *
	 * @throws AI_Exception When the limit is exceeded.
	 */
	protected function check_rate_limit( string $action ): void {
		$key     = 'lbai_' . $action . '_' . get_current_user_id();
		$allowed = Rate_Limiter::check( $key, 20, 60 );

		if ( false === $allowed ) {
			throw AI_Exception::rate_limited();
		}
	}
}
