<?php
/**
 * Local keyword assistant service.
 *
 * Generates grouped local keyword IDEAS via the configured AI provider. The
 * results are explicitly labelled as AI-generated ideas: this service never
 * invents search volumes, competition scores or any other metrics.
 *
 * @package LocalBoostAI
 * @since   1.0.0
 */

namespace LocalBoostAI\Services;

use LocalBoostAI\Includes\AI_Exception;
use LocalBoostAI\Includes\Options;
use LocalBoostAI\Includes\Rate_Limiter;
use LocalBoostAI\Includes\Text_Utils;
use LocalBoostAI\Includes\Usage_Tracker;
use LocalBoostAI\Providers\Provider_Factory;

defined( 'ABSPATH' ) || exit;

/**
 * Class Keyword_Assistant
 */
class Keyword_Assistant {

	/**
	 * Keyword groups returned by suggest().
	 */
	const GROUPS = [
		'primary',
		'secondary',
		'long_tail',
		'questions',
		'local_intent',
	];

	/**
	 * Supported content language codes => language names (for AI prompts).
	 */
	const LANGUAGES = [
		'en' => 'English',
		'fr' => 'French',
		'de' => 'German',
		'es' => 'Spanish',
		'it' => 'Italian',
		'nl' => 'Dutch',
		'pt' => 'Portuguese',
	];

	/**
	 * Suggest local keyword ideas for a business/service/location.
	 *
	 * @param array $params {
	 *     @type string $business_type Required. Business type, e.g. "Dentist".
	 *     @type string $service       Required. Service, e.g. "Teeth whitening".
	 *     @type string $city          Required. City.
	 *     @type string $region        Optional. Region/state.
	 *     @type string $country       Optional. Country.
	 *     @type string $language      Optional. Language code override.
	 * }
	 *
	 * @return array{
	 *     primary: array<array{ keyword: string }>,
	 *     secondary: array<array{ keyword: string }>,
	 *     long_tail: array<array{ keyword: string }>,
	 *     questions: array<array{ keyword: string }>,
	 *     local_intent: array<array{ keyword: string }>,
	 *     disclaimer: string
	 * }
	 *
	 * @throws AI_Exception
	 */
	public function suggest( array $params ): array {
		$business_type = isset( $params['business_type'] ) ? sanitize_text_field( (string) $params['business_type'] ) : '';
		$service       = isset( $params['service'] ) ? sanitize_text_field( (string) $params['service'] ) : '';
		$city          = isset( $params['city'] ) ? sanitize_text_field( (string) $params['city'] ) : '';
		$region        = isset( $params['region'] ) ? sanitize_text_field( (string) $params['region'] ) : '';
		$country       = isset( $params['country'] ) ? sanitize_text_field( (string) $params['country'] ) : '';

		$missing = [];
		if ( '' === $business_type ) {
			$missing[] = __( 'business type', 'localboost-ai' );
		}
		if ( '' === $service ) {
			$missing[] = __( 'service', 'localboost-ai' );
		}
		if ( '' === $city ) {
			$missing[] = __( 'city', 'localboost-ai' );
		}

		if ( ! empty( $missing ) ) {
			throw AI_Exception::invalid_output(
				sprintf(
					/* translators: %s: comma-separated list of missing fields */
					__( 'Please provide: %s.', 'localboost-ai' ),
					implode( ', ', $missing )
				)
			);
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			throw new AI_Exception( 'permission_denied', __( 'You are not allowed to use the keyword assistant.', 'localboost-ai' ) );
		}

		if ( ! Usage_Tracker::can_use( 'ai_generation' ) ) {
			throw new AI_Exception( 'limit_reached', Usage_Tracker::usage_message( 'ai_generation' ) );
		}

		$this->check_rate_limit( 'lbai_keywords' );

		$language = $this->language_name( isset( $params['language'] ) ? (string) $params['language'] : '' );

		$location = $city;
		if ( '' !== $region ) {
			$location .= ', ' . $region;
		}
		if ( '' !== $country ) {
			$location .= ', ' . $country;
		}

		$prompt = 'You are a local SEO keyword researcher. Suggest keyword ideas for:' . "\n"
			. 'Business type: ' . $business_type . "\n"
			. 'Service: ' . $service . "\n"
			. 'Location: ' . $location . "\n"
			. 'Language: ' . $language . "\n\n"
			. 'Group your answer into: primary keywords (5), secondary keywords (8), long-tail keywords (8), question keywords (5), local intent keywords (5).' . "\n"
			. 'Respond in JSON format exactly like this, with no other text:' . "\n"
			. '{"primary": ["..."], "secondary": ["..."], "long_tail": ["..."], "questions": ["..."], "local_intent": ["..."]}' . "\n"
			. 'Do NOT include search volumes, competition scores or any metrics — keywords only.';

		$provider = Provider_Factory::get_configured_provider();
		$result   = $provider->generate(
			[
				[
					'role'    => 'system',
					'content' => 'You are a local SEO keyword researcher. Respond with ONLY the requested JSON, no explanations.',
				],
				[
					'role'    => 'user',
					'content' => $prompt,
				],
			]
		);

		$groups = $this->parse_keywords( $result['text'] );

		$has_any = false;
		foreach ( $groups as $items ) {
			if ( ! empty( $items ) ) {
				$has_any = true;
				break;
			}
		}

		if ( ! $has_any ) {
			throw AI_Exception::empty_response();
		}

		Usage_Tracker::record( 'ai_generation' );

		$groups['disclaimer'] = __( 'AI-generated ideas. No search volume data — connect a keyword data provider for real volumes.', 'localboost-ai' );

		return $groups;
	}

	/**
	 * Parse grouped keywords from the AI response.
	 *
	 * Tries JSON first, then falls back to a line-based parser that detects
	 * section headers. Never invents metrics.
	 *
	 * @param string $text Raw AI response.
	 *
	 * @return array<string, array<array{ keyword: string }>>
	 */
	protected function parse_keywords( string $text ): array {
		$groups = [];
		foreach ( self::GROUPS as $group ) {
			$groups[ $group ] = [];
		}

		if ( preg_match( '/\{.*\}/s', $text, $m ) ) {
			$decoded = json_decode( $m[0], true );
			if ( is_array( $decoded ) ) {
				foreach ( self::GROUPS as $group ) {
					if ( isset( $decoded[ $group ] ) && is_array( $decoded[ $group ] ) ) {
						foreach ( $decoded[ $group ] as $keyword ) {
							$keyword = trim( wp_strip_all_tags( (string) $keyword ) );
							if ( '' !== $keyword && Text_Utils::strlen( $keyword ) <= 120 ) {
								$groups[ $group ][] = [ 'keyword' => $keyword ];
							}

							if ( count( $groups[ $group ] ) >= 15 ) {
								break;
							}
						}
					}
				}

				return $groups;
			}
		}

		// Fallback: line-based parsing with section headers.
		$headers = [
			'primary'     => 'primary',
			'secondary'   => 'secondary',
			'long-tail'   => 'long_tail',
			'long tail'   => 'long_tail',
			'question'    => 'questions',
			'local intent' => 'local_intent',
			'local-intent' => 'local_intent',
		];

		$current = 'primary';

		foreach ( preg_split( '/\r\n|\r|\n/', $text ) as $line ) {
			$line = trim( (string) $line );
			if ( '' === $line ) {
				continue;
			}

			// Section header: short line containing both a group word and the
			// word "keyword" (avoids misreading keywords like
			// "questions to ask a plumber" as headers).
			$lower = strtolower( $line );
			if ( Text_Utils::strlen( $line ) < 60 && false !== strpos( $lower, 'keyword' ) ) {
				$matched = false;
				foreach ( $headers as $needle => $group ) {
					if ( false !== strpos( $lower, $needle ) ) {
						$current = $group;
						$matched = true;
						break;
					}
				}
				if ( $matched ) {
					continue;
				}
			}

			$keyword = trim( (string) preg_replace( '/^[\s\-\*\d\.\)\]]+/', '', $line ) );
			$keyword = trim( wp_strip_all_tags( $keyword ), " \t\n\r\0\x0B\"'" );

			if ( '' === $keyword || Text_Utils::strlen( $keyword ) > 120 ) {
				continue;
			}

			if ( count( $groups[ $current ] ) < 15 ) {
				$groups[ $current ][] = [ 'keyword' => $keyword ];
			}
		}

		return $groups;
	}

	/**
	 * Resolve a language code against the whitelist, falling back to the
	 * configured content language and finally to English.
	 *
	 * @param string $code Requested code.
	 *
	 * @return string Valid code.
	 */
	protected function resolve_language( string $code ): string {
		$code = strtolower( trim( $code ) );
		if ( isset( self::LANGUAGES[ $code ] ) ) {
			return $code;
		}

		$option = Options::get( 'lbai_content_language' );
		$code   = is_string( $option ) ? strtolower( trim( $option ) ) : '';

		return isset( self::LANGUAGES[ $code ] ) ? $code : 'en';
	}

	/**
	 * Language name for AI prompts.
	 *
	 * @param string $code Language code.
	 *
	 * @return string
	 */
	protected function language_name( string $code ): string {
		return self::LANGUAGES[ $this->resolve_language( $code ) ];
	}

	/**
	 * Per-user rate limiting for AI calls.
	 *
	 * @param string $action Rate limit bucket.
	 *
	 * @throws AI_Exception When the limit is exceeded.
	 */
	protected function check_rate_limit( string $action ): void {
		$key     = 'lbai_' . $action . '_' . get_current_user_id();
		$allowed = Rate_Limiter::check( $key, 20, 60 );

		if ( false === $allowed ) {
			throw AI_Exception::rate_limited();
		}
	}
}
