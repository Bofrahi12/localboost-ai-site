<?php
/**
 * Automated monitoring service.
 *
 * Schedules periodic audits via a single WP-Cron hook and notifies the
 * administrator about new critical issues, score drops, or completed runs.
 *
 * Frequencies (decision, Phase 4): exactly 'off' | 'weekly' | 'monthly'.
 * No 'daily' — monthly is enforced inside run() with a 30-day gap instead of
 * registering a custom cron schedule, so no extra cron schedules are needed.
 *
 * Safety properties:
 * - schedule() is idempotent: the old event is always cleared first, so at
 *   most one lbai_scheduled_audit event exists; invalid frequencies clear
 *   the event and drop the option instead of fataling.
 * - run() takes a transient lock (15 min TTL): overlapping executions exit
 *   early with status 'skipped'.
 * - Per-page audit failures are retried (initial + 2 retries, 2s/5s backoff)
 *   and recorded; one bad page never kills the whole run.
 * - Every run records lbai_monitor_last_run / _next_run / _last_status
 *   (ok|failed|skipped) / _last_error, exposed via Monitor::get_status().
 *
 * Deactivation clears the hook (see Deactivator), so cron never runs while
 * the plugin is disabled.
 *
 * Integration note for the Loader (admin/bootstrap layer):
 *   add_action( 'lbai_scheduled_audit', array( 'LocalBoostAI\Services\Monitor', 'run' ) );
 * WP-Cron only fires on site visits; for reliable delivery the site owner
 * should set up a real server cron hitting wp-cron.php.
 *
 * Email template note (verified 2026-09-24): the scheduled-run completion
 * mail intentionally uses the 'report_ready' template — its payload is a
 * multi-page run summary (title + download_url). The 'audit_completed'
 * template is for single audits and expects score+url, which this run does
 * not produce.
 *
 * @package LocalBoostAI\Services
 */

namespace LocalBoostAI\Services;

use LocalBoostAI\Includes\Options;
use LocalBoostAI\Includes\Usage_Tracker;
use LocalBoostAI\Includes\Mailer;

defined( 'ABSPATH' ) || exit;

class Monitor {

	/**
	 * WP-Cron hook used for scheduled audits.
	 *
	 * @var string
	 */
	const HOOK = 'lbai_scheduled_audit';

	/**
	 * Allowed monitoring frequencies. 'daily' is intentionally NOT offered.
	 *
	 * @var string[]
	 */
	const FREQUENCIES = array( 'off', 'weekly', 'monthly' );

	/**
	 * Minimum gap between monitored runs when frequency is "monthly".
	 *
	 * Literal 30 * DAY_IN_SECONDS (2592000): class constants are evaluated
	 * at class-load time, so we avoid depending on the WP constant here.
	 *
	 * @var int
	 */
	const MONTHLY_GAP = 2592000;

	/**
	 * Transient used as the run lock. TTL bounds a stale lock after a crash.
	 *
	 * @var string
	 */
	const LOCK_TRANSIENT = 'lbai_monitor_lock';

	/**
	 * Run-lock TTL in seconds (15 minutes).
	 *
	 * @var int
	 */
	const LOCK_TTL = 900;

	/**
	 * Score drop (points) that triggers a notification.
	 *
	 * @var int
	 */
	const SCORE_DROP_THRESHOLD = 10;

	/**
	 * Total audit attempts per page: the initial try plus up to 2 retries.
	 *
	 * @var int
	 */
	const MAX_ATTEMPTS = 3;

	/**
	 * Schedule automated monitoring.
	 *
	 * Idempotent: any existing event is removed first, so scheduling twice —
	 * or switching frequencies — can never create duplicate events.
	 * 'off' clears the event and leaves the stored frequency alone;
	 * anything outside off|weekly|monthly clears the event, deletes the
	 * stored frequency, and returns without scheduling (no fatal).
	 *
	 * @param string $frequency 'off', 'weekly' or 'monthly'.
	 * @return void
	 */
	public static function schedule( string $frequency ): void {
		$frequency = strtolower( trim( $frequency ) );

		if ( ! in_array( $frequency, self::FREQUENCIES, true ) ) {
			self::unschedule();
			delete_option( 'lbai_monitor_frequency' );
			return;
		}

		// Always unschedule first: exactly one event, no duplicates.
		self::unschedule();

		if ( 'off' === $frequency ) {
			return;
		}

		update_option( 'lbai_monitor_frequency', $frequency );
		wp_schedule_event( time(), 'weekly', self::HOOK );
	}

	/**
	 * Remove the scheduled monitoring event.
	 *
	 * @return void
	 */
	public static function unschedule(): void {
		wp_clear_scheduled_hook( self::HOOK );
	}

	/**
	 * Current monitoring status for the dashboard / REST.
	 *
	 * @return array{
	 *   frequency: string,
	 *   last_run: int,
	 *   next_run: int,
	 *   status: string,
	 *   error: string,
	 *   monitored_pages: int,
	 *   locked: bool
	 * }
	 */
	public static function get_status(): array {
		$frequency = (string) get_option( 'lbai_monitor_frequency', 'off' );
		if ( ! in_array( $frequency, self::FREQUENCIES, true ) ) {
			$frequency = 'off';
		}
		$next = wp_next_scheduled( self::HOOK );

		return array(
			'frequency'       => $frequency,
			'last_run'        => (int) get_option( 'lbai_monitor_last_run', 0 ),
			'next_run'        => $next ? (int) $next : 0,
			'status'          => (string) get_option( 'lbai_monitor_last_status', 'never' ),
			'error'           => (string) get_option( 'lbai_monitor_last_error', '' ),
			'monitored_pages' => count( self::monitored_pages() ),
			'locked'          => (bool) get_transient( self::LOCK_TRANSIENT ),
		);
	}

	/**
	 * Run the scheduled audit pass.
	 *
	 * Audits the configured pages (default: the front page), stops silently
	 * when the audit usage limit is exhausted, retries transient per-page
	 * failures, and sends notifications according to the notification
	 * settings. Never throws: every failure path is recorded in the status
	 * options instead.
	 *
	 * @return void
	 */
	public static function run(): void {
		$frequency = (string) get_option( 'lbai_monitor_frequency', 'off' );
		if ( ! in_array( $frequency, array( 'weekly', 'monthly' ), true ) ) {
			self::record_status( 'skipped', __( 'Monitoring is disabled.', 'localboost-ai' ) );
			return;
		}

		// Run lock: never let two monitoring passes overlap. A stale lock
		// (e.g. after a fatal) expires on its own after LOCK_TTL seconds.
		if ( get_transient( self::LOCK_TRANSIENT ) ) {
			self::record_status( 'skipped', __( 'Another monitoring run is already in progress.', 'localboost-ai' ) );
			return;
		}
		set_transient( self::LOCK_TRANSIENT, time(), self::LOCK_TTL );

		try {
			$last_run = (int) get_option( 'lbai_monitor_last_run', 0 );

			// Monthly = the weekly event fires, but we only act every 30 days.
			// last_run is updated only by real executions, so the gap is
			// measured between executions, not between cron fires.
			if ( 'monthly' === $frequency && ( time() - $last_run ) < self::MONTHLY_GAP ) {
				self::record_status( 'skipped', '' );
				return;
			}

			update_option( 'lbai_monitor_last_run', time() );

			$alerts     = array();
			$audited    = 0;
			$failures   = 0;
			$last_error = '';

			foreach ( self::monitored_pages() as $post_id ) {
				// Respect the audit usage limit; stop silently when exhausted.
				if ( class_exists( Usage_Tracker::class )
					&& method_exists( Usage_Tracker::class, 'can_use' )
					&& ! Usage_Tracker::can_use( 'audit' ) ) {
					break;
				}

				$previous = self::previous_audit( $post_id );

				list( $ok, $result ) = self::with_retry(
					function () use ( $post_id ) {
						return SEO_Auditor::audit_post( $post_id );
					}
				);

				if ( ! $ok ) {
					$failures++;
					$last_error = is_string( $result ) && '' !== $result
						? $result
						: __( 'Audit failed.', 'localboost-ai' );
					continue;
				}

				$audited++;

				if ( is_array( $previous ) ) {
					$alert = self::detect_regression( $previous, $result );
					if ( null !== $alert ) {
						$alerts[] = $alert;
					}
				}
			}

			if ( $failures > 0 ) {
				self::record_status( 'failed', $last_error );
			} else {
				self::record_status( 'ok', '' );
			}

			if ( ! empty( $alerts ) && Options::get( 'lbai_notify_critical' ) ) {
				self::notify(
					'critical_issue',
					__( 'LocalBoost AI: SEO issue detected', 'localboost-ai' ),
					array(
						'issue'         => implode( '. ', $alerts ),
						'dashboard_url' => admin_url( 'admin.php?page=lbai-dashboard' ),
					)
				);
			}

			if ( $audited > 0 && Options::get( 'lbai_notify_audit_completed' ) ) {
				self::notify(
					'report_ready',
					__( 'LocalBoost AI: scheduled audit completed', 'localboost-ai' ),
					array(
						'title'        => sprintf(
							/* translators: %d: number of pages audited. */
							__( 'The scheduled SEO audit completed successfully. %d page(s) checked.', 'localboost-ai' ),
							$audited
						),
						'download_url' => admin_url( 'admin.php?page=lbai-reports' ),
					)
				);
			}
		} finally {
			delete_transient( self::LOCK_TRANSIENT );
		}
	}

	/**
	 * Run a callable with retry + backoff.
	 *
	 * Up to MAX_ATTEMPTS total attempts (initial + 2 retries), sleeping 2
	 * seconds before the first retry and 5 seconds before the second.
	 * sleep() is called unqualified so tests can override it via the
	 * namespace fallback without waiting in real time.
	 *
	 * @param callable $fn Work to attempt.
	 * @return array{0: bool, 1: mixed} [success, result|error message].
	 */
	private static function with_retry( callable $fn ): array {
		$delays  = array( 2, 5 );
		$attempt = 0;
		$error   = '';

		while ( true ) {
			try {
				return array( true, $fn() );
			} catch ( \Throwable $e ) {
				$error = $e->getMessage();
			}

			if ( $attempt >= count( $delays ) ) {
				break;
			}
			sleep( $delays[ $attempt ] );
			$attempt++;
		}

		return array( false, $error );
	}

	/**
	 * Post IDs covered by monitoring: configured pages, or the front page
	 * when nothing is configured.
	 *
	 * @return int[]
	 */
	private static function monitored_pages(): array {
		$ids = array();
		foreach ( (array) get_option( 'lbai_monitor_pages', array() ) as $post_id ) {
			$post_id = (int) $post_id;
			if ( $post_id > 0 ) {
				$ids[] = $post_id;
			}
		}
		if ( empty( $ids ) ) {
			$front_page = (int) get_option( 'page_on_front' );
			if ( $front_page > 0 ) {
				$ids[] = $front_page;
			}
		}
		return array_values( array_unique( $ids ) );
	}

	/**
	 * Persist the run outcome for the dashboard.
	 *
	 * @param string $status 'ok', 'failed' or 'skipped'.
	 * @param string $error  Failure reason, or ''.
	 * @return void
	 */
	private static function record_status( string $status, string $error ): void {
		update_option( 'lbai_monitor_last_status', $status );
		update_option( 'lbai_monitor_last_error', $error );
		$next = wp_next_scheduled( self::HOOK );
		update_option( 'lbai_monitor_next_run', $next ? (int) $next : 0 );
	}

	/**
	 * Get the most recent stored audit for a post.
	 *
	 * @param int $post_id Post ID.
	 * @return array|null Audit row or null.
	 */
	private static function previous_audit( int $post_id ): ?array {
		global $wpdb;
		$table = $wpdb->prefix . 'lbai_audits';

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT score, issues, url FROM {$table} WHERE post_id = %d ORDER BY id DESC LIMIT 1",
				$post_id
			),
			ARRAY_A
		);

		return is_array( $row ) ? $row : null;
	}

	/**
	 * Compare a new audit against the previous one and describe any regression.
	 *
	 * @param array $previous Previous audit row (score, issues JSON, url).
	 * @param array $audit    New audit result from SEO_Auditor::audit_post().
	 * @return string|null Alert line, or null when nothing notable changed.
	 */
	private static function detect_regression( array $previous, array $audit ): ?string {
		$prev_issues = json_decode( (string) $previous['issues'], true );
		$prev_critical_ids = array();
		if ( is_array( $prev_issues ) ) {
			foreach ( $prev_issues as $issue ) {
				if ( isset( $issue['severity'] ) && 'critical' === $issue['severity'] && isset( $issue['id'] ) ) {
					$prev_critical_ids[] = (string) $issue['id'];
				}
			}
		}

		$new_critical = array();
		foreach ( (array) $audit['issues'] as $issue ) {
			if ( isset( $issue['severity'], $issue['id'] )
				&& 'critical' === $issue['severity']
				&& ! in_array( (string) $issue['id'], $prev_critical_ids, true ) ) {
				$new_critical[] = isset( $issue['title'] ) ? (string) $issue['title'] : (string) $issue['id'];
			}
		}

		$score_drop = (int) $previous['score'] - (int) $audit['score'];
		$url        = isset( $audit['url'] ) ? (string) $audit['url'] : '';

		if ( ! empty( $new_critical ) ) {
			return sprintf(
				/* translators: 1: page URL, 2: comma-separated list of new critical issues. */
				__( '%1$s: new critical issue(s): %2$s', 'localboost-ai' ),
				$url,
				implode( ', ', $new_critical )
			);
		}

		if ( $score_drop >= self::SCORE_DROP_THRESHOLD ) {
			return sprintf(
				/* translators: 1: page URL, 2: points dropped. */
				__( '%1$s: SEO score dropped by %2$d points since the last check.', 'localboost-ai' ),
				$url,
				$score_drop
			);
		}

		return null;
	}

	/**
	 * Send an email notification, defensively.
	 *
	 * Uses Mailer::send( string $to, string $subject, string $template, array $data ).
	 * Silently skips when the Mailer service is unavailable.
	 *
	 * @param string $template Mailer template slug.
	 * @param string $subject  Email subject.
	 * @param array  $data     Template data (already translated strings).
	 * @return void
	 */
	private static function notify( string $template, string $subject, array $data ): void {
		if ( ! class_exists( Mailer::class ) || ! method_exists( Mailer::class, 'send' ) ) {
			return;
		}

		try {
			Mailer::send( get_option( 'admin_email' ), $subject, $template, $data );
		} catch ( \Throwable $e ) {
			// Notifications must never break the monitoring run.
		}
	}
}
