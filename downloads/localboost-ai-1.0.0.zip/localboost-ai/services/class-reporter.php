<?php
/**
 * Reporter service.
 *
 * Aggregates audit history, issue trends and AI usage into agency-ready
 * report data, plus CSV export. PDF export is intentionally not implemented
 * in v1 (see handoff notes); use CSV or the on-screen report.
 *
 * Performance notes (Phase 7 hardening):
 * - No unbounded full-table scans: per-post latest/previous audits are
 *   resolved with SQL aggregation (GROUP BY + MAX(id)) and fetched with a
 *   bounded IN() list. Severity counting stays in PHP because the `issues`
 *   column is a JSON blob that cannot be aggregated portably in SQL
 *   (MySQL 5.7 has no usable JSON aggregation for this shape).
 * - Every list query supports pagination (page/per_page) and validated
 *   YYYY-MM-DD date-range filters (after/before).
 * - Any scan that could grow without bound is capped by MAX_ROWS.
 * - CSV export reads in fixed-size chunks (keyset pagination on id) so a
 *   large audit history never sits fully in memory.
 * - Table names are always `$wpdb->prefix` + an allow-listed suffix;
 *   ORDER BY columns/directions come from strict allow-lists;
 *   LIMIT/OFFSET are bound as %d; every other value goes through
 *   `$wpdb->prepare()`.
 *
 * @package LocalBoostAI\Services
 */

namespace LocalBoostAI\Services;

use LocalBoostAI\Includes\Usage_Tracker;

defined( 'ABSPATH' ) || exit;

class Reporter {

	/**
	 * Hard cap for any scan that could otherwise grow without bound
	 * (distinct audited posts, CSV export rows).
	 */
	const MAX_ROWS = 5000;

	/** Default / maximum page size for paginated lists. */
	const DEFAULT_PER_PAGE = 20;
	const MAX_PER_PAGE     = 100;

	/** Default / maximum number of score-history points. */
	const DEFAULT_HISTORY_LIMIT = 12;
	const MAX_HISTORY_LIMIT     = 100;

	/** Rows read per chunk when streaming a CSV export. */
	const EXPORT_CHUNK_SIZE = 500;

	/**
	 * Allow-listed table suffixes. Table names are always
	 * `$wpdb->prefix` + one of these — never user input.
	 */
	const ALLOWED_TABLE_SUFFIXES = array( 'lbai_audits' );

	/** Allow-listed ORDER BY columns for the score-history list. */
	const ALLOWED_HISTORY_ORDER_BY = array( 'created_at', 'id', 'score' );

	/** Allow-listed sort directions. */
	const ALLOWED_ORDER_DIRECTIONS = array( 'ASC', 'DESC' );

	/**
	 * Build the report summary.
	 *
	 * @param array $args {
	 *     Optional. Pagination / filtering arguments.
	 *
	 *     @type string $after           Start date (inclusive) as YYYY-MM-DD.
	 *                                   Invalid values are ignored.
	 *     @type string $before          End date (inclusive) as YYYY-MM-DD.
	 *                                   Invalid values are ignored.
	 *     @type int    $page            Page number for the `improvements`
	 *                                   list. Default 1.
	 *     @type int    $per_page        Improvements per page.
	 *                                   Default 20, capped at 100.
	 *     @type int    $history_limit   Number of score-history points.
	 *                                   Default 12, capped at 100.
	 *     @type string $history_orderby Score-history sort column. One of
	 *                                   created_at, id, score. Default created_at.
	 *     @type string $history_order   ASC or DESC. Default DESC.
	 * }
	 * @return array {
	 *     @type array $score_history      Audits (newest first): score + checked_at.
	 *     @type int   $latest_score       Latest score or 0 when no audits exist.
	 *     @type int   $previous_score     Previous score or 0.
	 *     @type int   $issues_fixed       Critical+warning issues resolved between
	 *                                     consecutive audits of the same post (summed).
	 *     @type int   $issues_remaining   Critical+warning issues in the latest audit per post.
	 *     @type int   $pages_analyzed     Distinct posts audited in the selected
	 *                                     range (defaults to the last 30 days).
	 *     @type array $ai_usage           Monthly usage per feature.
	 *     @type array $improvements       Paginated: posts whose score improved
	 *                                     vs their previous audit.
	 *     @type int   $improvements_total Total improvements before pagination.
	 *     @type array $pagination         page, per_page, total_items, total_pages.
	 *     @type array $filters            Normalised after/before (null when unset/invalid).
	 * }
	 */
	public static function summary( array $args = array() ): array {
		global $wpdb;
		$table = self::table( 'lbai_audits' );

		list( $after, $before ) = self::date_bounds( $args );

		// pages_analyzed keeps its historical "last 30 days" meaning unless
		// the caller passes an explicit range.
		$range_after  = $after;
		$range_before = $before;
		if ( null === $range_after && null === $range_before ) {
			$range_after = gmdate( 'Y-m-d', time() - 30 * self::day_in_seconds() );
		}
		list( $where, $params ) = self::date_where( $range_after, $range_before, 'created_at' );

		// --- Score history (bounded list query). ---
		$history_limit = self::bounded_int(
			isset( $args['history_limit'] ) ? $args['history_limit'] : null,
			self::DEFAULT_HISTORY_LIMIT,
			1,
			self::MAX_HISTORY_LIMIT
		);
		$order_by      = self::order_by_column(
			isset( $args['history_orderby'] ) ? $args['history_orderby'] : null
		);
		$order_dir     = self::order_direction(
			isset( $args['history_order'] ) ? $args['history_order'] : null
		);

		$history = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT score, created_at FROM {$table} WHERE {$where} ORDER BY {$order_by} {$order_dir}, id DESC LIMIT %d",
				array_merge( $params, array( $history_limit ) )
			),
			ARRAY_A
		);
		$history = is_array( $history ) ? $history : array();

		$latest_score   = isset( $history[0] ) ? (int) $history[0]['score'] : 0;
		$previous_score = isset( $history[1] ) ? (int) $history[1]['score'] : 0;

		// --- Latest + previous audit per post, resolved in SQL (no full-table fetch). ---
		$cap        = self::MAX_ROWS;
		$latest_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT MAX(id) FROM {$table} WHERE {$where} GROUP BY post_id ORDER BY post_id ASC LIMIT %d",
				array_merge( $params, array( $cap ) )
			)
		);
		$latest_ids = is_array( $latest_ids ) ? array_map( 'intval', $latest_ids ) : array();

		$prev_ids = array();
		if ( ! empty( $latest_ids ) ) {
			// Second-latest audit per post via anti-join (no window functions,
			// so this stays compatible with MySQL 5.7 / MariaDB 10.3).
			list( $where_t, $params_t ) = self::date_where( $range_after, $range_before, 't.created_at' );
			$prev_ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT MAX(t.id) FROM {$table} t
					 LEFT JOIN (
						 SELECT post_id, MAX(id) AS latest_id
						 FROM {$table}
						 WHERE {$where}
						 GROUP BY post_id
					 ) m ON m.post_id <=> t.post_id AND m.latest_id = t.id
					 WHERE m.latest_id IS NULL AND {$where_t}
					 GROUP BY t.post_id ORDER BY t.post_id ASC LIMIT %d",
					array_merge( $params, $params_t, array( $cap ) )
				)
			);
			$prev_ids = is_array( $prev_ids ) ? array_map( 'intval', $prev_ids ) : array();
		}

		$latest_by_post = array();
		foreach ( self::rows_by_ids( $table, $latest_ids ) as $row ) {
			$latest_by_post[ (int) $row['post_id'] ] = $row;
		}
		$prev_by_post = array();
		foreach ( self::rows_by_ids( $table, $prev_ids ) as $row ) {
			$prev_by_post[ (int) $row['post_id'] ] = $row;
		}

		$issues_fixed     = 0;
		$issues_remaining = 0;
		$improvements     = array();

		foreach ( $latest_by_post as $pid => $latest ) {
			$latest_cw         = self::count_critical_warning( $latest['issues'] );
			$issues_remaining += $latest_cw;

			if ( isset( $prev_by_post[ $pid ] ) ) {
				$previous      = $prev_by_post[ $pid ];
				$prev_cw       = self::count_critical_warning( $previous['issues'] );
				$issues_fixed += max( 0, $prev_cw - $latest_cw );

				if ( (int) $latest['score'] > (int) $previous['score'] ) {
					$improvements[] = array(
						'post_id'        => $pid,
						'url'            => $latest['url'],
						'previous_score' => (int) $previous['score'],
						'score'          => (int) $latest['score'],
						'checked_at'     => $latest['created_at'],
					);
				}
			}
		}

		// --- Paginate the improvements list. ---
		$page     = self::bounded_int(
			isset( $args['page'] ) ? $args['page'] : null,
			1,
			1,
			1000000
		);
		$per_page = self::bounded_int(
			isset( $args['per_page'] ) ? $args['per_page'] : null,
			self::DEFAULT_PER_PAGE,
			1,
			self::MAX_PER_PAGE
		);

		$total_improvements = count( $improvements );
		$total_pages        = max( 1, (int) ceil( $total_improvements / $per_page ) );
		if ( $page > $total_pages ) {
			$page = $total_pages;
		}
		$improvements_page = array_slice( $improvements, ( $page - 1 ) * $per_page, $per_page );

		$pages_analyzed = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT post_id) FROM {$table} WHERE {$where}",
				$params
			)
		);

		return array(
			'score_history'      => $history,
			'latest_score'       => $latest_score,
			'previous_score'     => $previous_score,
			'issues_fixed'       => $issues_fixed,
			'issues_remaining'   => $issues_remaining,
			'pages_analyzed'     => $pages_analyzed,
			'ai_usage'           => array(
				'audit'         => self::monthly_usage( 'audit' ),
				'ai_generation' => self::monthly_usage( 'ai_generation' ),
				'content'       => self::monthly_usage( 'content' ),
			),
			'improvements'       => $improvements_page,
			'improvements_total' => $total_improvements,
			'pagination'         => array(
				'page'        => $page,
				'per_page'    => $per_page,
				'total_items' => $total_improvements,
				'total_pages' => $total_pages,
			),
			'filters'            => array(
				'after'  => $after,
				'before' => $before,
			),
		);
	}

	/**
	 * Neutralize a CSV cell against formula injection (OWASP).
	 *
	 * Spreadsheet apps interpret cells starting with =, +, -, @ (and, in
	 * some apps, tab / carriage return) as formulas. Prefixing such values
	 * with a single quote keeps the visible text identical while preventing
	 * execution. Numeric cells are returned untouched.
	 *
	 * @param mixed $value Cell value.
	 * @return mixed Safe cell value.
	 */
	private static function csv_cell( $value ) {
		if ( ! is_string( $value ) || $value === '' ) {
			return $value;
		}
		$first = $value[0];
		if ( $first === '=' || $first === '+' || $first === '-' || $first === '@' || $first === "\t" || $first === "\r" ) {
			return "'" . $value;
		}
		return $value;
	}

	/**
	 * Export a report as CSV.
	 *
	 * The audits export is streamed in fixed-size chunks (keyset pagination
	 * on `id`) and capped at MAX_ROWS rows, so exporting a large history
	 * never loads the whole dataset into memory. Columns and row logic are
	 * unchanged from v1.0.0. String cells are neutralized against CSV
	 * formula injection (OWASP): values starting with =, +, -, @, tab or
	 * carriage return are prefixed with a single quote.
	 *
	 * @param string $report 'audits' (audit history) or 'usage' (monthly usage).
	 *                       Any other value falls back to 'audits'.
	 * @param array  $args   Optional. `after` / `before` YYYY-MM-DD date filters
	 *                       (validated; invalid values are ignored).
	 * @return string CSV content.
	 */
	public static function export_csv( string $report = 'audits', array $args = array() ): string {
		global $wpdb;
		$table = self::table( 'lbai_audits' );

		$handle = fopen( 'php://temp', 'r+' );
		if ( false === $handle ) {
			return '';
		}

		if ( 'usage' === $report ) {
			fputcsv( $handle, array( 'feature', 'month', 'amount' ), ',', '"', '\\' );
			$month = gmdate( 'Y-m' );
			foreach ( array( 'audit', 'ai_generation', 'content' ) as $feature ) {
				fputcsv( $handle, array( self::csv_cell( $feature ), self::csv_cell( $month ), self::monthly_usage( $feature ) ), ',', '"', '\\' );
			}
		} else {
			fputcsv( $handle, array( 'id', 'date', 'post_id', 'url', 'score' ), ',', '"', '\\' );

			list( $after, $before )   = self::date_bounds( $args );
			list( $where, $params )    = self::date_where( $after, $before, 'created_at' );
			$chunk    = self::EXPORT_CHUNK_SIZE;
			$exported = 0;
			$last_id  = null;

			do {
				$chunk_params = $params;
				if ( null === $last_id ) {
					$sql = "SELECT id, created_at, post_id, url, score FROM {$table} WHERE {$where} ORDER BY id DESC LIMIT %d";
				} else {
					$sql            = "SELECT id, created_at, post_id, url, score FROM {$table} WHERE {$where} AND id < %d ORDER BY id DESC LIMIT %d";
					$chunk_params[] = $last_id;
				}
				$chunk_params[] = $chunk;

				$rows = $wpdb->get_results( $wpdb->prepare( $sql, $chunk_params ), ARRAY_A );
				if ( ! is_array( $rows ) || empty( $rows ) ) {
					break;
				}

				foreach ( $rows as $row ) {
					if ( $exported >= self::MAX_ROWS ) {
						break 2;
					}
					fputcsv(
						$handle,
						array(
							(int) $row['id'],
							self::csv_cell( $row['created_at'] ),
							(int) $row['post_id'],
							self::csv_cell( $row['url'] ),
							(int) $row['score'],
						),
						',',
						'"',
						'\\'
					);
					$last_id  = (int) $row['id'];
					$exported++;
				}
			} while ( count( $rows ) === $chunk && $exported < self::MAX_ROWS );
		}

		rewind( $handle );
		$csv = stream_get_contents( $handle );
		fclose( $handle );

		return (string) $csv;
	}

	/**
	 * Resolve a plugin table name from an allow-listed suffix.
	 *
	 * @param string $suffix Table suffix, e.g. 'lbai_audits'.
	 * @return string Fully-qualified table name.
	 */
	private static function table( string $suffix ): string {
		global $wpdb;
		if ( ! in_array( $suffix, self::ALLOWED_TABLE_SUFFIXES, true ) ) {
			$suffix = 'lbai_audits';
		}
		return $wpdb->prefix . $suffix;
	}

	/**
	 * Fetch full audit rows for a bounded list of ids.
	 *
	 * @param string $table Audits table name (from self::table()).
	 * @param array  $ids   Row ids.
	 * @return array
	 */
	private static function rows_by_ids( string $table, array $ids ): array {
		global $wpdb;

		$clean = array();
		foreach ( $ids as $id ) {
			$id = (int) $id;
			if ( $id > 0 ) {
				$clean[ $id ] = $id;
			}
		}
		if ( empty( $clean ) ) {
			return array();
		}
		// Never pull more than MAX_ROWS rows in one go.
		$clean        = array_slice( array_values( $clean ), 0, self::MAX_ROWS );
		$placeholders = implode( ',', array_fill( 0, count( $clean ), '%d' ) );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, post_id, url, score, issues, created_at FROM {$table} WHERE id IN ({$placeholders})",
				$clean
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Normalise the after/before date filters.
	 *
	 * @param array $args Caller arguments.
	 * @return array Tuple of ( ?string $after, ?string $before ) as YYYY-MM-DD or null.
	 */
	private static function date_bounds( array $args ): array {
		$after  = self::valid_date( isset( $args['after'] ) ? $args['after'] : null );
		$before = self::valid_date( isset( $args['before'] ) ? $args['before'] : null );
		return array( $after, $before );
	}

	/**
	 * Build a date-range WHERE fragment with bound parameters.
	 *
	 * @param string|null $after  YYYY-MM-DD start (inclusive) or null.
	 * @param string|null $before YYYY-MM-DD end (inclusive) or null.
	 * @param string      $column Date column reference (internal constant only).
	 * @return array Tuple of ( string $where_sql, array $params ).
	 */
	private static function date_where( ?string $after, ?string $before, string $column ): array {
		$clauses = array( '1 = 1' );
		$params  = array();
		if ( null !== $after ) {
			$clauses[] = "{$column} >= %s";
			$params[]  = $after . ' 00:00:00';
		}
		if ( null !== $before ) {
			$clauses[] = "{$column} <= %s";
			$params[]  = $before . ' 23:59:59';
		}
		return array( implode( ' AND ', $clauses ), $params );
	}

	/**
	 * Strictly validate a YYYY-MM-DD date. Anything else returns null.
	 *
	 * @param mixed $value Candidate value.
	 * @return string|null Normalised YYYY-MM-DD date or null when invalid.
	 */
	private static function valid_date( $value ): ?string {
		if ( ! is_string( $value ) ) {
			return null;
		}
		$value = trim( $value );
		if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $value, $m ) ) {
			return null;
		}
		$year  = (int) $m[1];
		$month = (int) $m[2];
		$day   = (int) $m[3];
		if ( ! checkdate( $month, $day, $year ) ) {
			return null;
		}
		return sprintf( '%04d-%02d-%02d', $year, $month, $day );
	}

	/**
	 * Clamp an integer-ish input into [ $min, $max ], falling back to
	 * $default for non-numeric input.
	 *
	 * @param mixed $value   Candidate value.
	 * @param int   $default Fallback.
	 * @param int   $min     Minimum (inclusive).
	 * @param int   $max     Maximum (inclusive).
	 * @return int
	 */
	private static function bounded_int( $value, int $default, int $min, int $max ): int {
		if ( is_bool( $value ) || is_array( $value ) || is_object( $value ) || null === $value ) {
			return $default;
		}
		if ( is_string( $value ) ) {
			$value = trim( $value );
			if ( ! preg_match( '/^-?\d+$/', $value ) ) {
				return $default;
			}
		}
		$int = (int) $value;
		if ( $int < $min ) {
			return $min;
		}
		if ( $int > $max ) {
			return $max;
		}
		return $int;
	}

	/**
	 * Allow-list an ORDER BY column for the score-history list.
	 *
	 * @param mixed $value Requested column.
	 * @return string Safe column name.
	 */
	private static function order_by_column( $value ): string {
		if ( is_string( $value ) && in_array( strtolower( trim( $value ) ), self::ALLOWED_HISTORY_ORDER_BY, true ) ) {
			return strtolower( trim( $value ) );
		}
		return 'created_at';
	}

	/**
	 * Allow-list a sort direction.
	 *
	 * @param mixed $value Requested direction.
	 * @return string ASC or DESC.
	 */
	private static function order_direction( $value ): string {
		if ( is_string( $value ) && in_array( strtoupper( trim( $value ) ), self::ALLOWED_ORDER_DIRECTIONS, true ) ) {
			return strtoupper( trim( $value ) );
		}
		return 'DESC';
	}

	/**
	 * DAY_IN_SECONDS with a fallback for non-WordPress contexts.
	 *
	 * @return int
	 */
	private static function day_in_seconds(): int {
		return defined( 'DAY_IN_SECONDS' ) ? (int) DAY_IN_SECONDS : 86400;
	}

	/**
	 * Count critical + warning issues in a stored issues JSON blob.
	 *
	 * @param string $issues_json JSON-encoded issue list.
	 * @return int
	 */
	private static function count_critical_warning( $issues_json ): int {
		$issues = json_decode( (string) $issues_json, true );
		if ( ! is_array( $issues ) ) {
			return 0;
		}
		$count = 0;
		foreach ( $issues as $issue ) {
			$severity = isset( $issue['severity'] ) ? (string) $issue['severity'] : '';
			if ( 'critical' === $severity || 'warning' === $severity ) {
				$count++;
			}
		}
		return $count;
	}

	/**
	 * Read monthly usage for a feature, defensively.
	 *
	 * @param string $feature Feature key (audit, ai_generation, content).
	 * @return int
	 */
	private static function monthly_usage( string $feature ): int {
		if ( class_exists( Usage_Tracker::class ) && method_exists( Usage_Tracker::class, 'get_monthly_usage' ) ) {
			return max( 0, (int) Usage_Tracker::get_monthly_usage( $feature ) );
		}
		return 0;
	}
}
