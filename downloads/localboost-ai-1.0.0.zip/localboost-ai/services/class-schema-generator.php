<?php
/**
 * Schema.org structured data generator.
 *
 * Builds valid JSON-LD from the Local SEO settings. Only non-empty values
 * are emitted: the generator never invents or emits misleading fields.
 * Every schema can be validated with validate() before it is activated.
 *
 * @package LocalBoostAI\Services
 */

namespace LocalBoostAI\Services;

use LocalBoostAI\Includes\Options;

defined( 'ABSPATH' ) || exit;

class Schema_Generator {

	/**
	 * Business types supported by the plugin.
	 *
	 * @return array Type key => [ schema => Schema.org type, label => translated label ].
	 */
	public static function get_supported_types(): array {
		return array(
			'restaurant'   => array(
				'schema' => 'Restaurant',
				'label'  => __( 'Restaurant', 'localboost-ai' ),
			),
			'dentist'      => array(
				'schema' => 'Dentist',
				'label'  => __( 'Dentist', 'localboost-ai' ),
			),
			'doctor'       => array(
				'schema' => 'Physician',
				'label'  => __( 'Doctor', 'localboost-ai' ),
			),
			'lawyer'       => array(
				'schema' => 'Attorney',
				'label'  => __( 'Lawyer', 'localboost-ai' ),
			),
			'real_estate'  => array(
				'schema' => 'RealEstateAgent',
				'label'  => __( 'Real estate business', 'localboost-ai' ),
			),
			'salon'        => array(
				'schema' => 'HairSalon',
				'label'  => __( 'Salon', 'localboost-ai' ),
			),
			'contractor'   => array(
				'schema' => 'HomeAndConstructionBusiness',
				'label'  => __( 'Contractor', 'localboost-ai' ),
			),
			'plumber'      => array(
				'schema' => 'Plumber',
				'label'  => __( 'Plumber', 'localboost-ai' ),
			),
			'electrician'  => array(
				'schema' => 'Electrician',
				'label'  => __( 'Electrician', 'localboost-ai' ),
			),
			'cleaning'     => array(
				'schema' => 'CleaningService',
				'label'  => __( 'Cleaning company', 'localboost-ai' ),
			),
			'shop'         => array(
				'schema' => 'Store',
				'label'  => __( 'Local shop', 'localboost-ai' ),
			),
			'agency'       => array(
				'schema' => 'ProfessionalService',
				'label'  => __( 'Marketing agency', 'localboost-ai' ),
			),
			'freelancer'   => array(
				'schema' => 'ProfessionalService',
				'label'  => __( 'Freelancer', 'localboost-ai' ),
			),
			'local_shop'   => array(
				'schema' => 'LocalBusiness',
				'label'  => __( 'Local business', 'localboost-ai' ),
			),
		);
	}

	/**
	 * Build a LocalBusiness (or subtype) schema array from the settings.
	 *
	 * @param string $type Business type key (see get_supported_types()).
	 *                     Unknown keys fall back to LocalBusiness.
	 * @return array Schema.org array (use to_jsonld() to serialize).
	 */
	public static function build( string $type = 'local_business' ): array {
		$supported   = self::get_supported_types();
		$schema_type = isset( $supported[ $type ] ) ? $supported[ $type ]['schema'] : 'LocalBusiness';

		$schema = array(
			'@context' => 'https://schema.org',
			'@type'    => $schema_type,
		);

		$name = trim( (string) Options::get( 'lbai_business_name' ) );
		if ( '' !== $name ) {
			$schema['name'] = $name;
		}

		$phone = trim( (string) Options::get( 'lbai_phone' ) );
		if ( '' !== $phone ) {
			$schema['telephone'] = $phone;
		}

		$url = trim( (string) Options::get( 'lbai_website' ) );
		if ( '' === $url ) {
			$url = home_url();
		}
		$schema['url'] = esc_url_raw( $url );

		$price_range = trim( (string) Options::get( 'lbai_price_range' ) );
		if ( '' !== $price_range ) {
			$schema['priceRange'] = $price_range;
		}

		$address = array_filter(
			array(
				'streetAddress'   => trim( (string) Options::get( 'lbai_street' ) ),
				'addressLocality' => trim( (string) Options::get( 'lbai_city' ) ),
				'addressRegion'   => trim( (string) Options::get( 'lbai_region' ) ),
				'postalCode'      => trim( (string) Options::get( 'lbai_postal' ) ),
				'addressCountry'  => trim( (string) Options::get( 'lbai_country' ) ),
			)
		);
		if ( ! empty( $address ) ) {
			$schema['address'] = array_merge( array( '@type' => 'PostalAddress' ), $address );
		}

		$lat = Options::get( 'lbai_lat' );
		$lng = Options::get( 'lbai_lng' );
		if ( is_numeric( $lat ) && is_numeric( $lng ) ) {
			$schema['geo'] = array(
				'@type'     => 'GeoCoordinates',
				'latitude'  => (float) $lat,
				'longitude' => (float) $lng,
			);
		}

		$opening_hours = self::opening_hours_specification( Options::get( 'lbai_hours' ) );
		if ( ! empty( $opening_hours ) ) {
			$schema['openingHoursSpecification'] = $opening_hours;
		}

		$social = Options::get( 'lbai_social' );
		if ( ! empty( $social ) ) {
			$same_as = array();
			foreach ( (array) $social as $profile ) {
				$profile = esc_url_raw( trim( (string) $profile ) );
				if ( '' !== $profile ) {
					$same_as[] = $profile;
				}
			}
			$same_as = array_values( array_unique( $same_as ) );
			if ( ! empty( $same_as ) ) {
				$schema['sameAs'] = $same_as;
			}
		}

		return $schema;
	}

	/**
	 * Build a FAQPage schema from question/answer pairs.
	 *
	 * @param array $faqs List of [ 'q' => question, 'a' => answer ].
	 * @return array FAQPage schema array.
	 */
	public static function build_faq( array $faqs ): array {
		$entities = array();

		foreach ( $faqs as $faq ) {
			if ( ! is_array( $faq ) ) {
				continue;
			}
			$question = isset( $faq['q'] ) ? sanitize_text_field( (string) $faq['q'] ) : '';
			$answer   = isset( $faq['a'] ) ? wp_kses_post( (string) $faq['a'] ) : '';
			if ( '' === $question || '' === $answer ) {
				continue;
			}
			$entities[] = array(
				'@type'          => 'Question',
				'name'           => $question,
				'acceptedAnswer' => array(
					'@type' => 'Answer',
					'text'  => $answer,
				),
			);
		}

		return array(
			'@context'   => 'https://schema.org',
			'@type'      => 'FAQPage',
			'mainEntity' => $entities,
		);
	}

	/**
	 * Build a BreadcrumbList schema from a trail.
	 *
	 * @param array $trail List of [ 'name' => label, 'url' => URL (optional, omit for current page) ].
	 * @return array BreadcrumbList schema array.
	 */
	public static function build_breadcrumb( array $trail ): array {
		$elements = array();
		$position = 1;

		foreach ( $trail as $crumb ) {
			if ( ! is_array( $crumb ) || empty( $crumb['name'] ) ) {
				continue;
			}
			$item = array(
				'@type'    => 'ListItem',
				'position' => $position,
				'name'     => sanitize_text_field( (string) $crumb['name'] ),
			);
			if ( ! empty( $crumb['url'] ) ) {
				$item['item'] = esc_url_raw( (string) $crumb['url'] );
			}
			$elements[] = $item;
			$position++;
		}

		return array(
			'@context'        => 'https://schema.org',
			'@type'           => 'BreadcrumbList',
			'itemListElement' => $elements,
		);
	}

	/**
	 * Validate a generated schema array.
	 *
	 * @param array $schema Schema array.
	 * @return string[] List of translated error messages; empty means valid.
	 */
	public static function validate( array $schema ): array {
		$errors = array();

		if ( empty( $schema['@type'] ) || ! is_string( $schema['@type'] ) ) {
			$errors[] = __( 'Schema @type is missing.', 'localboost-ai' );
			return $errors;
		}

		$local_types   = array_column( self::get_supported_types(), 'schema' );
		$local_types[] = 'LocalBusiness';

		if ( in_array( $schema['@type'], $local_types, true ) ) {
			if ( empty( $schema['name'] ) ) {
				$errors[] = __( 'A LocalBusiness schema must include the business name. Add it in the Local SEO settings.', 'localboost-ai' );
			}
			if ( empty( $schema['address'] ) || ! is_array( $schema['address'] ) ) {
				$errors[] = __( 'A LocalBusiness schema must include an address. Add street, city and postal code in the Local SEO settings.', 'localboost-ai' );
			}
		}

		return $errors;
	}

	/**
	 * Serialize a schema array to a JSON-LD string.
	 *
	 * @param array $schema Schema array.
	 * @return string JSON-LD.
	 */
	public static function to_jsonld( array $schema ): string {
		$json = (string) wp_json_encode(
			$schema,
			JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
		);

		// Never allow breaking out of the <script> block this JSON-LD is
		// printed into (business data is admin-entered but echoed publicly).
		$json = str_ireplace( '</script', '<\/script', $json );

		return $json;
	}

	/**
	 * Convert the lbai_hours setting into openingHoursSpecification entries.
	 *
	 * Accepts per-day values either as [ 'open' => 'HH:MM', 'close' => 'HH:MM' ]
	 * arrays or as "HH:MM-HH:MM" strings. Days set to "closed" are skipped.
	 *
	 * @param mixed $hours Hours setting value.
	 * @return array List of OpeningHoursSpecification arrays.
	 */
	private static function opening_hours_specification( $hours ): array {
		if ( ! is_array( $hours ) || empty( $hours ) ) {
			return array();
		}

		$specs = array();

		foreach ( $hours as $day => $value ) {
			$day_name = self::normalize_day( (string) $day );
			if ( null === $day_name ) {
				continue;
			}

			$open  = '';
			$close = '';
			if ( is_array( $value ) ) {
				$open  = isset( $value['open'] ) ? trim( (string) $value['open'] ) : '';
				$close = isset( $value['close'] ) ? trim( (string) $value['close'] ) : '';
			} elseif ( is_string( $value ) ) {
				$value = trim( $value );
				if ( '' === $value || 'closed' === strtolower( $value ) ) {
					continue;
				}
				$parts = explode( '-', $value );
				if ( 2 === count( $parts ) ) {
					$open  = trim( $parts[0] );
					$close = trim( $parts[1] );
				}
			}

			if ( ! self::is_valid_time( $open ) || ! self::is_valid_time( $close ) ) {
				continue;
			}

			$specs[] = array(
				'@type'     => 'OpeningHoursSpecification',
				'dayOfWeek' => $day_name,
				'opens'     => $open,
				'closes'    => $close,
			);
		}

		return $specs;
	}

	/**
	 * Normalize a day key to a Schema.org day name.
	 *
	 * @param string $day Day key (e.g. "monday", "mon", "Monday").
	 * @return string|null Schema.org day name or null when unknown.
	 */
	private static function normalize_day( string $day ): ?string {
		$map = array(
			'monday'    => 'Monday',
			'mon'       => 'Monday',
			'tuesday'   => 'Tuesday',
			'tue'       => 'Tuesday',
			'wednesday' => 'Wednesday',
			'wed'       => 'Wednesday',
			'thursday'  => 'Thursday',
			'thu'       => 'Thursday',
			'friday'    => 'Friday',
			'fri'       => 'Friday',
			'saturday'  => 'Saturday',
			'sat'       => 'Saturday',
			'sunday'    => 'Sunday',
			'sun'       => 'Sunday',
		);
		$key = strtolower( trim( $day ) );
		return isset( $map[ $key ] ) ? $map[ $key ] : null;
	}

	/**
	 * Check a HH:MM time string.
	 *
	 * @param string $time Time string.
	 * @return bool
	 */
	private static function is_valid_time( string $time ): bool {
		return (bool) preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $time );
	}
}
