<?php
/**
 * SEO Auditor service.
 *
 * Runs a set of statically-detectable SEO checks against a single post and
 * persists the result to the lbai_audits table. Only the requested post is
 * ever scanned (never the whole site) to keep performance predictable.
 *
 * Every check returns an issue array with exactly these keys:
 *   id, severity (critical|warning|info), category (technical|onpage|local|
 *   content|schema), field (canonical optimizer field name or ''),
 *   title, problem, why, action, ai_fix (bool).
 *
 * The ai_fix flag is true only when the issue's field is a valid,
 * optimizable canonical field (see Field_Registry); the admin UI renders
 * the "Fix with AI" button only in that case.
 *
 * @package LocalBoostAI\Services
 */

namespace LocalBoostAI\Services;

use LocalBoostAI\Includes\Field_Registry;
use LocalBoostAI\Includes\Options;
use LocalBoostAI\Includes\Text_Stats;
use LocalBoostAI\Includes\Text_Utils;
use LocalBoostAI\Includes\Usage_Tracker;

defined( 'ABSPATH' ) || exit;

class SEO_Auditor {

	/**
	 * Audit a single post.
	 *
	 * Capability checks are intentionally NOT done here: this method is also
	 * called from WP-Cron (Monitor) where no user is present. Callers that act
	 * on a user request (e.g. the REST layer) must check capabilities first.
	 *
	 * @param int $post_id Post ID to audit.
	 * @return array Audit result with score, categories, issues and counts.
	 * @throws \InvalidArgumentException When the post does not exist (REST layer maps to 404).
	 * @throws \RuntimeException         When the audit cannot be stored.
	 */
	public static function audit_post( int $post_id ): array {
		$post = get_post( $post_id );

		if ( ! $post instanceof \WP_Post || 'trash' === $post->post_status ) {
			throw new \InvalidArgumentException( 'Invalid post', 404 );
		}

		$issues = self::run_checks( $post );
		$score  = SEO_Scorer::calculate( $issues );

		$audit_id = self::save_audit( $post, $score, $issues );

		if ( class_exists( Usage_Tracker::class ) ) {
			Usage_Tracker::record( 'audit' );
		}

		return array(
			'audit_id'   => $audit_id,
			'post_id'    => $post->ID,
			'url'        => get_permalink( $post ),
			'score'      => $score['score'],
			'categories' => $score['categories'],
			'issues'     => $issues,
			'counts'     => $score['counts'],
			'checked_at' => current_time( 'mysql', true ),
		);
	}

	/**
	 * Get a summary of the latest audit plus aggregate counters.
	 *
	 * @return array {
	 *     @type array|null $latest         Latest audit row (decoded) or null.
	 *     @type array      $counts         Severity counts (critical|warning|info) of the latest audit.
	 *     @type int        $pages_analyzed Distinct posts audited in the last 30 days.
	 *     @type int        $audits_total   Total audits stored.
	 * }
	 */
	public static function get_latest_audit_summary(): array {
		global $wpdb;
		$table = $wpdb->prefix . 'lbai_audits';

		$latest = $wpdb->get_row( "SELECT * FROM {$table} ORDER BY id DESC LIMIT 1", ARRAY_A );

		$counts = array(
			'critical' => 0,
			'warning'  => 0,
			'info'     => 0,
			'total'    => 0,
		);

		$latest_decoded = null;
		if ( is_array( $latest ) ) {
			$issues = json_decode( (string) $latest['issues'], true );
			if ( is_array( $issues ) ) {
				foreach ( $issues as $issue ) {
					$severity = isset( $issue['severity'] ) ? (string) $issue['severity'] : 'info';
					if ( 'recommendation' === $severity || 'passed' === $severity ) {
						// Legacy rows stored before the unified issue contract.
						$severity = 'info';
					}
					if ( isset( $counts[ $severity ] ) ) {
						$counts[ $severity ]++;
					}
					$counts['total']++;
				}
			}
			$latest_decoded = array(
				'audit_id'   => (int) $latest['id'],
				'post_id'    => (int) $latest['post_id'],
				'url'        => $latest['url'],
				'score'      => (int) $latest['score'],
				'categories' => json_decode( (string) $latest['categories'], true ),
				'checked_at' => $latest['created_at'],
			);
		}

		$thirty_days_ago = gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS );

		$pages_analyzed = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT post_id) FROM {$table} WHERE created_at >= %s",
				$thirty_days_ago
			)
		);
		$audits_total   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );

		return array(
			'latest'         => $latest_decoded,
			'counts'         => $counts,
			'pages_analyzed' => $pages_analyzed,
			'audits_total'   => $audits_total,
		);
	}

	/**
	 * Run all checks against a post.
	 *
	 * Only statically-detectable facts are checked. Nothing here guesses:
	 * e.g. mobile rendering quality is NOT claimed, only missing
	 * width/height attributes (a layout-shift risk) are flagged.
	 *
	 * @param \WP_Post $post Post to check.
	 * @return array List of issue arrays.
	 */
	private static function run_checks( \WP_Post $post ): array {
		$issues  = array();
		$content = (string) $post->post_content;
		$plain   = wp_strip_all_tags( $content );
		$words   = self::word_count( $plain );

		// 1. Title length (on-page).
		$title     = trim( (string) $post->post_title );
		$title_len = Text_Utils::strlen( $title );
		if ( '' === $title ) {
			$issues[] = self::issue(
				'title_length',
				'critical',
				'onpage',
				'title',
				__( 'Page title', 'localboost-ai' ),
				__( 'This page has no title.', 'localboost-ai' ),
				__( 'Search engines use the page title as the main headline in search results. A missing title hurts visibility and click-through.', 'localboost-ai' ),
				__( 'Add a clear, descriptive title. Use the AI Optimizer to generate one.', 'localboost-ai' ),
				true
			);
		} elseif ( $title_len < 30 || $title_len > 60 ) {
			$issues[] = self::issue(
				'title_length',
				'warning',
				'onpage',
				'title',
				__( 'Page title length', 'localboost-ai' ),
				sprintf(
									/* translators: %d: title length in characters. */
									__( 'The page title is %d characters long.', 'localboost-ai' ),
									$title_len
								),
				__( 'Titles shorter than 30 characters may not describe the page well; titles longer than 60 characters are often cut off in search results.', 'localboost-ai' ),
				__( 'Rewrite the title to 30-60 characters. Use the AI Optimizer to generate a better title.', 'localboost-ai' ),
				true
			);
		} else {
			$issues[] = self::issue(
				'title_length',
				'passed',
				'onpage',
				'title',
				__( 'Page title length', 'localboost-ai' ),
				sprintf(
									/* translators: %d: title length in characters. */
									__( 'The page title is %d characters long, within the recommended 30-60 range.', 'localboost-ai' ),
									$title_len
								),
				'',
				''
			);
		}

		// 2. Meta description (on-page).
		$meta_desc = trim( (string) get_post_meta( $post->ID, '_lbai_meta_description', true ) );
		if ( '' === $meta_desc ) {
			$meta_desc = trim( (string) get_post_meta( $post->ID, '_yoast_wpseo_metadesc', true ) );
		}
		if ( '' === $meta_desc ) {
			$meta_desc = trim( (string) get_post_meta( $post->ID, 'rank_math_description', true ) );
		}
		$desc_len = Text_Utils::strlen( $meta_desc );
		if ( '' === $meta_desc ) {
			$issues[] = self::issue(
				'meta_description',
				'critical',
				'onpage',
				'meta_description',
				__( 'Meta description', 'localboost-ai' ),
				__( 'This page has no meta description.', 'localboost-ai' ),
				__( 'The meta description is the text shown under your title in search results. Without it, search engines pick a random snippet, which usually gets fewer clicks.', 'localboost-ai' ),
				__( 'Write a 120-160 character summary of the page. Use the AI Optimizer to generate one.', 'localboost-ai' ),
				true
			);
		} elseif ( $desc_len > 160 ) {
			$issues[] = self::issue(
				'meta_description',
				'warning',
				'onpage',
				'meta_description',
				__( 'Meta description length', 'localboost-ai' ),
				sprintf(
									/* translators: %d: meta description length in characters. */
									__( 'The meta description is %d characters long and will likely be cut off in search results.', 'localboost-ai' ),
									$desc_len
								),
				__( 'Search engines typically display about 155-160 characters of the meta description.', 'localboost-ai' ),
				__( 'Shorten the description to 120-160 characters. Use the AI Optimizer to rewrite it.', 'localboost-ai' ),
				true
			);
		} else {
			$issues[] = self::issue(
				'meta_description',
				'passed',
				'onpage',
				'meta_description',
				__( 'Meta description', 'localboost-ai' ),
				__( 'A meta description is set and its length looks good.', 'localboost-ai' ),
				'',
				''
			);
		}

		// 3. H1 count (on-page).
		$h1_count = preg_match_all( '/<h1[\s>]/i', $content );
		if ( 0 === $h1_count ) {
			$issues[] = self::issue(
				'h1_count',
				'warning',
				'onpage',
				'h1',
				__( 'Main heading (H1)', 'localboost-ai' ),
				__( 'This page has no H1 heading.', 'localboost-ai' ),
				__( 'The H1 tells search engines and visitors what the page is about. Pages usually perform better with exactly one clear H1.', 'localboost-ai' ),
				__( 'Add one H1 heading that describes the page. Use the AI Optimizer to generate one.', 'localboost-ai' ),
				true
			);
		} elseif ( $h1_count > 1 ) {
			$issues[] = self::issue(
				'h1_count',
				'warning',
				'onpage',
				'h1',
				__( 'Main heading (H1)', 'localboost-ai' ),
				sprintf(
									/* translators: %d: number of H1 headings found. */
									__( 'This page has %d H1 headings.', 'localboost-ai' ),
									$h1_count
								),
				__( 'Multiple H1 headings can confuse search engines about the page topic. One clear H1 per page is the safest structure.', 'localboost-ai' ),
				__( 'Keep the strongest H1 and change the others to H2 headings.', 'localboost-ai' )
			);
		} else {
			$issues[] = self::issue(
				'h1_count',
				'passed',
				'onpage',
				'h1',
				__( 'Main heading (H1)', 'localboost-ai' ),
				__( 'The page has exactly one H1 heading.', 'localboost-ai' ),
				'',
				''
			);
		}

		// 4. H2 structure (content).
		$h2_count = preg_match_all( '/<h2[\s>]/i', $content );
		if ( $words > 300 && 0 === $h2_count ) {
			$issues[] = self::issue(
				'h2_structure',
				'warning',
				'content',
				'',
				__( 'Subheadings (H2)', 'localboost-ai' ),
				__( 'This is a long page with no H2 subheadings.', 'localboost-ai' ),
				__( 'Subheadings break content into scannable sections, help readers stay on the page, and give search engines more topic signals.', 'localboost-ai' ),
				__( 'Split the content into sections with descriptive H2 subheadings.', 'localboost-ai' )
			);
		} else {
			$issues[] = self::issue(
				'h2_structure',
				'passed',
				'content',
				'',
				__( 'Subheadings (H2)', 'localboost-ai' ),
				__( 'The heading structure looks reasonable for this page length.', 'localboost-ai' ),
				'',
				''
			);
		}

		// 5. Content length (content).
		if ( $words < 100 ) {
			$issues[] = self::issue(
				'content_length',
				'critical',
				'content',
				'',
				__( 'Content length', 'localboost-ai' ),
				sprintf(
									/* translators: %d: word count. */
									__( 'This page has only about %d words.', 'localboost-ai' ),
									$words
								),
				__( 'Very thin pages rarely rank well because they give search engines little to understand and visitors little reason to stay.', 'localboost-ai' ),
				__( 'Expand the page with genuinely useful information about your service, area, pricing or process. Use the AI Content Generator for a first draft, then edit it in your own words.', 'localboost-ai' )
			);
		} elseif ( $words < 300 ) {
			$issues[] = self::issue(
				'content_length',
				'warning',
				'content',
				'',
				__( 'Content length', 'localboost-ai' ),
				sprintf(
									/* translators: %d: word count. */
									__( 'This page has about %d words, which is thin for a service page.', 'localboost-ai' ),
									$words
								),
				__( 'Pages that explain a service in depth tend to rank better and convert more visitors.', 'localboost-ai' ),
				__( 'Add useful detail: what you offer, who it is for, your process, your service area and answers to common questions.', 'localboost-ai' )
			);
		} else {
			$issues[] = self::issue(
				'content_length',
				'passed',
				'content',
				'',
				__( 'Content length', 'localboost-ai' ),
				sprintf(
									/* translators: %d: word count. */
									__( 'This page has about %d words, which is a healthy length.', 'localboost-ai' ),
									$words
								),
				'',
				''
			);
		}

		// 6. Image alt text (on-page).
		preg_match_all( '/<img\b[^>]*>/i', $content, $img_matches );
		$img_total = count( $img_matches[0] );
		$img_bad   = 0;
		foreach ( $img_matches[0] as $img_tag ) {
			if ( ! preg_match( '/alt\s*=\s*("[^"]*"|\'[^\']*\')/i', $img_tag, $alt_match ) ) {
				$img_bad++;
				continue;
			}
			$alt_value = trim( $alt_match[1], "\"'" );
			if ( '' === trim( $alt_value ) ) {
				$img_bad++;
			}
		}
		if ( 0 === $img_total ) {
			$issues[] = self::issue(
				'images_alt',
				'passed',
				'onpage',
				'',
				__( 'Image alt text', 'localboost-ai' ),
				__( 'This page contains no images, so there is no alt text to check.', 'localboost-ai' ),
				'',
				''
			);
		} elseif ( $img_bad > 0 && ( $img_bad / $img_total ) > 0.5 ) {
			$issues[] = self::issue(
				'images_alt',
				'critical',
				'onpage',
				'alt_texts',
				__( 'Image alt text', 'localboost-ai' ),
				sprintf(
									/* translators: 1: number of images missing alt text, 2: total images. */
									__( '%1$d of %2$d images are missing descriptive alt text.', 'localboost-ai' ),
									$img_bad,
									$img_total
								),
				__( 'Alt text describes images to search engines and to visitors using screen readers. Missing alt text is a missed ranking signal and an accessibility problem.', 'localboost-ai' ),
				__( 'Add a short, descriptive alt text to every image (for example: "dentist cleaning teeth in Lyon"). Use the AI Optimizer to generate alt texts.', 'localboost-ai' ),
				true
			);
		} elseif ( $img_bad > 0 ) {
			$issues[] = self::issue(
				'images_alt',
				'warning',
				'onpage',
				'alt_texts',
				__( 'Image alt text', 'localboost-ai' ),
				sprintf(
									/* translators: 1: number of images missing alt text, 2: total images. */
									__( '%1$d of %2$d images are missing descriptive alt text.', 'localboost-ai' ),
									$img_bad,
									$img_total
								),
				__( 'Alt text describes images to search engines and to visitors using screen readers.', 'localboost-ai' ),
				__( 'Add a short, descriptive alt text to the remaining images.', 'localboost-ai' ),
				true
			);
		} else {
			$issues[] = self::issue(
				'images_alt',
				'passed',
				'onpage',
				'alt_texts',
				__( 'Image alt text', 'localboost-ai' ),
				sprintf(
									/* translators: %d: total images. */
									__( 'All %d images have alt text.', 'localboost-ai' ),
									$img_total
								),
				'',
				''
			);
		}

		// 7-8. Internal and external links.
		$home_url  = untrailingslashit( home_url() );
		$home_len  = strlen( $home_url );
		$internal  = 0;
		$external  = 0;
		preg_match_all( '/<a\b[^>]*\bhref\s*=\s*("([^"]+)"|\'([^\']+)\')/i', $content, $link_matches, PREG_SET_ORDER );
		foreach ( $link_matches as $link_match ) {
			$href = isset( $link_match[2] ) && '' !== $link_match[2] ? $link_match[2] : $link_match[3];
			$href = trim( (string) $href );
			if ( '' === $href || 0 === strpos( $href, '#' ) ) {
				continue;
			}
			if ( 0 === strpos( $href, $home_url )
				&& ( strlen( $href ) === $home_len || in_array( $href[ $home_len ], array( '/', '?', '#' ), true ) ) ) {
				$internal++;
			} elseif ( preg_match( '#^/(?!/)#', $href ) ) {
				$internal++;
			} elseif ( preg_match( '#^https?://#i', $href ) ) {
				$external++;
			}
		}

		if ( 0 === $internal && $words > 200 ) {
			$issues[] = self::issue(
				'internal_links',
				'warning',
				'onpage',
				'internal_links',
				__( 'Internal links', 'localboost-ai' ),
				__( 'This page has no links to other pages of your website.', 'localboost-ai' ),
				__( 'Internal links help visitors discover your services and help search engines understand your site structure.', 'localboost-ai' ),
				__( 'Add a few links to related service or location pages where they help the reader.', 'localboost-ai' )
			);
		} else {
			$issues[] = self::issue(
				'internal_links',
				'passed',
				'onpage',
				'internal_links',
				__( 'Internal links', 'localboost-ai' ),
				sprintf(
									/* translators: %d: number of internal links. */
									__( 'This page links to %d other page(s) of your website.', 'localboost-ai' ),
									$internal
								),
				'',
				''
			);
		}

		$issues[] = self::issue(
				'external_links',
				'passed',
				'technical',
				'',
				__( 'External links', 'localboost-ai' ),
				sprintf(
								/* translators: %d: number of external links. */
								__( 'This page contains %d external link(s).', 'localboost-ai' ),
								$external
							),
				'',
				''
			);

		// 9. Canonical URL (technical).
		if ( false !== has_action( 'wp_head', 'rel_canonical' ) ) {
			$issues[] = self::issue(
				'canonical',
				'passed',
				'technical',
				'',
				__( 'Canonical URL', 'localboost-ai' ),
				__( 'WordPress outputs a canonical link tag for this page.', 'localboost-ai' ),
				'',
				''
			);
		} else {
			$issues[] = self::issue(
				'canonical',
				'recommendation',
				'technical',
				'',
				__( 'Canonical URL', 'localboost-ai' ),
				__( 'No canonical link tag was detected in wp_head.', 'localboost-ai' ),
				__( 'The canonical tag tells search engines which URL is the official version of a page, avoiding duplicate-content confusion.', 'localboost-ai' ),
				__( 'Make sure your theme calls wp_head() and that no plugin or theme code removes rel_canonical.', 'localboost-ai' )
			);
		}

		// 10. Robots directives (technical).
		$robots        = apply_filters( 'wp_robots', array() );
		$robots_block  = is_array( $robots )
			&& ( in_array( 'noindex', $robots, true ) || in_array( 'nofollow', $robots, true ) );
		if ( $robots_block ) {
			$issues[] = self::issue(
				'robots_meta',
				'warning',
				'technical',
				'',
				__( 'Robots directives', 'localboost-ai' ),
				__( 'This page appears to block search engines (noindex or nofollow).', 'localboost-ai' ),
				__( 'A noindex directive tells search engines to drop the page from results. That is correct for private pages, but a mistake on pages you want found.', 'localboost-ai' ),
				__( 'If this page should appear in Google, remove the noindex setting (Settings > Reading, or your SEO plugin settings for this page).', 'localboost-ai' )
			);
		} else {
			$issues[] = self::issue(
				'robots_meta',
				'passed',
				'technical',
				'',
				__( 'Robots directives', 'localboost-ai' ),
				__( 'This page does not block search engines.', 'localboost-ai' ),
				'',
				''
			);
		}

		// 11. Open Graph data (technical).
		$og_source = '';
		if ( defined( 'WPSEO_VERSION' ) ) {
			$og_source = 'Yoast SEO';
		} elseif ( defined( 'RANK_MATH_VERSION' ) ) {
			$og_source = 'Rank Math';
		} elseif ( '' !== trim( (string) get_post_meta( $post->ID, '_yoast_wpseo_opengraph-title', true ) )
			|| '' !== trim( (string) get_post_meta( $post->ID, 'rank_math_facebook_title', true ) ) ) {
			$og_source = __( 'custom meta fields', 'localboost-ai' );
		}
		if ( '' !== $og_source ) {
			$issues[] = self::issue(
				'open_graph',
				'passed',
				'technical',
				'',
				__( 'Open Graph data', 'localboost-ai' ),
				sprintf(
									/* translators: %s: detected source of Open Graph data. */
									__( 'Open Graph data appears to be handled by %s.', 'localboost-ai' ),
									$og_source
								),
				'',
				''
			);
		} else {
			$issues[] = self::issue(
				'open_graph',
				'recommendation',
				'technical',
				'',
				__( 'Open Graph data', 'localboost-ai' ),
				__( 'No Open Graph (social sharing) data was detected for this page.', 'localboost-ai' ),
				__( 'Open Graph tags control how your page looks when shared on Facebook, WhatsApp, LinkedIn and other platforms.', 'localboost-ai' ),
				__( 'Install an SEO plugin (e.g. Yoast SEO or Rank Math) to generate Open Graph tags automatically.', 'localboost-ai' )
			);
		}

		// 12. Structured data (schema).
		if ( Options::get( 'lbai_schema_enabled' ) ) {
			$issues[] = self::issue(
				'structured_data',
				'passed',
				'schema',
				'',
				__( 'Structured data', 'localboost-ai' ),
				__( 'LocalBoost AI schema output is enabled.', 'localboost-ai' ),
				'',
				''
			);
		} else {
			$issues[] = self::issue(
				'structured_data',
				'recommendation',
				'schema',
				'',
				__( 'Structured data', 'localboost-ai' ),
				__( 'No LocalBoost AI schema is enabled for this site.', 'localboost-ai' ),
				__( 'Schema.org structured data helps search engines understand your business and can produce rich results (ratings, hours, address) in search.', 'localboost-ai' ),
				__( 'Complete the Local SEO settings, preview the generated JSON-LD, then enable schema output.', 'localboost-ai' )
			);
		}

		// 13. Local NAP presence (local).
		$biz_name  = trim( (string) Options::get( 'lbai_business_name' ) );
		$biz_phone = preg_replace( '/\D/', '', (string) Options::get( 'lbai_phone' ) );
		$biz_city  = trim( (string) Options::get( 'lbai_city' ) );
		if ( '' === $biz_name && '' === $biz_phone && '' === $biz_city ) {
			$issues[] = self::issue(
				'local_nap',
				'recommendation',
				'local',
				'',
				__( 'Business information (NAP)', 'localboost-ai' ),
				__( 'Your business name, phone and city are not configured yet.', 'localboost-ai' ),
				__( 'LocalBoost cannot check name/address/phone consistency on your pages until it knows your official business details.', 'localboost-ai' ),
				__( 'Fill in your business details in the Local SEO settings, then re-run the audit.', 'localboost-ai' )
			);
		} else {
			$missing = array();
			if ( '' !== $biz_name && false === Text_Utils::stripos( $plain, $biz_name ) ) {
				$missing[] = __( 'business name', 'localboost-ai' );
			}
			if ( strlen( (string) $biz_phone ) >= 7 ) {
				$content_digits = preg_replace( '/\D/', '', $plain );
				if ( false === strpos( (string) $content_digits, (string) $biz_phone ) ) {
					$missing[] = __( 'phone number', 'localboost-ai' );
				}
			}
			if ( empty( $missing ) ) {
				$issues[] = self::issue(
				'local_nap',
				'passed',
				'local',
				'',
				__( 'Business information (NAP)', 'localboost-ai' ),
				__( 'Your configured business name and phone number appear on this page.', 'localboost-ai' ),
				'',
				''
			);
			} else {
				$issues[] = self::issue(
				'local_nap',
				'warning',
				'local',
				'',
				__( 'Business information (NAP)', 'localboost-ai' ),
				sprintf(
										/* translators: %s: comma-separated list of missing business details. */
										__( 'This page does not mention your %s as configured in the Local SEO settings.', 'localboost-ai' ),
										implode( ', ', $missing )
									),
				__( 'Consistent name, address and phone (NAP) across your pages builds trust with local search engines.', 'localboost-ai' ),
				__( 'Add the missing business details to the page, exactly as configured in the Local SEO settings.', 'localboost-ai' )
			);
			}
		}

		// 14. Contact information (local).
		$has_phone = (bool) preg_match( '/\+?\d[\d\s().-]{5,}\d/', $plain );
		$has_email = (bool) preg_match( '/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i', $plain );
		if ( $has_phone || $has_email ) {
			$issues[] = self::issue(
				'contact_info',
				'passed',
				'local',
				'',
				__( 'Contact information', 'localboost-ai' ),
				__( 'A phone number or email address was found on this page.', 'localboost-ai' ),
				'',
				''
			);
		} else {
			$issues[] = self::issue(
				'contact_info',
				'warning',
				'local',
				'',
				__( 'Contact information', 'localboost-ai' ),
				__( 'No phone number or email address was found on this page.', 'localboost-ai' ),
				__( 'Local customers need an obvious way to contact you. Pages without contact details convert worse.', 'localboost-ai' ),
				__( 'Add your phone number or email address to the page, ideally near the top or in a clear call-to-action.', 'localboost-ai' )
			);
		}

		// 15. Image dimensions / layout shift (technical).
		$imgs_no_dims = 0;
		foreach ( $img_matches[0] as $img_tag ) {
			$has_width  = (bool) preg_match( '/\bwidth\s*=/i', $img_tag );
			$has_height = (bool) preg_match( '/\bheight\s*=/i', $img_tag );
			if ( ! $has_width || ! $has_height ) {
				$imgs_no_dims++;
			}
		}
		if ( $img_total > 0 && $imgs_no_dims > 0 ) {
			$issues[] = self::issue(
				'mobile_images',
				'recommendation',
				'technical',
				'',
				__( 'Image dimensions', 'localboost-ai' ),
				sprintf(
									/* translators: 1: number of images without dimensions, 2: total images. */
									__( '%1$d of %2$d images are missing width/height attributes.', 'localboost-ai' ),
									$imgs_no_dims,
									$img_total
								),
				__( 'Without dimensions, images can shift the page layout while loading. This hurts the mobile experience and a Google metric called Cumulative Layout Shift.', 'localboost-ai' ),
				__( 'Note: this check cannot test your page on a real phone. Re-save the images through the WordPress media library so width/height are added, and check the page on a mobile device yourself.', 'localboost-ai' )
			);
		} else {
			$issues[] = self::issue(
				'mobile_images',
				'passed',
				'technical',
				'',
				__( 'Image dimensions', 'localboost-ai' ),
				__( 'Images include width/height attributes, or the page has no images.', 'localboost-ai' ),
				'',
				''
			);
		}

		// 16. HTTPS (technical).
		if ( 'https' === parse_url( home_url(), PHP_URL_SCHEME ) ) {
			$issues[] = self::issue(
				'https_check',
				'passed',
				'technical',
				'',
				__( 'HTTPS', 'localboost-ai' ),
				__( 'Your website uses HTTPS.', 'localboost-ai' ),
				'',
				''
			);
		} else {
			$issues[] = self::issue(
				'https_check',
				'critical',
				'technical',
				'',
				__( 'HTTPS', 'localboost-ai' ),
				__( 'Your website does not use HTTPS.', 'localboost-ai' ),
				__( 'Browsers warn visitors about non-HTTPS sites, and Google treats HTTPS as a ranking signal. For a local business, this directly costs trust.', 'localboost-ai' ),
				__( 'Ask your hosting provider to enable a free SSL certificate (for example Let\'s Encrypt) and switch your site address to https://.', 'localboost-ai' )
			);
		}

		return $issues;
	}

	/**
	 * Build a normalized issue array following the unified audit contract.
	 *
	 * Severity is normalized to critical|warning|info ('recommendation' and
	 * 'passed' become 'info'). The field is normalized through
	 * Field_Registry; ai_fix is forced to false unless the field is a valid
	 * optimizable canonical field, so the contract can never promise an AI
	 * fix that the optimizer cannot deliver.
	 *
	 * @param string $id       Stable issue identifier.
	 * @param string $severity critical|warning|info (others become info).
	 * @param string $category technical|onpage|local|content|schema.
	 * @param string $field    Canonical optimizer field name, or '' when the
	 *                         issue is not tied to an optimizer field.
	 * @param string $title    Short issue title (translated by caller context).
	 * @param string $problem  What was found.
	 * @param string $why      Why it matters (empty for info checks).
	 * @param string $action   Recommended action (empty for info checks).
	 * @param bool   $ai_fix   Whether the AI Optimizer can fix this issue.
	 * @return array
	 */
	private static function issue( string $id, string $severity, string $category, string $field, string $title, string $problem, string $why, string $action, bool $ai_fix = false ): array {
		switch ( $severity ) {
			case 'critical':
			case 'warning':
				break;
			default:
				// 'recommendation', 'passed' and anything unknown are
				// informational results, not problems.
				$severity = 'info';
				break;
		}

		$canonical = Field_Registry::canonicalize( $field );
		if ( null === $canonical ) {
			$canonical = '';
		}
		if ( $ai_fix && ! in_array( $canonical, Field_Registry::all(), true ) ) {
			// Never advertise an AI fix for a field the optimizer cannot
			// handle: unknown fields and the deprecated h2_structure.
			$ai_fix = false;
		}

		return array(
			'id'       => $id,
			'severity' => $severity,
			'category' => $category,
			'field'    => $canonical,
			'title'    => $title,
			'problem'  => $problem,
			'why'      => $why,
			'action'   => $action,
			'ai_fix'   => $ai_fix,
		);
	}

	/**
	 * Persist an audit row.
	 *
	 * @param \WP_Post $post   Audited post.
	 * @param array    $score  Score breakdown from SEO_Scorer::calculate().
	 * @param array    $issues Issue list.
	 * @return int Inserted audit row ID.
	 * @throws \RuntimeException When the insert fails.
	 */
	private static function save_audit( \WP_Post $post, array $score, array $issues ): int {
		global $wpdb;
		$table = $wpdb->prefix . 'lbai_audits';

		$inserted = $wpdb->insert(
			$table,
			array(
				'post_id'    => $post->ID,
				'url'        => get_permalink( $post ),
				'score'      => $score['score'],
				'categories' => wp_json_encode( $score['categories'] ),
				'issues'     => wp_json_encode( $issues ),
				'created_at' => current_time( 'mysql', true ),
			),
			array( '%d', '%s', '%d', '%s', '%s', '%s' )
		);

		if ( false === $inserted ) {
			throw new \RuntimeException( 'The SEO audit could not be stored.' );
		}

		return (int) $wpdb->insert_id;
	}

	/**
	 * Count words in plain text, preferring the shared Text_Stats helper.
	 *
	 * @param string $text Plain text.
	 * @return int Word count.
	 */
	private static function word_count( string $text ): int {
		$text = trim( wp_strip_all_tags( $text ) );
		if ( '' === $text ) {
			return 0;
		}
		if ( class_exists( Text_Stats::class ) && method_exists( Text_Stats::class, 'word_count' ) ) {
			return max( 0, (int) Text_Stats::word_count( $text ) );
		}
		return max( 0, (int) str_word_count( $text ) );
	}
}
