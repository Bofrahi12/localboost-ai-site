<?php
/**
 * SEO Score calculator.
 *
 * Pure logic, no WordPress dependencies: receives already-translated issue
 * arrays from the auditor and returns a deterministic score breakdown.
 *
 * @package LocalBoostAI\Services
 */

namespace LocalBoostAI\Services;

defined( 'ABSPATH' ) || exit;

final class SEO_Scorer {

	/**
	 * Score deductions per issue severity.
	 *
	 * @var array
	 */
	const DEDUCTIONS = array(
		'critical'       => 15,
		'warning'        => 7,
		'recommendation' => 3,
		'passed'         => 0,
	);

	/**
	 * Score categories.
	 *
	 * @var array
	 */
	const CATEGORIES = array( 'technical', 'onpage', 'local', 'content', 'schema' );

	/**
	 * Calculate the LocalBoost SEO Score for a set of issues.
	 *
	 * Each issue must provide at least:
	 *   - severity: critical|warning|recommendation|passed
	 *   - category: technical|onpage|local|content|schema
	 *
	 * Unknown severities are treated as "passed"; unknown categories only
	 * affect the overall score, never a category score.
	 *
	 * @param array $issues List of issue arrays.
	 * @return array {
	 *     @type int   $score      Overall score, 0-100.
	 *     @type array $categories Per-category scores, 0-100 each.
	 *     @type array $counts     Counts per severity plus total.
	 * }
	 */
	public static function calculate( array $issues ): array {
		$counts = array(
			'critical'       => 0,
			'warning'        => 0,
			'recommendation' => 0,
			'passed'         => 0,
			'total'          => 0,
		);

		$category_deductions = array_fill_keys( self::CATEGORIES, 0 );
		$total_deduction     = 0;

		foreach ( $issues as $issue ) {
			if ( ! is_array( $issue ) ) {
				continue;
			}

			$severity = isset( $issue['severity'] ) ? (string) $issue['severity'] : 'passed';
			if ( ! isset( self::DEDUCTIONS[ $severity ] ) ) {
				$severity = 'passed';
			}
			$counts[ $severity ]++;
			$counts['total']++;

			$deduction          = self::DEDUCTIONS[ $severity ];
			$total_deduction   += $deduction;

			$category = isset( $issue['category'] ) ? (string) $issue['category'] : '';
			if ( in_array( $category, self::CATEGORIES, true ) ) {
				$category_deductions[ $category ] += $deduction;
			}
		}

		$categories = array();
		foreach ( self::CATEGORIES as $category ) {
			$categories[ $category ] = max( 0, 100 - $category_deductions[ $category ] );
		}

		return array(
			'score'      => max( 0, 100 - $total_deduction ),
			'categories' => $categories,
			'counts'     => $counts,
		);
	}
}
