<?php
/**
 * Uninstall routine for LocalBoost AI.
 *
 * Removes plugin-owned data only: custom tables, options (including encrypted
 * lbai_secure_* options), transients and scheduled cron hooks.
 *
 * NEVER deletes posts, pages, or any other user content.
 *
 * @package LocalBoostAI
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

global $wpdb;

require_once __DIR__ . '/includes/class-options.php';

// 1. Drop custom tables.
$tables = array('lbai_audits', 'lbai_usage', 'lbai_reports');
foreach ($tables as $table) {
    // Table names are hardcoded plugin constants; no user input involved.
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}{$table}"); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
}

// 2. Delete every registered plugin option (canonical keys + aliases).
foreach (\LocalBoostAI\Includes\Options::all_known_keys() as $option_key) {
    delete_option($option_key);
}

// 3. Delete encrypted options stored by Secure_Store (lbai_secure_*).
$secure_like    = $wpdb->esc_like('lbai_secure_') . '%';
$secure_options = $wpdb->get_col(
    $wpdb->prepare(
        "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
        $secure_like
    )
);
if (is_array($secure_options)) {
    foreach ($secure_options as $option_name) {
        delete_option($option_name);
    }
}

// 4. Delete plugin transients (data + timeout rows).
$transient_like = $wpdb->esc_like('_transient_lbai_') . '%';
$timeout_like   = $wpdb->esc_like('_transient_timeout_lbai_') . '%';
$wpdb->query(
    $wpdb->prepare(
        "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
        $transient_like,
        $timeout_like
    )
);

// 5. Clear scheduled monitoring.
wp_clear_scheduled_hook('lbai_scheduled_audit');
